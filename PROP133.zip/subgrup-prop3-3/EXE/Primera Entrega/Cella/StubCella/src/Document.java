import java.util.Vector;

public class Document {
    
    //Primera Patillada :) Es revisarà properament
	
	private String nomDoc;
	private String path;
	private boolean mode;
	private Vector<Full> llibreta;
	
	public Document() 
	{
		nomDoc = "New document";
		path = null;
		mode = true;
		llibreta.add(new Full());
	}
	
	public Document carregarDocPropi(String nomD)
	{
		return new Document();
	}
	
	public Document carregarDocCSV(String nomD)
	{
		return new Document();
	}
	
	public void desarDoc()
	{
		//desa el document, reescrivint el que hi ha en el path del propi doc
		return;
	}
	
	public void anomenaIDesa(String format, String nomD)
	{
		//desarà en el format designat i amb el nom proveït
		nomDoc = nomD;
	}
	
	public void eliminarDocument()
	{
		return;
	}
	
	public void afegirFull()
	{
		llibreta.add(new Full());
	}
	
	public void ordenarFull()
	{
		llibreta.sort(null);
	}
	
	private Full eliminarFull(int i) 					// Retorna Full per si implemntem desfer / refer.
	{
		Full f = new Full();
		if (i < llibreta.size()) f = llibreta.remove(i);
		return f;
	}
	
	public void mode()
	{
		mode = !mode;
	}
	
	
}
