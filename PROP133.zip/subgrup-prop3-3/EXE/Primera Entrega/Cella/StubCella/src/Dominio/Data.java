package Dominio;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

public class Data extends Dada {
	public Data (Cella casella, String contingut, String formula) {
		super(casella, contingut, formula);
	}
	
	/* Funcions de data */
	public String data (String tipus) {
		Date data = null;
		try {
			data = DateFormat.getDateInstance(DateFormat.SHORT).parse(getContingut());
		} catch (ParseException e) {
			return getContingut();
		}
			//Es converteix el contingut (String) de la dada tipus Data en un valor tipus data
		
		Calendar calendari = Calendar.getInstance();
		calendari.setTime(data);
			//S'inicialitza el calendari a partir del qual es trobara la informacio desitjada de la data
		
		if (tipus.equals("DATADIA"))
		{				
				//La funcio del calendari retorna un numero entre l'1 i el 7, que representa els dies numerats de Diumenge a Dissabte
			switch (calendari.get(Calendar.DAY_OF_WEEK))
			{
				case 2:
					return "Dilluns";
				case 3:
					return "Dimarts";
				case 4:
					return "Dimecres";
				case 5:
					return "Dijous";
				case 6:
					return "Divendres";
				case 7:
					return "Dissabte";
				case 1:
					return "Diumenge";
				default:
					break;
			}
		}
		
		return getContingut();
	}
	
	public String data (String tipus, char instant) throws FuncioNoAplicable {
		Date data = null;
		try {
			data = DateFormat.getDateInstance(DateFormat.SHORT).parse(getContingut());
		} catch (ParseException e) {
			return getContingut();
		}
			//Es converteix el contingut (String) de la dada tipus Data en un valor tipus data
		
		Calendar calendari = Calendar.getInstance();
		calendari.setTime(data);
			//S'inicialitza el calendari a partir del qual es trobara la informacio desitjada de la data
		
		if (tipus.equals("DATELEM"))
		{
				//Segons el caracter introduit es retorna el dia, el mes o l'any de la data sobre la qual s'opera
			if (instant == 'D') return ""+calendari.get(Calendar.DAY_OF_MONTH);
			else if (instant == 'M') return ""+(calendari.get(Calendar.MONTH)+1);
			else if (instant == 'A') return ""+calendari.get(Calendar.YEAR);
			else throw new FuncioNoAplicable("L'indicador de l'element a extreure de la data no es valid: s'admet D, M, A. Has introduit " + instant);
		}
		
		return getContingut();
	}
}
