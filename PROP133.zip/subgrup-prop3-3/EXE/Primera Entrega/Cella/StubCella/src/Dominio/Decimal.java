package Dominio;

public class Decimal extends Numerica {
	public Decimal (Cella casella, String contingut, String formula) {
		super(casella, contingut, formula);
	}
	
	/* Funcions de truncament */
	public String numericaTruncament (String tipus) {
		String fixed = aPunt(getContingut());
		double numTruncat = Double.parseDouble(fixed);
		
		if (tipus.equals("TRUNCINT"))
		{
				//Si el numero es positiu, s'arrodoneix (trunca al seu valor enter) a la baixa.
			if (numTruncat >= 0) return (""+(int)Math.floor(numTruncat));
			else return (""+(int)Math.ceil(numTruncat));
				//Si el numero es negatiu, caldra arribar al valor absolut superior, no arrodonir a la baixa.
		}
		else if (tipus.equals("TRUNCNOT"))
		{
			// Opcional
		}
		
		return getContingut();
	}
	
	public String numericaTruncament (String tipus, int decimal) {
		String fixed = aPunt(getContingut());
		double numTruncat = Double.parseDouble(fixed);
		
		if (tipus.equals("TRUNCDEC"))
		{
				//Calcul matematic de truncament
			numTruncat = numTruncat*Math.pow(10, decimal);
				//Es mou el valor decimal just despres de la xifra fins on es vol truncar
			if (numTruncat >= 0) numTruncat = Math.floor(numTruncat);
			else if (numTruncat < 0) numTruncat = Math.ceil(numTruncat);
				//Es trunca a enter (prenent en consideracio que un valor sigui positiu o no)
			numTruncat = numTruncat/Math.pow(10, decimal);
				//Es divideix el valor (ara enter) per les potencies de 10 indicades fins recuperar el valor original, ara truncat
			
			return (""+numTruncat);
		}
		
		return getContingut();
	}
	
	/* Funcions de conversio */
	public String numericaConversio (String tipus) {
		String numConvertit = "";
		
		if (tipus.equals("CONVDEC"))
		{			
				//Si el format del valor conte la representacio decimal amb ',' es canvia a punt ('.')
			if (getContingut().matches("-{0,1}\\d{1,},\\d{1,}")) numConvertit = aPunt(getContingut());
			else if (getContingut().matches("-{0,1}\\d{1,}\\.\\d{1,}")) numConvertit = aComa(getContingut());
				//Si el format del valor conte la representacio decimal amb '.' es canvia a coma (',')
			
			return numConvertit;
		}
		
		return getContingut();
	}
	
	public String numericaConversio (String tipus, char nou) throws FuncioNoAplicable {	
		if (tipus.equals("CONVRAD"))
		{
			// Opcional
		}
		
		return getContingut();
	}
}
