package Dominio;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Dada {
	/* Cella en blanc */
	public Dada (Cella casella) {
		cella = casella;
		contingut = new String("");
		tipus = checkTipus(contingut);
		formula = new String ("");
	}
	
	/* Cella amb contingut */
	public Dada (Cella casella, String contingut, String formula) {
		cella = casella;
		this.contingut = new String(contingut);
		this.tipus = checkTipus(contingut);
		this.formula = new String(formula);
	}
	
	/* Setters */
	public void setCella (Cella casella) {
		cella = casella;
	}
	
	public void setContingut (String nou) {
			//Quan es canvia el contingut de la dada es revisa el seu tipus i es crea la subclasse necessaria.
		setTipus(checkTipus(nou));
		creaDadaConcreta();
		contingut = new String(nou);
	}
	
	public void setTipus (char nou) {
		tipus = nou;
	}
	
	public void setFormula (String nou) {
		formula = new String(nou);
	}
	
	/* Getters */
	public Cella getCella () {
		return cella;
	}
	
	public String getContingut () {
		return contingut;
	}
	
	public char getTipus () {
		
		return tipus;
	}
	
	public String getFormula () {
		return formula;
	}
	
	/* Determinacio del tipus de la dada */
	public char checkTipus(String contingut)
	{
		String formatEnter = "-{0,1}\\d{1,}";
		String formatDecimal = "-{0,1}\\d{1,}(\\.\\d{1,}|,\\d{1,})";
		String formatBinari = "0b(0|1){1,}";
		String formatHexadecimal = "0x[A-F0-9]{1,}";
		String formatData = "\\d{1,2}/\\d{1,2}/\\d{2,4}";
		
		if (contingut.matches(formatEnter))
			return 'E';
		else if (contingut.matches(formatDecimal))
			return 'N';
		else if (contingut.matches(formatBinari))
			return 'B';
		else if (contingut.matches(formatHexadecimal))
			return 'H';
		else if (contingut.matches(formatData))
		{
			Date data = null;
			try {
				data = DateFormat.getDateInstance(DateFormat.SHORT).parse(contingut);
			} catch (ParseException e) { }
			
			Calendar calendari = Calendar.getInstance();
			calendari.setTime(data);
			
			String[] elements = contingut.split("/");
			
			int dia = Integer.parseInt(elements[0]);
			int mes = Integer.parseInt(elements[1]);
			int any = Integer.parseInt(elements[2]);
			
			boolean traspas = false;
			
		    if (any % 4 == 0)
		    	if (any % 100 == 0) { if (any % 400 == 0) traspas = true; }
		    	else traspas = true;
		    
		    int minDia = calendari.getMinimum(Calendar.DAY_OF_MONTH);
			int maxDia;
			if (mes == 2)
			{
				if (traspas) maxDia = 29;
				else maxDia = 28;
			}
			else if (mes == 4 || mes == 6 || mes == 9 || mes == 11)
				maxDia = 30;
			else maxDia = calendari.getMaximum(Calendar.DAY_OF_MONTH);
			int minMes = (calendari.getMinimum(Calendar.MONTH) + 1);
			int maxMes = (calendari.getMaximum(Calendar.MONTH) + 1);
			int minAny = calendari.getMinimum(Calendar.YEAR);
			
			if (dia >= minDia && dia <= maxDia && mes >= minMes && mes <= maxMes && any >= minAny)
				return 'D';
		}

		return 'T';
	}
	
	public ArrayList<String> valorsDelText (String text) throws FuncioNoAplicable
	{
		ArrayList<String> valors;
		valors = new ArrayList<String>();
		
		String[] v = text.split(";");
		
		for (int i = 0; i < v.length; ++i)
		{
			if (v[i].length() > 0)
			{
				String valor = new String(v[i]).trim();
				
				char t = checkTipus(valor);	
				if (t == 'N' || t == 'E')
				{
					if (t == 'N' && valor.matches("-{0,1}\\d{1,},\\d{1,}"))
					{
						String[] coma = valor.split(",");
						valor = coma[0] + '.' + coma[1];
					}
					valors.add(valor);
				}
				else throw new FuncioNoAplicable("La dada " + v[i] + " no es un numero.");
			}
		}
		
		return valors;
	}
	
	
	/* Creadora d'una nova subclasse que coincideixi amb el tipus (canviant) de Dada */
	private void creaDadaConcreta ()
	{
		if (this.tipus == 'D') data = new Data(cella, contingut, formula);
		else if (this.tipus == 'T') text = new Text(cella, contingut, formula);
		else if (this.tipus == 'E' || this.tipus == 'N' || this.tipus == 'B' || this.tipus == 'H') numerica = new Numerica(cella, contingut, formula);
	}

	/* Funcions de truncament */
	public String numericaTruncament (String tipus) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + ')');
		
		creaDadaConcreta();
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N') setContingut(numerica.numericaTruncament(tipus));
		else throw new FuncioNoAplicable("No es pot truncar una dada a enter que no sigui decimal: has introduit " + getTipus() + "."); 
			
		return contingut;
	}
	
	public String numericaTruncament (String tipus, int decimal) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + decimal + ')');
		
		creaDadaConcreta();
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N') setContingut(numerica.numericaTruncament(tipus, decimal));
		else throw new FuncioNoAplicable("No es pot truncar una dada que no sigui decimal: has introduit " + getTipus() + "."); 
			
		return contingut;
	}
	
	/* Funcions de conversio */
	public String numericaConversio (String tipus) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + ')');
		
		creaDadaConcreta();
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N') setContingut(numerica.numericaConversio(tipus));
		else throw new FuncioNoAplicable("No es pot convertir una dada que no sigui decimal: has introduit " + getTipus() + "."); 
			
		return contingut;
	}
	
	public String numericaConversio (String tipus, char nou) throws FuncioNoAplicable
	{	
		setFormula('=' + tipus + '(' + nou + ')');
		
		creaDadaConcreta();
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'E' || this.tipus == 'B' || this.tipus == 'H') setContingut(numerica.numericaConversio(tipus, nou));
		else throw new FuncioNoAplicable("No es pot convertir una dada que no sigui entera, binaria o hexadecimal: has introduit " + getTipus() + "."); 
			
		return contingut;
	}
	
	/* Funcions unaries */
	public String unaria (String tipus) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + ')');
		
		creaDadaConcreta();
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N' || this.tipus == 'E') setContingut(numerica.unaria(tipus));
		else throw new FuncioNoAplicable("No es pot calcular el valor absolut d'una dada que no sigui decimal o entera: has introduit " + getTipus() + ".");
		
		return contingut;
	}
	
	public String unaria (String tipus, int valor) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + valor + ')');
		
		creaDadaConcreta();
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N'|| this.tipus == 'E') setContingut(numerica.unaria(tipus, valor));
		else throw new FuncioNoAplicable("No es pot aplicar una operacio unaria a una dada que no sigui decimal o entera: has introduit " + getTipus() + ".");
		
		return contingut;
	}
	
	/* Funcions n-aries */
	public String naria (String tipus, String n) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + n + ')');
		
		setTipus('N');
		creaDadaConcreta();
		
		setContingut(numerica.naria(tipus, n));
			//No s'activa l'excepcio FuncioNoAplicable perque si s'introdueix cap altre tipus de dada sera ignorat per l'operacio
		
		return contingut;
	}
	
	/* Funcions de data */
	public String data (String tipus) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + ')');
		
		creaDadaConcreta();
		
			//Si el tipus de la dada no coincideix amb Data (D) salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'D')	setContingut(data.data(tipus));
		else throw new FuncioNoAplicable("No es pot aplicar una operacio de data a una dada que no sigui una data: has introduit " + getTipus() + ".");
		
		return contingut;
	}
	
	public String data (String tipus, char instant) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + instant + ')');
		
		creaDadaConcreta();
			
			//Si el tipus de la dada no coincideix amb Data (D) salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'D')	setContingut(data.data(tipus, instant));
		else throw new FuncioNoAplicable("No es pot aplicar una operacio de data a una dada que no sigui una data: has introduit " + getTipus() + ".");
		
		return contingut;
	}
	
	/* Funcions de substitucio */
	public String textSubstituir(String tipus, char canvi) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + canvi + ')');
		
		creaDadaConcreta();
		
			//Si el tipus de la dada no coincideix amb Text (T) salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'T') setContingut(text.textSubstituir(tipus, canvi));
		else throw new FuncioNoAplicable("No es pot modificar text d'una dada que no sigui un text: has introduit " + getTipus() + ".");
		
		return contingut;
	}
	
	public String textSubstituir(String tipus, String vell, String nou) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + vell + '|' + nou + ')');
		
		creaDadaConcreta();
		
			//Si el tipus de la dada no coincideix amb Text (T) salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'T') setContingut(text.textSubstituir(tipus, vell, nou));
		else throw new FuncioNoAplicable("No es pot substituir text d'una dada que no sigui un text: has introduit " + getTipus() + ".");
		
		return contingut;
	}
	
	/* Funcions de longitud */
	public String textLongitud(String tipus) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + ')');
		
		creaDadaConcreta();
		
		if (this.tipus == 'T') setContingut(text.textLongitud(tipus));
		else throw new FuncioNoAplicable("No es poden comptar els caracters d'una dada que no sigui un text: has introuit "+ getTipus() + ".");
		
		return contingut;
	}
	
	public String textLongitud(String tipus, String recompte) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + recompte + ')');
		
		creaDadaConcreta();
		
		if (this.tipus == 'T') setContingut(text.textLongitud(tipus, recompte));
		else throw new FuncioNoAplicable("No es poden comptar les coincidencies d'una dada que no sigui un text: has introuit "+ getTipus() + ".");
		
		return contingut;
	}
	
	/* Funcions d'estadistica */
	public String estadistica(String tipus, String n) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + n + ')');
		
		setTipus('N');
		creaDadaConcreta();
		
		setContingut(numerica.estadistica(tipus, n));
			//No s'activa l'excepcio FuncioNoAplicable perque si s'introdueix cap altre tipus de dada sera ignorat per l'operacio
		
		return contingut;
	}
	
	public String estadistica(String tipus, String n, String m) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + n + '|' + m + ')');
		
		setTipus('N');
		creaDadaConcreta();
		
		setContingut(numerica.estadistica(tipus, n, m));
			//No s'activa l'excepcio FuncioNoAplicable perque si s'introdueix cap altre tipus de dada sera ignorat per l'operacio
		
		return contingut;
	}
	
	/* Atributs de Dada */
	private Cella cella;
		//Cella a la qual s'associa la dada
	private Numerica numerica;
	private Data data;
	private Text text;
		//Instancies de les possibles subclasses de la dada
	private String contingut;
		//Conjunt de caracters d'una cella sobre el qual s'opera
	private char tipus;
		//Text (T), Enter (E), Decimal (N), Binari (B), Hexadecimal (H), Data (D)
	private String formula;
}