package Dominio;

import java.util.ArrayList;

public class Text extends Dada {
	public Text (Cella casella, String contingut, String formula) {
		super(casella, contingut, formula);
	}
	
	/* Funcions de substitucio */
	public String textSubstituir(String tipus, char canvi) {
		if (tipus.equals("MINMAJ"))
		{								
			String minMAJ = new String(getContingut());
			
				//Si s'introdueix 'M' com a canvi el text passa a ser tot en maj�scules
			if (canvi == 'M') minMAJ = getContingut().toUpperCase();
			else if (canvi == 'm') minMAJ = getContingut().toLowerCase();
				//Si s'introdueix 'm' com a canvi el text passa a ser tot en min�scules
			
			return minMAJ;
		}
		
		return getContingut();
	}
	
	public String textSubstituir(String tipus, String vell, String nou) {
		if (tipus.equals("REECAR"))
		{				
				//Es reemplacen els fragments que coincideixin amb vell pel fragment nou
			String substitut = getContingut().replace(vell, nou);
			return substitut;
		}
		
		return getContingut();
	}
	
	/* Funcions de longitud */
	public String textLongitud(String tipus) {
		if (tipus.equals("NUMCAR"))
				//Es retorna la longitud en caracters del text
			return (""+getContingut().length());
		
		return getContingut();
	}
	
	public String textLongitud(String tipus, String recompte) {
		if (tipus.equals("NUMCON"))
		{
			int n = 0;
			int chunk = recompte.length();
			
				//Es compten les coincidencies amb el fragment recompte que hi ha al text
			for (int i = 0; (i + chunk - 1) < getContingut().length(); ++i)
			{				
					//Comportament: per al text [ABCDEFG] i el recompte [EF] els substrings generats seran [AB], [BC], [CD], [DE], [EF] i [FG]
				String segment = getContingut().substring(i, i+chunk);
				
				if (segment.equals(recompte)) ++n;
					//Si es troba una coincidencia, s'augmenta el comptador
			}
			
			return (""+n);
		}
		
		return getContingut();
	}
}
