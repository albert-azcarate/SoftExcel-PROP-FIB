 package Dominio;

public class Binaria extends Numerica {
	public Binaria (Cella casella, String contingut, String formula) {
		super(casella, contingut, formula);
	}

	public String numericaConversio (String tipus, char nou) throws FuncioNoAplicable {	
		if (tipus.equals("CONVBASE"))
		{
			int numConvertit;
			
				//Treu el "0b" del principi
			String valor = getContingut().substring(2, getContingut().length());
			
				//Es converteix el valor binari a enter (si s'indica E) o hexadecimal (H)
			if (nou == 'E')
			{
				numConvertit = Integer.parseInt(valor, 2);
				return (""+numConvertit);
			}
			else if (nou == 'H')
			{
				numConvertit = Integer.parseInt(valor, 2);
				return ("0x"+Integer.toHexString(numConvertit).toUpperCase());
			}
			else  throw new FuncioNoAplicable("No es pot convertir la dada al tipus: " + nou + ".");
				//En cas que s'hagi introduit un tipus incorrecte al qual convertir el valor enter, salta l'excepcio FuncioNoAplicable
		}
		
		return getContingut();
	}
}
