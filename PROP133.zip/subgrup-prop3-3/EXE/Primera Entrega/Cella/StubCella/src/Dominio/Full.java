package Dominio;

import java.util.*;

public class Full {
	public Full (int xAxis, int yAxis)
	{
		x = xAxis;
		y = yAxis;
		celles = new ArrayList<>(y);
		for(int i = 0; i < y; i++)
			celles.add(new ArrayList<Cella>());
		
		for (int i = 0; i < xAxis; ++i)
		{
			for (int j = 0; j < yAxis; ++j)
			{				
				Cella c = new Cella(j, i, this);
				celles.get(j).add(i, c);
			}
		}
	}
	
	public ArrayList<ArrayList<Cella>> getCelles(){
		return celles;
	}
	
	public void foli () {		
		for(int i = 0; i < x; i++) {
			for(int j = 0; j < y; j++) {
				System.out.printf("[");
				System.out.printf(" " + celles.get(i).get(j).getDada().getContingut() + " " + celles.get(i).get(j).getDada().getTipus() + " ");
				System.out.printf("]");
			}
			System.out.println();
		}
	}
	
	private int x;

	private int y;
	
	private ArrayList<ArrayList<Cella>> celles;
}
