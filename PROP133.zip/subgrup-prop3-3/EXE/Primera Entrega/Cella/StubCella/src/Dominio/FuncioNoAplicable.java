package Dominio;

public class FuncioNoAplicable extends Exception {
	public FuncioNoAplicable (String missatge)
	{
		super(missatge);
	}
}