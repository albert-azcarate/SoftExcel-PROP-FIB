public class Cella {
	
	private int coordCol, coordRow;
	private String contingut, formula;
	private char tipus;
	private int color;
	private boolean bold, italics, underline, condicional;
	
	/* Funcions de truncament */
	public void numericaTruncament (String tipus) {
		if (tipus == "TRUNCDEC")
		{
			
		}
		else if (tipus == "TRUNCINT")
		{
			
		}
		else if (tipus == "TRUNCNOT")
		{
			System.out.printf("Opcional :)");
		}
	}
	
	/* Funcions de conversi� */
	public void numericaConversio (String tipus) {
		if (tipus == "CONVDEC")
		{
			
		}
		else if (tipus == "CONVRAD")
		{
			System.out.printf("Opcional :)");
		}
		else if (tipus == "CONVBASE")
		{
			
		}
	}
	
	/* Funcions un�ries */
	public void unaria (String tipus) {
		if (tipus == "INC")
		{
			
		}
		else if (tipus == "ABS")
		{
			
		}
		else if (tipus == "LOG")
		{
			System.out.printf("Opcional :)");
		}
	}
	
	/* Funcions n-�ries */
	public void naria (String tipus, Vector<char> n) {
		if (tipus == "SUM")
		{
			
		}
		else if (tipus == "RES")
		{
			
		}
		else if (tipus == "MUL")
		{
			
		}
		else if (tipus == "DIV")
		{
			
		}
	}
	
	/* Funcions de data */
	public var data (String tipus, String op, Data d) {
		return;
	}
	
	/* Funcions de reempla�ament */
	public String textReempla�ament(String tipus, String vell, String nou) {
		return;
	}
	
	/* Funcions de longitud */
	public int textLongitud(String tipus, Data d) {
		return;
	}
	
	/* Funcions d'estad�stica */
	public var estadistica(String tipus, var n) {
		return;
	}
	
	/* */
	public 
}
