package main;
import java.util.Scanner;

import Dominio.*;

public class main {
	public static void main(String[] args) {
		Full f = new Full(10, 10);
		
		String input;
		Scanner scanner = new Scanner(System.in);
		
		int i = 0;
		int j = 0;
		
		while(true)
		{
			input = scanner.next();
			
			if (input.charAt(0) == '=')
			{
					//S'obte l'expressio sense el tipus d'operacio (de longitud variable) ni el ')'
				String formula = new String(input.substring(1, input.length() - 1));
					//S'extreu el '('
				String[] indicador = formula.split("\\(");
				formula = new String(indicador[0]);
				
				switch (formula)
				{
					case "TRUNCDEC":
						try {
							f.getCelles().get(i).get(j).getDada().numericaTruncament(formula, Integer.parseInt(indicador[1]));
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "TRUNCINT":
						try {
							f.getCelles().get(i).get(j).getDada().numericaTruncament(formula);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "CONVDEC":
						try {
							f.getCelles().get(i).get(j).getDada().numericaConversio(formula);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "CONVBASE":
						try {
							f.getCelles().get(i).get(j).getDada().numericaConversio(formula, indicador[1].charAt(0));
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "INC":
						try {
							f.getCelles().get(i).get(j).getDada().unaria(formula, Integer.parseInt(indicador[1]));
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "ABS":
						try {
							f.getCelles().get(i).get(j).getDada().unaria(formula);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						catch (ArrayIndexOutOfBoundsException a) { }
						f.foli();
						break;
					case "SUM":
						try {
							f.getCelles().get(i).get(j).getDada().naria(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "RES":
						try {
							f.getCelles().get(i).get(j).getDada().naria(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "MUL":
						try {
							f.getCelles().get(i).get(j).getDada().naria(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "DIV":
						try {
							f.getCelles().get(i).get(j).getDada().naria(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "DATELEM":
						try {
							f.getCelles().get(i).get(j).getDada().data(formula, indicador[1].charAt(0));
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "DATADIA":
						try {
							f.getCelles().get(i).get(j).getDada().data(formula);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "REECAR":
						if (indicador[1].contains("|"))
						{
							indicador = indicador[1].split("\\|");
							try {
								f.getCelles().get(i).get(j).getDada().textSubstituir(formula, indicador[0], indicador[1]);
							}
							catch (FuncioNoAplicable fna) {
								fna.getMessage();
							}
						}
						f.foli();
						break;
					case "MINMAJ":
						try {
							f.getCelles().get(i).get(j).getDada().textSubstituir(formula, indicador[1].charAt(0));
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "NUMCAR":
						try {
							f.getCelles().get(i).get(j).getDada().textLongitud(formula);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "NUMCON":
						try {
							f.getCelles().get(i).get(j).getDada().textLongitud(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "MIT":
						try {
							f.getCelles().get(i).get(j).getDada().estadistica(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "MED":
						try {
							f.getCelles().get(i).get(j).getDada().estadistica(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "VAR":
						try {
							f.getCelles().get(i).get(j).getDada().estadistica(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "COVAR":
						if (indicador[1].contains("|"))
						{
							indicador = indicador[1].split("\\|");
							try {
								f.getCelles().get(i).get(j).getDada().estadistica(formula, indicador[0], indicador[1]);
							}
							catch (FuncioNoAplicable fna) {
								fna.getMessage();
							}
						}
						f.foli();
						break;
					case "STDEV":
						try {
							f.getCelles().get(i).get(j).getDada().estadistica(formula, indicador[1]);
						}
						catch (FuncioNoAplicable fna) {
							fna.getMessage();
						}
						f.foli();
						break;
					case "PEARSON":
						if (indicador[1].contains("|"))
						{
							indicador = indicador[1].split("\\|");
							try {
								f.getCelles().get(i).get(j).getDada().estadistica(formula, indicador[0], indicador[1]);
							}
							catch (FuncioNoAplicable fna) {
								fna.getMessage();
							}
						}
						f.foli();
						break;
					default:
						break;
				}
			}	
			else
			{
					String comprovacio = new String(""+input.charAt(0)+input.charAt(1));
					String entrada = "";
					int x = 0;
					int y = 0;
					
					if (comprovacio.equals("ES") || comprovacio.equals("CO"))
					{
						input = new String(input.substring(0, input.length() - 1));
						String[] valor = input.split("\\(");
						input = new String(valor[0]);
						entrada = new String(valor[1]);
						
						if (comprovacio.equals("CO"))
						{
							valor = entrada.split(",");
						    
						    x = Integer.parseInt(valor[0]);
						    y = Integer.parseInt(valor[1]);
						}
					}
					
					switch (input)
					{
						case "LLEGIR":
							f.foli();
							break;
						case "ESCRIU":
							f.getCelles().get(i).get(j).getDada().setContingut(entrada);
							f.foli();
							break;
						case "COORD":
							i = x;
							j = y;
							break;
						case "EXIT":
							System.exit(0);
						default:
							break;
					}
			}
		}
	}
}