package test;

import Dominio.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


/* 								***IMPORTANT***
 * 					Mai tindrem contingut de cel�la = null;
 * Quan volem representar una cel�la buida, es representa amb "", no amb null.
*/
public class CellaTest {
	Cella cell;
	Full f = new Full(10,10);
	@Before
	public void SetUp() {
		cell = new Cella(0, 0, f);
	}
	
	@Test
	public void CreationTest()
	{
		cell = new Cella(0,0, f);
	}
	
	@Test
	public void CreationCopiedTest()
	{
		cell = new Cella(0,0,f);
		
		cell.getDada().setContingut("Copied test");
		cell.setColor(120120);
		
		Cella tested = new Cella(cell);
		assertEquals("Hauria de retornar:", cell.getDada().getContingut(), tested.getDada().getContingut());
		assertEquals("Hauria de retornar:", cell.getColor(), tested.getColor());
		assertEquals("Hauria de retornar:", cell.getDada().getTipus(), tested.getDada().getTipus());
	}
	
	@Test
	public void settersIGetters()
	{
		cell = new Cella(0,0,f);
		
		assertEquals("Hauria de retornar: ", 0, cell.getRows());
		assertEquals("Hauria de retornar: ", 0, cell.getCols());
		
		cell.setDada("", "");
		assertEquals("Hauria de retornar: ", "", cell.getDada().getContingut());
		assertEquals("Hauria de retornar: ", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("patata");
		assertEquals("Hauria de retornar:", "patata", cell.getDada().getContingut());
		
		cell.setColor(450062);
		assertEquals("Hauria de retornar: ", 450062, cell.getColor());
		
		cell.setFormatBold(false);
		assertEquals("Hauria de retornar: ", false, cell.getFormatBold());
		cell.setFormatBold(true);
		assertEquals("Hauria de retornar: ", true, cell.getFormatBold());
		
		cell.setFormatItalics(false);
		assertEquals("Hauria de retornar: ", false, cell.getFormatItalics());
		cell.setFormatItalics(true);
		assertEquals("Hauria de retornar:", true, cell.getFormatItalics());
		
		cell.setFormatUnderline(false);
		assertEquals("Hauria de retornar: ", false, cell.getFormatUnderline());
		cell.setFormatUnderline(true);
		assertEquals("Hauria de retornar: ", true, cell.getFormatUnderline());
		
		cell.getDada().setTipus('T');
		assertEquals("Hauria de retornar: ", 'T', cell.getDada().getTipus());
		
		cell.setFormatConditional(false);
		assertEquals("Hauria de retornar: ", false, cell.getFormatConditional());
		cell.setFormatConditional(true);
		assertEquals("Hauria de retornar: ", true, cell.getFormatConditional());
		
		cell.getDada().setFormula("=SUM(A1,A3)");
		assertEquals("Hauria de retornar: ", "=SUM(A1,A3)", cell.getDada().getFormula());
		
		cell.setFull(f);
		assertEquals("Hauria de retornar: ", f, cell.getFull());
	}
	
	@Test
	public void esborraTest()
	{
		cell = new Cella(4,2, f);
		cell.getDada().setContingut("patata");
		cell.setColor(450062);
		cell.setFormatBold(true);
		cell.getDada().setTipus('N');
		
		cell.esborrarContingut();
		
		assertEquals("Hauria de retornar:", 4, cell.getCols());
		assertEquals("Hauria de retornar:", 2, cell.getRows());
		assertEquals("Hauria de retornar:", "", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", 0, cell.getColor());
		assertEquals("Hauria de retornar:", false, cell.getFormatBold());
		assertEquals("Hauria de retornar:", false, cell.getFormatItalics());
		assertEquals("Hauria de retornar:", false, cell.getFormatUnderline());
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		assertEquals("Hauria de retornar:", "", cell.getDada().getFormula());
	}
	
	@Test
	public void checkTipus()
	{
		cell = new Cella(0, 0, f);
		cell.getDada().setContingut("");
		assertEquals("Hauria de retornar:", "", cell.getDada().getContingut());
		
		cell.getDada().setContingut("MarvelStudios");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("100");
		assertEquals("Hauria de retornar:", 'E', cell.getDada().getTipus());
		
		cell.getDada().setContingut("-25");
		assertEquals("Hauria de retornar:", 'E', cell.getDada().getTipus());
		
		cell.getDada().setContingut("-2.57");
		assertEquals("Hauria de retornar:", 'N', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1.618");
		assertEquals("Hauria de retornar:", 'N', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1.6.18");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1,618");
		assertEquals("Hauria de retornar:", 'N', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1,6,18");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("A1");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1/02/2024");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("31/01/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("31/12/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("30/04/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("30/06/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("30/09/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("30/11/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("28/02/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("29/02/2024");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1/1/0001");
		assertEquals("Hauria de retornar:", 'D', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0b101110");
		assertEquals("Hauria de retornar:", 'B', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0x45AB");
		assertEquals("Hauria de retornar:", 'H', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0bA7");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0xPCH");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0xabcd");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0x-1111");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0b");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0x");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("Home/Dona");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("Ho/Do/NA");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("/");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1//1000//1");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("29886/01/05");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("0/02/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("30/02/4400");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("29/02/0200");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("29/02/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("31/04/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("32/05/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1/0/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1/13/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("1/1/0000");
		assertEquals("Hauria de retornar:", 'T', cell.getDada().getTipus());
		
		cell.getDada().setContingut("");
		assertEquals("Hauria de retornar:", "", cell.getDada().getContingut());
	}
	
	@Test
	public void numTrunc() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		cell.getDada().setContingut("0");
		try { cell.getDada().numericaTruncament("TRUNCINT"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0.0");
		cell.getDada().numericaTruncament("TRUNCINT");
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.5");
		cell.getDada().numericaTruncament("TRUNCINT");
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-2.75");
		cell.getDada().numericaTruncament("TRUNCINT");
		assertEquals("Hauria de retornar:", "-2", cell.getDada().getContingut());
		
		// No v�lid per a truncament:
		cell.getDada().setContingut("test");
		try { cell.getDada().numericaTruncament("TRUNCINT"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "test", cell.getDada().getContingut());
		
		cell.getDada().setContingut("125.575");
		cell.getDada().numericaTruncament("INCORRECT OPTION HERE");
		assertEquals("Hauria de retornar:", "125.575", cell.getDada().getContingut());
	}
	
	@Test
	public void numTruncDec() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		// TRUNCDEC Testing:
		cell.getDada().setContingut("0");
		try { cell.getDada().numericaTruncament("TRUNCDEC", 1); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("123.55");
		cell.getDada().numericaTruncament("TRUNCDEC", 1);
		assertEquals("Hauria de retornar:", "123.5", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.5");
		cell.getDada().numericaTruncament("TRUNCDEC", 0);
		assertEquals("Hauria de retornar:", "1.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.54321");
		cell.getDada().numericaTruncament("TRUNCDEC", 3);
		assertEquals("Hauria de retornar:", "1.543", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-2.75");
		cell.getDada().numericaTruncament("TRUNCDEC", 0);
		assertEquals("Hauria de retornar:", "-2.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("test");
		try { cell.getDada().numericaTruncament("TRUNCDEC", 10); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "test", cell.getDada().getContingut());
		
		cell.getDada().setContingut("125.575");
		cell.getDada().numericaTruncament("TRUNCEC", 10);
		assertEquals("Hauria de retornar:", "125.575", cell.getDada().getContingut());
	}
	
	@Test
	public void conversi�Decimal() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		// CONVDEC Testing:
		cell.getDada().setContingut("1.0");
		cell.getDada().numericaConversio("CONVDC");
		assertEquals("Hauria de retornar:", "1.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().numericaConversio("CONVDEC"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1");
		try { cell.getDada().numericaConversio("CONVDEC"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-1");
		try { cell.getDada().numericaConversio("CONVDEC"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "-1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("3,14156593");
		cell.getDada().numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "3.14156593", cell.getDada().getContingut());
		
		cell.getDada().setContingut("3.14156593");
		cell.getDada().numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "3,14156593", cell.getDada().getContingut());
		
		cell.getDada().setContingut("3.14156593");
		cell.getDada().numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "3,14156593", cell.getDada().getContingut());
		cell.getDada().numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "3.14156593", cell.getDada().getContingut());
	}
	
	@Test
	public void numConversio() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		// Decimal a binari / hexa:
		cell.getDada().setContingut("1");
		cell.getDada().numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1");
		cell.getDada().numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0x1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("67");
		cell.getDada().numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b1000011", cell.getDada().getContingut());
		
		cell.getDada().setContingut("67");
		cell.getDada().numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0x43", cell.getDada().getContingut());
		
		cell.getDada().setContingut("10");
		cell.getDada().numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0xA", cell.getDada().getContingut());
		
		
		// Binari a hexa / decimal:
		cell.getDada().setContingut("0b1");
		cell.getDada().numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0x1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0b1");
		cell.getDada().numericaConversio("CONVBASE", 'E');
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0b11011");
		cell.getDada().numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0x1B", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0b11011");
		cell.getDada().numericaConversio("CONVBASE", 'E');
		assertEquals("Hauria de retornar:", "27", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0b1111");
		cell.getDada().numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0xF", cell.getDada().getContingut());
		
		// Hexa a binari / decimal:
		cell.getDada().setContingut("0x1");
		cell.getDada().numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0x1");
		cell.getDada().numericaConversio("CONVBASE", 'E');
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0xA3");
		cell.getDada().numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b10100011", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0xA3");
		cell.getDada().numericaConversio("CONVBASE", 'E');
		assertEquals("Hauria de retornar:", "163", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0xF");
		cell.getDada().numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b1111", cell.getDada().getContingut());
		
		// Casos especials:
		cell.getDada().setContingut("test");
		try { cell.getDada().numericaConversio("CONVBASE", 'H'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "test", cell.getDada().getContingut());
		
		cell.getDada().setContingut("25.75");
		try { cell.getDada().numericaConversio("CONVBASE", 'B'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "25.75", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1");
		cell.getDada().numericaConversio("INPUT INCORRECTE", 'H');
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1");
		try { cell.getDada().numericaConversio("CONVBASE", 'P'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0b1");
		try { cell.getDada().numericaConversio("CONVBASE", 'P'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "0b1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0x1");
		try { cell.getDada().numericaConversio("CONVBASE", 'P'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "0x1", cell.getDada().getContingut());
	}
	
	@Test
	public void testUnaria() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		// INC Testing:
		cell.getDada().setContingut("0");
		cell.getDada().unaria("NC", 0);
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0");
		cell.getDada().unaria("INC", 0);
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-15");
		cell.getDada().unaria("INC", 1);
		assertEquals("Hauria de retornar:", "-14", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.5");
		cell.getDada().unaria("INC", 1);
		assertEquals("Hauria de retornar:", "2.5", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-2.25");
		cell.getDada().unaria("INC", 4);
		assertEquals("Hauria de retornar:", "1.75", cell.getDada().getContingut());
		
		cell.getDada().setContingut("test");
		try { cell.getDada().unaria("INC", 10); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "test", cell.getDada().getContingut());
		
		// ABS Testing:
		cell.getDada().setContingut("0");
		cell.getDada().unaria("AB");
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0");
		cell.getDada().unaria("ABS");
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-15");
		cell.getDada().unaria("ABS");
		assertEquals("Hauria de retornar:", "15", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.5");
		cell.getDada().unaria("ABS");
		assertEquals("Hauria de retornar:", "1.5", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-2.25");
		cell.getDada().unaria("ABS");
		assertEquals("Hauria de retornar:", "2.25", cell.getDada().getContingut());
		
		cell.getDada().setContingut("test");
		try { cell.getDada().unaria("ABS"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "test", cell.getDada().getContingut());
	}
	
	@Test
	public void testNaries() throws FuncioNoAplicable
	{
		//SUM, RES, MUL, DIV
		cell = new Cella(0,0,f);
		Cella cell2 = new Cella(0,1,f);
		
		/* 						***IMPORTANT***
		 * 
		 *  Per raons de normalitzacio, les operacions amb decimals
		 *  sempre converteixen el simbol decimal a un punt.
		 *  
		 */
		
		cell.getDada().setContingut("");
		try { cell.getDada().naria("SUM", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0");
		try { cell.getDada().naria("SUM", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		// SUM Testing:
		cell.getDada().setContingut("0");
		cell2.getDada().setContingut("0");
		cell.getDada().naria("SUM", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15");
		cell2.getDada().setContingut("5");
		cell.getDada().naria("SUM", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "20", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15");
		cell2.getDada().setContingut("-5");
		cell.getDada().naria("SUM", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "10", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15.5");
		cell2.getDada().setContingut("5.5");
		cell.getDada().naria("SUM", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "21.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15,5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("SUM", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "21.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15.5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("SUM", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "21.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-15.5");
		cell2.getDada().setContingut("5.5");
		cell.getDada().naria("SUM", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-10.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-15.5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("SUM", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-10.0", cell.getDada().getContingut());
		
		// RES Testing:
		cell.getDada().setContingut("0");
		cell2.getDada().setContingut("0");
		cell.getDada().naria("RES", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15");
		cell2.getDada().setContingut("5");
		cell.getDada().naria("RES", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "10", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15");
		cell2.getDada().setContingut("-5");
		cell.getDada().naria("RES", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "20", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15.5");
		cell2.getDada().setContingut("5.5");
		cell.getDada().naria("RES", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "10.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15,5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("RES", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "10.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15.5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("RES", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "10.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-15.5");
		cell2.getDada().setContingut("5.5");
		cell.getDada().naria("RES", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-21.0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-15.5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("RES", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-21.0", cell.getDada().getContingut());
		
		// MUL Testing
		cell.getDada().setContingut("0");
		cell2.getDada().setContingut("0");
		cell.getDada().naria("MUL", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15");
		cell2.getDada().setContingut("5");
		cell.getDada().naria("MUL", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "75", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15");
		cell2.getDada().setContingut("-5");
		cell.getDada().naria("MUL", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-75", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15.5");
		cell2.getDada().setContingut("5.5");
		cell.getDada().naria("MUL", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "85.25", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15,5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("MUL", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "85.25", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15.5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("MUL", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "85.25", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-15.5");
		cell2.getDada().setContingut("5.5");
		cell.getDada().naria("MUL", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-85.25", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-15.5");
		cell2.getDada().setContingut("5,5");
		cell.getDada().naria("MUL", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-85.25", cell.getDada().getContingut());
		
		
		// DIV Testing:
		cell.getDada().setContingut("0");
		cell2.getDada().setContingut("1");
		cell.getDada().naria("DV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "0; 1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("0");
		cell2.getDada().setContingut("1");
		cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15");
		cell2.getDada().setContingut("5");
		cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "3", cell.getDada().getContingut());
		
		cell.getDada().setContingut("15");
		cell2.getDada().setContingut("-5");
		cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-3", cell.getDada().getContingut());
		
		cell.getDada().setContingut("555.5");
		cell2.getDada().setContingut("12.5");
		cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "44.44", cell.getDada().getContingut());
		
		cell.getDada().setContingut("555,5");
		cell2.getDada().setContingut("12,5");
		cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "44.44", cell.getDada().getContingut());
		
		cell.getDada().setContingut("555.5");
		cell2.getDada().setContingut("-12,5");
		cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-44.44", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-555.5");
		cell2.getDada().setContingut("12.5");
		cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-44.44", cell.getDada().getContingut());
		
		cell.getDada().setContingut("-555.5");
		cell2.getDada().setContingut("12,5");
		cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "-44.44", cell.getDada().getContingut());
		
		cell.getDada().setContingut("100");
		cell2.getDada().setContingut("0");
		try { cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "100", cell.getDada().getContingut());
		
		cell.getDada().setContingut("100");
		cell2.getDada().setContingut("3;5");
		try { cell.getDada().naria("DIV", cell.getDada().getContingut() + "; " + cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "100", cell.getDada().getContingut());
	}
	
	
	@Test
	public void dataTest() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		// DATADIA Testing:
		cell.getDada().setContingut("Text");
		try { cell.getDada().data("DATADA"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try { cell.getDada().data("DATADA"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell.getDada().data("DATADA");
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().data("DATADIA"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try{ cell.getDada().data("DATADIA"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dilluns", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/22");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dilluns", cell.getDada().getContingut());
		
		cell.getDada().setContingut("19/04/2022");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dimarts", cell.getDada().getContingut());
		
		cell.getDada().setContingut("19/04/22");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dimarts", cell.getDada().getContingut());
		
		cell.getDada().setContingut("20/04/2022");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dimecres", cell.getDada().getContingut());
		
		cell.getDada().setContingut("20/04/22");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dimecres", cell.getDada().getContingut());
		
		cell.getDada().setContingut("21/04/2022");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dijous", cell.getDada().getContingut());
		
		cell.getDada().setContingut("21/04/22");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dijous", cell.getDada().getContingut());
		
		cell.getDada().setContingut("22/04/2022");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Divendres", cell.getDada().getContingut());
		
		cell.getDada().setContingut("22/04/22");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Divendres", cell.getDada().getContingut());
		
		cell.getDada().setContingut("23/04/2022");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dissabte", cell.getDada().getContingut());
		
		cell.getDada().setContingut("23/04/22");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Dissabte", cell.getDada().getContingut());
		
		cell.getDada().setContingut("24/04/2022");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Diumenge", cell.getDada().getContingut());
		
		cell.getDada().setContingut("24/04/22");
		cell.getDada().data("DATADIA");
		assertEquals("Hauria de retornar:", "Diumenge", cell.getDada().getContingut());
		
		cell.getDada().setContingut("32/04/22");
		try { cell.getDada().data("DATADIA"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "32/04/22", cell.getDada().getContingut());
		
		// DATELEM Testing:
		cell.getDada().setContingut("Text");
		try{ cell.getDada().data("DATELM", 'C'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try{ cell.getDada().data("DATELM", 'C'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell.getDada().data("DATELM", 'C');
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().data("DATELM", 'D'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try { cell.getDada().data("DATELM", 'D'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell.getDada().data("DATELM", 'D');
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().data("DATELEM", 'D'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try { cell.getDada().data("DATELEM", 'D'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell.getDada().data("DATELEM", 'D');
		assertEquals("Hauria de retornar:", "18", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell.getDada().data("DATELEM", 'M');
		assertEquals("Hauria de retornar:", "4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/12/2022");
		cell.getDada().data("DATELEM", 'M');
		assertEquals("Hauria de retornar:", "12", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/0001");
		cell.getDada().data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/0010");
		cell.getDada().data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "10", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/0100");
		cell.getDada().data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "100", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell.getDada().data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/22");
		cell.getDada().data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell.getDada().data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/22");
		try { cell.getDada().data("DATELEM", 'C'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/22", cell.getDada().getContingut());
	}
	
	@Test
	public void substituirTest() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		// MINMAJ Testing:
		cell.getDada().setContingut("1234");
		try { cell.getDada().textSubstituir("MINMJ", 'A'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textSubstituir("MINMJ", 'A'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().textSubstituir("MINMJ", 'A'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try { cell.getDada().textSubstituir("MINMAJ", 'A'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textSubstituir("MINMAJ", 'A'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().textSubstituir("MINMAJ", 'A'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try { cell.getDada().textSubstituir("MINMAJ", 'M'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textSubstituir("MINMAJ", 'M'); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textSubstituir("MINMAJ", 'M');
		assertEquals("Hauria de retornar:", "TEXT", cell.getDada().getContingut());
		
		cell.getDada().setContingut("TEXT");
		cell.getDada().textSubstituir("MINMAJ", 'M');
		assertEquals("Hauria de retornar:", "TEXT", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textSubstituir("MINMAJ", 'm');
		assertEquals("Hauria de retornar:", "text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("text");
		cell.getDada().textSubstituir("MINMAJ", 'm');
		assertEquals("Hauria de retornar:", "text", cell.getDada().getContingut());
		
		// REECAR Testing:
		cell.getDada().setContingut("1234");
		try { cell.getDada().textSubstituir("REECR", "x", "s"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textSubstituir("REECR", "x", "s"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textSubstituir("REECR", "x", "s");
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try { cell.getDada().textSubstituir("REECAR", "x", "s"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textSubstituir("REECAR", "x", "s"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textSubstituir("REECAR", "x", "s");
		assertEquals("Hauria de retornar:", "Test", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textSubstituir("REECAR", "s", "x");
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
	}
	
	@Test
	public void longitudTest() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		// NUMCAR Testing:
		cell.getDada().setContingut("1234");
		try { cell.getDada().textLongitud("NUMCR"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textLongitud("NUMCR"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textLongitud("NUMCR");
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try { cell.getDada().textLongitud("NUMCAR"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textLongitud("NUMCAR"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textLongitud("NUMCAR");
		assertEquals("Hauria de retornar:", "4", cell.getDada().getContingut());
		
		// NUMCON Testing:
		cell.getDada().setContingut("1234");
		try { cell.getDada().textLongitud("NUMCN", "1"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textLongitud("NUMCN", "1"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textLongitud("NUMCN", "x");
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1234");
		try { cell.getDada().textLongitud("NUMCON", "1"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1234", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().textLongitud("NUMCON", "1"); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textLongitud("NUMCON", "x");
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell.getDada().textLongitud("NUMCON", "Text");
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
	}
	
	@Test
	public void estadisticaTest() throws FuncioNoAplicable
	{
		cell = new Cella(0,0,f);
		
		// MIT Testing:
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().estadistica("MT", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().estadistica("MT", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell.getDada().estadistica("MT", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().estadistica("MIT", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().estadistica("MIT", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;2;1;4");
		cell.getDada().estadistica("MIT", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "2", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;2;A;4");
		try { cell.getDada().estadistica("MIT", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1;2;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;2;A;4");
		try { cell.getDada().estadistica("MIT", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1.0;2;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;2;1.0;4");
		cell.getDada().estadistica("MIT", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "2.0", cell.getDada().getContingut());
		
		// MED Testing:
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().estadistica("MD", cell.getDada().getContingut());  } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().estadistica("MD", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell.getDada().estadistica("MD", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().estadistica("MED", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().estadistica("MED", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("2;5;7;-9;0");
		cell.getDada().estadistica("MED", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "2", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;2;8;4");
		cell.getDada().estadistica("MED", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "3", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;2;A;4");
		try { cell.getDada().estadistica("MED", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1;2;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;2;A;4");
		try { cell.getDada().estadistica("MED", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1.0;2;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;2;8.0;4");
		cell.getDada().estadistica("MED", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "3.0", cell.getDada().getContingut());
		
		// VAR Testing:
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().estadistica("VR", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().estadistica("VR", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell.getDada().estadistica("VR", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().estadistica("VAR", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().estadistica("VAR", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell.getDada().estadistica("VAR", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "2", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;A;4");
		try { cell.getDada().estadistica("VAR", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;A;4");
		try { cell.getDada().estadistica("VAR", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1.0;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;3;4");
		cell.getDada().estadistica("VAR", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "2.333333333333333", cell.getDada().getContingut());
		
		// STDEV Testing:
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().estadistica("STDV", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().estadistica("STDV", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell.getDada().estadistica("STDV", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		try { cell.getDada().estadistica("STDEV", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		try { cell.getDada().estadistica("STDEV", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell.getDada().estadistica("STDEV", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;A;4");
		try { cell.getDada().estadistica("STDEV", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;A;4");
		try { cell.getDada().estadistica("STDEV", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1.0;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;3;4");
		cell.getDada().estadistica("STDEV", cell.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1.5275252316519465", cell.getDada().getContingut());
		
		Cella cell2 = new Cella(0,1,f);
		
		// COVAR Testing:
		cell.getDada().setContingut("18/04/2022");
		cell2.getDada().setContingut("19/04/2022");
		try { cell.getDada().estadistica("COVR", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell2.getDada().setContingut("Text");
		try { cell.getDada().estadistica("COVR", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell2.getDada().setContingut("2;5;6");
		cell.getDada().estadistica("COVR", cell.getDada().getContingut(), cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell2.getDada().setContingut("19/04/2022");
		try { cell.getDada().estadistica("COVAR", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell2.getDada().setContingut("Text");
		try { cell.getDada().estadistica("COVAR", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell2.getDada().setContingut("2;5;6");
		cell.getDada().estadistica("COVAR", cell.getDada().getContingut(), cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "3", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell2.getDada().setContingut("2;5;6;7");
		try { cell.getDada().estadistica("COVAR", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1;3;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell2.getDada().setContingut("2;5;6");
		try { cell.getDada().estadistica("COVAR", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;A;4");
		cell2.getDada().setContingut("3;5;7");
		try { cell.getDada().estadistica("COVAR", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;A;4");
		cell2.getDada().setContingut("3;5;7.0");
		try { cell.getDada().estadistica("COVAR", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1.0;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;3;4");
		cell2.getDada().setContingut("3;5;7.0");
		cell.getDada().estadistica("COVAR", cell.getDada().getContingut(), cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "3.0", cell.getDada().getContingut());
		
		// PEARSON Testing:
		cell.getDada().setContingut("18/04/2022");
		cell2.getDada().setContingut("19/04/2022");
		try { cell.getDada().estadistica("PEARSN", cell.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell2.getDada().setContingut("Text");
		try { cell.getDada().estadistica("PEARSN", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell2.getDada().setContingut("2;5;6");
		cell.getDada().estadistica("PEARSN", cell.getDada().getContingut(), cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("18/04/2022");
		cell2.getDada().setContingut("19/04/2022");
		try { cell.getDada().estadistica("PEARSON", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell2.getDada().setContingut("Text");
		try { cell.getDada().estadistica("PEARSON", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell2.getDada().setContingut("2;5;6");
		cell.getDada().estadistica("PEARSON", cell.getDada().getContingut(), cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "1", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;3;4");
		cell2.getDada().setContingut("2;5;6;7");
		try { cell.getDada().estadistica("PEARSON", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1;3;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("Text");
		cell2.getDada().setContingut("2;5;6");
		try { cell.getDada().estadistica("PEARSON", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "Text", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1;A;4");
		cell2.getDada().setContingut("3;5;7");
		try { cell.getDada().estadistica("PEARSON", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;A;4");
		cell2.getDada().setContingut("3;5;7.0");
		try { cell.getDada().estadistica("PEARSON", cell.getDada().getContingut(), cell2.getDada().getContingut()); } catch (FuncioNoAplicable fna) {};
		assertEquals("Hauria de retornar:", "1.0;A;4", cell.getDada().getContingut());
		
		cell.getDada().setContingut("1.0;3;4");
		cell2.getDada().setContingut("3;5;7.0");
		cell.getDada().estadistica("PEARSON", cell.getDada().getContingut(), cell2.getDada().getContingut());
		assertEquals("Hauria de retornar:", "0.9819805060619659", cell.getDada().getContingut());
	}
	
	@Test
	public void formatTest()
	{
		cell = new Cella(0,0,f);
		
		// Bold Testing:
		cell.formatBold();
		assertEquals("Hauria de retornar:", true, cell.getFormatBold());
		
		// Italics Testing:
		cell.formatItalics();
		assertEquals("Hauria de retornar:", true, cell.getFormatItalics());
		
		// Underline Testing:
		cell.formatUnderline();
		assertEquals("Hauria de retornar:", true, cell.getFormatUnderline());
	}
}