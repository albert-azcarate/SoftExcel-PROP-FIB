package test;

import Dominio.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FullTest {
    Full f;

    @Before
    public void SetUp(){ f = new Full(10, 10); }

    @Test
    public void CreationTest()
    { 
    	f = new Full(10, 10); 
    	
    	 assertEquals("Hauria de retornar:", 10, f.getNumRows());
         assertEquals("Hauria de retornar:", 10, f.getNumColumns());
         assertEquals("Hauria de retornar:", "New Sheet", f.getNomFull());
    }

    @Test
    public void settersIGetters(){
        f = new Full(10, 10);

        assertEquals("Hauria de retornar:", 10, f.getNumRows());
        assertEquals("Hauria de retornar:", 10, f.getNumColumns());
        assertEquals("Hauria de retornar:", "New Sheet", f.getNomFull());

        f.nombrarFull("full 1");
        assertEquals("Hauria de retornar:", "full 1", f.getNomFull());
        
        f.getCella(0, 0).setContingut("test");
        Cella c = f.getCella(0, 0);
        assertEquals("Hauria de retornar:", "test", c.getContingut());
        
        c = f.getCella(125, 7911);
        assertNull("Hauria de ser null:", c);
    }

    @Test
    public void addRowTest(){
        f = new Full(10, 10);

        f.addRow(3);
        assertEquals("Hauria de retornar:", 11, f.getNumRows());

        f = new Full(10, 10);
        f.addRow(12);
        assertEquals("Hauria de retornar:", 10, f.getNumRows());
        
        f = new Full(10, 10);
        f.addRow(-1);
        assertEquals("Hauria de retornar:", 10, f.getNumRows());

    }

    @Test
    public void addColTest(){
        f = new Full(10, 10);

        f.addCol(3);
        assertEquals("Hauria de retornar:", 11, f.getNumColumns());

        f = new Full(10, 10);
        f.addCol(12);
        assertEquals("Hauria de retornar:", 10, f.getNumColumns());

        f = new Full(10, 10);
        f.addCol(-1);
        assertEquals("Hauria de retornar:", 10, f.getNumColumns());
    }

    @Test
    public void addRowSetTest(){
        f = new Full(10, 10);

        f.addRowSet(3, 5);
        assertEquals("Hauria de retornar:", 15, f.getNumRows());

        f = new Full(10, 10);
        f.addRowSet(15, 5);
        assertEquals("Hauria de retornar:", 10, f.getNumRows());

    }

    @Test
    public void addColSetTest(){
        f = new Full(10, 10);

        f.addColSet(3, 5);
        assertEquals("Hauria de retornar:", 15, f.getNumColumns());

        f = new Full(10, 10);
        f.addColSet(15, 5);
        assertEquals("Hauria de retornar:", 10, f.getNumColumns());

    }

    @Test
    public void deleteRowTest(){
        f = new Full(10, 10);

        f.deleteRow(3);
        assertEquals("Hauria de retornar:", 9, f.getNumRows());

        f = new Full(10, 10);
        f.deleteRow(12);
        assertEquals("Hauria de retornar:", 10, f.getNumRows());

    }

    @Test
    public void deleteColTest(){
        f = new Full(10, 10);

        f.deleteCol(3);
        assertEquals("Hauria de retornar:", 9, f.getNumColumns());

        f = new Full(10, 10);
        f.deleteCol(12);
        assertEquals("Hauria de retornar:", 10, f.getNumColumns());

    }

    @Test
    public void deleteRowSetTest(){
        f = new Full(10, 10);

        f.deleteRowSet(3, 5);
        assertEquals("Hauria de retornar:", 5, f.getNumRows());

        f = new Full(10, 10);
        f.deleteRowSet(15, 5);
        assertEquals("Hauria de retornar:", 10, f.getNumRows());

        f = new Full(10, 10);
        f.deleteRowSet(8, 5);
        assertEquals("Hauria de retornar:", 8, f.getNumRows());

    }

    @Test
    public void deleteColSetTest(){
        f = new Full(10, 10);

        f.deleteColSet(3, 5);
        assertEquals("Hauria de retornar:", 5, f.getNumColumns());

        f = new Full(10, 10);
        f.deleteColSet(15, 5);
        assertEquals("Hauria de retornar:", 10, f.getNumColumns());

        f = new Full(10, 10);
        f.deleteColSet(8, 5);
        assertEquals("Hauria de retornar:", 8, f.getNumColumns());

    }

    @Test
    public void modificarCotinguts(){
        f = new Full(5, 5);

        f.modificarContinguts("hola");
        for(int i = 0; i < f.getNumColumns(); i++) {
            for(int j = 0; j < f.getNumRows(); j++) {
                assertEquals("Hauria de retornar:", "hola", f.getCelles().get(i).get(j).getContingut());
            }
        }

    }

    @Test
    public void desfer(){
        f = new Full(10,  10);
        f.getCelles().get(5).get(2).setContingut("hola");
        f.desfes();
        assertEquals("Hauria de retornar:", "", f.getCelles().get(5).get(2).getContingut());
        f.desfes();
        assertEquals("Hauria de retornar:", "", f.getCelles().get(5).get(2).getContingut());
    }

    @Test
    public void refer(){
        f = new Full(10,  10);
        f.getCelles().get(5).get(2).setContingut("hola");
        f.desfes();
        f.refer();
        assertEquals("Hauria de retornar:", "hola", f.getCelles().get(5).get(2).getContingut());
        f.refer();
        assertEquals("Hauria de retornar:", "hola", f.getCelles().get(5).get(2).getContingut());
    }
    
    @Test
    public void testPrint()
    {
    	f = new Full(10,  10);
    	f.print();
    	System.out.println();
    	f.getCelles().get(5).get(2).setContingut("hola");
    	f.print();
    }
    
    @Test
    public void modificarCotingutsCelles(){
        f = new Full(5, 5);

        f.modificarContinguts("hola", 2, 3, 4, 4);
        for(int i = 2; i < 4; i++) {
            for(int j = 3; j < 4; j++) {
                assertEquals("Hauria de retornar:", "hola", f.getCelles().get(i).get(j).getContingut());
            }
        }
    }
    
    @Test
    public void modificarCella() {
    	f = new Full(10, 10);
    	
    	f.modificarCella("hola", 2, 2);
    	assertEquals("Hauria de retornar:", "hola", f.getCelles().get(2).get(2).getContingut());
    	
    	f.modificarCella("hola", 1000, 2); 
    	// Imprimeix l'excepció corresponent i no fa res.
    	
    	f.modificarCella("hola", -1, 2);
    	// Imprimeix l'excepció corresponent i no fa res.
    }

}
