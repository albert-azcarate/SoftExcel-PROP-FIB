package test;

import Dominio.*;

import static org.junit.Assert.*;

//import java.util.ArrayList;

import org.junit.*;

//import org.junit.runners.*;
import org.junit.Test;

public class DocTest {
	Document doc;
	@Before
	public void SetUp() {
		doc = new Document();
	}
	
	@Test 
	public void CreationTest()
	{
		doc = new Document();
		assertEquals("Hauria de retornar:", "New Document", doc.GetNom());
		assertNull(doc.GetPath());
	}
	
	@Test
	public void CreationTest2()
	{
		doc = new Document("C:/Users/march/OneDrive/Escriptori");
		assertEquals("Hauria de retornar:", "New Document", doc.GetNom());
		assertEquals("Hauria de retornar:", "C:/Users/march/OneDrive/Escriptori", doc.GetPath());
	}
	
	@Test
	public void InitTest() 
	{
		doc = new Document();
		doc.init();
		assertEquals("Hauria de retornar:", "New Document", doc.GetNom());
		assertNull(doc.GetPath());
	}
	
	@Test
	public void Init2Test()
	{
		doc = new Document();
		doc.init("C:/Users/march/OneDrive/Escriptori");
		assertEquals("Hauria de retornar:", "C:/Users/march/OneDrive/Escriptori", doc.GetPath());
	}

	@Test 
	public void getters()
	{
		doc = new Document();
		doc.init("C:/Users/march/OneDrive/Escriptori");
		assertEquals("Hauria de retornar:", true, doc.GetMode());
		assertEquals("Hauria de retornar:", "New Document",doc.GetNom());
		assertEquals("Hauria de retornar:", "C:/Users/march/OneDrive/Escriptori",doc.GetPath());
		assertEquals("Hauria de retornar:", doc, doc.GetDoc());
		
		assertNotNull("Full 0:", doc.GetFull(0));
		assertNotNull("Full 0:", doc.GetFull("0"));
		String s = doc.GetFull(0).getNomFull();
		assertEquals("Hauria de retornar:", doc.GetFull(0), doc.GetFull(s));
		
		assertNull("Full out of bounds:", doc.GetFull(12));
		assertNull("Full amb nom no existent:", doc.GetFull("test"));
		assertNull("Full amb nom no existent:", doc.GetFull("120"));
		
	}
	
	@Test
	public void afegirFull()
	{
		doc = new Document();
		doc.init("C:/Users/march/OneDrive/Escriptori");
		int test1 = doc.GetLengthLlibreta();
		doc.afegirFull();
		int test2 = doc.GetLengthLlibreta();
		assertEquals("Hauria de retornar: ", test1+1, test2);
	}
	
	@Test
	public void setters()
	{
		doc = new Document();
		doc.init();
		
		doc.SetPath("C:/Users/march/OneDrive/Escriptori");
		assertEquals("Hauria de retornar:", "C:/Users/march/OneDrive/Escriptori",doc.GetPath());
		
		assertEquals("Hauria de retornar:", true, doc.GetMode());
		doc.SetMode(false);
		assertEquals("Hauria de retornar:", false, doc.GetMode());
		doc.SwitchMode();
		assertEquals("Hauria de retornar:", true, doc.GetMode());
		doc.SwitchMode();
		assertEquals("Hauria de retornar:", false, doc.GetMode());
		
		assertEquals("Hauria de retornar:", "New Document",doc.GetNom());
		doc.SetNom("Bon Nadal i Felices Pasqües");
		assertEquals("Hauria de retornar:", "Bon Nadal i Felices Pasqües",doc.GetNom());
		
		assertEquals("Hauria de retornar:", 0, doc.GetFullActiu());
		doc.afegirFull();
		doc.setFullActiu(1);
		assertEquals("Hauria de retornar:", 1, doc.GetFullActiu());
		doc.setFullActiu(101);
		assertEquals("Hauria de retornar:", 1, doc.GetFullActiu());
		doc.setFullActiu(-1);
		assertEquals("Hauria de retornar:", 1, doc.GetFullActiu());
		doc.setFullActiu(0);
		assertEquals("Hauria de retornar:", 0, doc.GetFullActiu());
		
		doc.SetCopia(null);
		assertNull(doc.GetCopia());
		
		Bloc b = new Bloc(0,0,1,2,doc.GetFull(0));
		doc.SetCopia(b);
		assertEquals("Haurien de ser iguals: ", b.getinitX(), doc.GetCopia().getinitX());
		assertEquals("Haurien de ser iguals: ", b.getinitY(), doc.GetCopia().getinitY());
		assertEquals("Haurien de ser iguals: ", b.getRows(), doc.GetCopia().getRows());
		assertEquals("Haurien de ser iguals: ", b.getCols(), doc.GetCopia().getCols());
	}
	
	@Test
	public void initLlibreta()
	{
		doc = new Document();
		doc.init();
		
		assertEquals("Nombre de fulls hauria de ser: ", 1, doc.GetLengthLlibreta());
		doc.afegirFull();
		assertEquals("Nombre de fulls hauria de ser: ", 2, doc.GetLengthLlibreta());
		
		doc.InitLlibreta();
		assertEquals("Nombre de fulls hauria de ser: ", 1, doc.GetLengthLlibreta());
	}
	
	@Test
	public void eliminaDoc()
	{
		doc = new Document();
		
		doc.afegirFull();
		doc.afegirFull();
		assertEquals("Nombre de fulls hauria de ser: ", 3, doc.GetLengthLlibreta());
		
		// Esborrem el document - Ara es null pointer
		doc = doc.eliminarDocument(doc.GetNom(), doc.GetPath());
		assertNull(doc);
	}
	
	@Test
	public void indexIncorrecteEliminaFull()
	{
		doc = new Document();
		doc.eliminarFull(10);
		assertEquals("Nombre de fulls hauria de ser: ", 1, doc.GetLengthLlibreta()); 	// Cap full s'ha d'haver eliminat
	}
	
	@Test
	public void ordenaLlibreta()
	{
		doc = new Document();
		Full f1, f2, f3 = new Full(10, 10);
		f1 = doc.GetFull(0);
		doc.afegirFull();
		f2 = doc.GetFull(1);
		doc.afegirFull();
		f3 = doc.GetFull(2);
		doc.ordenarFulls(1, 2);
		assertEquals("Haurien d'estar en el mateix ordre: ", f1, doc.GetFull(0));
		assertEquals("Haurien d'estar en el següent ordre: ", f3, doc.GetFull(1));
		assertEquals("Haurien d'estar en el següent ordre: ", f2, doc.GetFull(2));
		
		assertEquals("FullActiu:", 0, doc.GetFullActiu());
		
		assertEquals("Haurien d'estar en el mateix ordre: ", f1, doc.GetFull(0));
		assertNotEquals("Haurien d'estar en el següent ordre: ", f2, doc.GetFull(1));
		assertNotEquals("Haurien d'estar en el següent ordre: ", f3, doc.GetFull(2));
		
		f1 = doc.GetFull(0);
		doc.afegirFull();
		f2 = doc.GetFull(1);
		doc.afegirFull();
		f3 = doc.GetFull(2);
		doc.ordenarFulls(0, 2);		// Porta f1 a la posició 3
		assertEquals("Haurien d'estar en el següent ordre: ", f2, doc.GetFull(0));
		assertEquals("Haurien d'estar en el següent ordre: ", f3, doc.GetFull(1));
		assertEquals("Haurien d'estar en el següent ordre: ", f1, doc.GetFull(2));
		assertEquals("FullActiu:", 2, doc.GetFullActiu());
		
		doc.ordenarFulls(2, 0); 	// Retorna f1, ara a la posició 3, a la primera.
		assertEquals("Haurien d'estar en el següent ordre: ", f1, doc.GetFull(0));
		assertEquals("Haurien d'estar en el següent ordre: ", f2, doc.GetFull(1));
		assertEquals("Haurien d'estar en el següent ordre: ", f3, doc.GetFull(2));
		assertEquals("FullActiu:", 0, doc.GetFullActiu());
		
		
		// Casos Especials: i/j són més grans que la mida de la llibreta.
		doc = new Document();
		f1 = doc.GetFull(0);
		doc.afegirFull();
		f2 = doc.GetFull(1);
		doc.afegirFull();
		f3 = doc.GetFull(2);
		doc.ordenarFulls(3, 2);
		assertEquals("Haurien d'estar en el mateix ordre: ", f1, doc.GetFull(0));
		assertEquals("Haurien d'estar en el següent ordre: ", f2, doc.GetFull(1));
		assertEquals("Haurien d'estar en el següent ordre: ", f3, doc.GetFull(2));
		
		assertEquals("FullActiu:", 0, doc.GetFullActiu());
		
		
		doc = new Document();
		f1 = doc.GetFull(0);
		doc.afegirFull();
		f2 = doc.GetFull(1);
		doc.afegirFull();
		f3 = doc.GetFull(2);
		doc.ordenarFulls(2, 3);
		assertEquals("Haurien d'estar en el mateix ordre: ", f1, doc.GetFull(0));
		assertEquals("Haurien d'estar en el següent ordre: ", f2, doc.GetFull(1));
		assertEquals("Haurien d'estar en el següent ordre: ", f3, doc.GetFull(2));
	}
	
	/*
	@Test
	public void testReferencia()
	{
		doc = new Document();
		String[] s = {"A0"};
		s = doc.referencia(s);
		assertEquals("Reference", "0;0", s[0]);
		
		s[0] = "F5";
		s = doc.referencia(s);
		assertEquals("Reference", "5;5", s[0]);
		
		s[0] = "5";
		s = doc.referencia(s);
		assertEquals("Reference", "5", s[0]);
		
		s[0] = "-5";
		s = doc.referencia(s);
		assertEquals("Reference", "-5", s[0]);
		
		String [] s1 = {"A6", "B8", "-128"};
		s1 = doc.referencia(s1);
		assertEquals("Reference", "6;0", s1[0]);
		assertEquals("Reference", "8;1", s1[1]);
		assertEquals("Reference", "-128", s1[2]);
		
		// Casos d'Error:
		
		s[0] = "F5F";
		s = doc.referencia(s);
		assertNull(s[0]);
		
		s[0] = "5A";
		s = doc.referencia(s);
		assertNull(s[0]);
		
		s[0] = "//";
		s = doc.referencia(s);
		assertNull(s[0]);
		
		String [] s2 = {"CA5", "A4A"};
		s2 = doc.referencia(s2);
		assertNull(s[0]);
		assertNull("Reference", s2[1]);
		
		String [] s3 = {"CA5", "A4A", "A0", "B1", "C2"};
		s3 = doc.referencia(s3);
		assertNull("Reference", s3[0]);
		assertNull("Reference", s3[1]);
		assertNull("Reference", s3[2]);
		assertNull("Reference", s3[3]);
		assertNull("Reference", s3[4]);
	}
	*/
	
}
