package test;

import static org.junit.Assert.*;

//import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import Dominio.Bloc;
import Dominio.Document;
import Dominio.Full;

public class BlocTest {
	
	Full f;
	Bloc b;
	
	@Before
	public void SetUp() {
		f = new Full(10, 10);
	}

	@Test
	public void testCreacio() {
		b = new Bloc(0,0,1,1,f);
		assertNotNull("Hauria de ser not null:", b);
		assertEquals("Columns", 1, b.getCols());
		assertEquals("Rows", 1, b.getRows());
		assertEquals("X", 0, b.getinitX());
		assertEquals("Y", 0, b.getinitY());
		
		
		// Casos Erronis: el bloc es crea buit, amb 0 columnes i files:
		
		b = new Bloc(-1,0,1,1,f);
		assertNotNull("Hauria de ser not null:", b);
		assertEquals("Columns", 0, b.getCols());
		assertEquals("Rows", 0, b.getRows());
		assertEquals("X", 0, b.getinitX());
		assertEquals("Y", 0, b.getinitY());
		
		b = new Bloc(0,-1,1,1,f);
		assertNotNull("Hauria de ser not null:", b);
		assertEquals("Columns", 0, b.getCols());
		assertEquals("Rows", 0, b.getRows());
		assertEquals("X", 0, b.getinitX());
		assertEquals("Y", 0, b.getinitY());
		
		b = new Bloc(0,0,180,1,f);
		assertNotNull("Hauria de ser not null:", b);
		assertEquals("Columns", 0, b.getCols());
		assertEquals("Rows", 0, b.getRows());
		assertEquals("X", 0, b.getinitX());
		assertEquals("Y", 0, b.getinitY());
		
		b = new Bloc(0,0,1,180,f);
		assertNotNull("Hauria de ser not null:", b);
		assertEquals("Columns", 0, b.getCols());
		assertEquals("Rows", 0, b.getRows());
		assertEquals("X", 0, b.getinitX());
		assertEquals("Y", 0, b.getinitY());
	}
	
	@Test
	public void testGetters() {
		f.getCella(0, 0).setContingut("test");
		b = new Bloc(0,0,1,1,f);
		
		assertEquals("Columns", 1, b.getCols());
		assertEquals("Rows", 1, b.getRows());
		assertEquals("X", 0, b.getinitX());
		assertEquals("Y", 0, b.getinitY());
		
		assertEquals("Cell from Block", "test", b.getmt().get(0).get(0).getContingut());
		
		f = new Full(10,10);
	}
	
	@Test
	public void testClone() {
		f.getCella(0, 0).setContingut("test");
		b = new Bloc(0,0,1,1,f);
		Bloc b_clone = b.clone();
		
		assertEquals("Columns", b_clone.getCols(), b.getCols());
		assertEquals("Rows", b_clone.getRows(), b.getRows());
		assertEquals("X", b_clone.getinitX(), b.getinitX());
		assertEquals("Y", b_clone.getinitY(), b.getinitY());
		assertEquals("Content ", b_clone.getmt().get(0).get(0).getContingut(), b.getmt().get(0).get(0).getContingut());
		
		// Comprovem que s'ha clonat la cella i no s'ha només copiat la referència:
		assertNotEquals("Cell code ", b_clone.getmt().get(0).get(0), b.getmt().get(0).get(0));
	}
	
	@Test
	public void testCopiar() {
		Document d = new Document();
		d.GetFull(0).getCelles().get(1).get(1).setContingut("test");
		b = new Bloc(0,0,2,2,d.GetFull(d.GetFullActiu()));
		b.copiar(d);
		
		assertEquals("Content ", d.GetCopia().getmt().get(1).get(1).getContingut(), b.getmt().get(1).get(1).getContingut());
		
		// Comprovem que s'ha clonat la cella i no s'ha només copiat la referència:
		assertNotEquals("Cell code ", d.GetCopia().getmt().get(1).get(1), b.getmt().get(1).get(1));
	}
	
	@Test
	public void testEnganxar() {
		Document d = new Document();
		d.GetFull(0).getCelles().get(1).get(1).setContingut("test");
		
		b = new Bloc(0,0,2,2,d.GetFull(d.GetFullActiu()));
		b.enganxar(d, d.GetFull(0), 9, 9);
		
		// A la cel·la [10][10] hi hauria d'haver la paraula "test".
		assertEquals("Content ", d.GetFull(0).getCelles().get(10).get(10).getContingut(), b.getmt().get(1).get(1).getContingut());
		// Ens assegurem que la referencia de cel·la es diferent (no estan vinculades i no es traspassen els canvis entre elles).
		assertNotEquals("Cell code ", d.GetFull(0).getCelles().get(10).get(10), b.getmt().get(1).get(1));
		
		//No es permet enganxar en coordenades fora de limits i salta excepcio.
	}
	
	@Test
	public void testMoure() {
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("test1");
		f.getCella(1, 1).setContingut("test2");
		b = new Bloc(0,0,2,2,f);
		
		b.moure(f.getCella(5, 5));
		
		assertEquals("Cella test1:", "", f.getCella(0, 0).getContingut());
		assertEquals("Cella test1:", "", f.getCella(1, 1).getContingut());
		
		assertEquals("Cella test1:", "test1", f.getCella(5, 5).getContingut());
		assertEquals("Cella test1:", "test2", f.getCella(6, 6).getContingut());
		
		//b.moure(f.getCella(9, 9));
	}
	
	@Test
	public void testOrdenar() {
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("1");
		f.getCella(0, 1).setContingut("2");
		f.getCella(0, 2).setContingut("0");
		b = new Bloc(0,0,1,3,f);
		
		b.ordenar("Asc");
		
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "1", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(2).getContingut());
		
		b.ordenar("Desc");
		
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "1", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(2).getContingut());
		
		// Cas criteri erroni:
		// No hi ha modificacio respecte la darrera ordenacio
		
		b.ordenar("test");
		
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "1", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(2).getContingut());
		
		
		// Casos Extra:
		
		// Forma inicial del bloc:
				// [1][][]
				// [][2][]
				// [][][0]
		
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("1");
		f.getCella(1, 1).setContingut("2");
		f.getCella(2, 2).setContingut("0");
		b = new Bloc(0,0,3,3,f);
		
		b.ordenar("Asc");
		// Forma esperada del bloc:
		// [][][0]
		// [][][1]
		// [][][2]
		assertEquals("Cella test1:", "0", b.getmt().get(2).get(0).getContingut());
		assertEquals("Cella test1:", "1", b.getmt().get(2).get(1).getContingut());
		assertEquals("Cella test1:", "2", b.getmt().get(2).get(2).getContingut());
		
		
		b.ordenar("Desc");
		// Forma esperada del bloc:
		// [2][][]
		// [1][][]
		// [0][][]
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "1", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(2).getContingut());
		
		
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("A");
		f.getCella(1, 0).setContingut("B");
		f.getCella(2, 0).setContingut("C");
		f.getCella(0, 1).setContingut("D");
		f.getCella(1, 1).setContingut("E");
		f.getCella(2, 1).setContingut("F");
		f.getCella(0, 2).setContingut("G");
		f.getCella(1, 2).setContingut("H");
		f.getCella(2, 2).setContingut("I");
		b = new Bloc(0,0,3,3,f);
		// Forma inicial del bloc:
		// [A][B][C]
		// [D][E][F]
		// [G][H][I]
		b.ordenar("Asc");
		// Forma esperada del bloc:
				// [A][D][G]
				// [B][E][H]
				// [C][F][I]
		assertEquals("Cella test1:", "A", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "B", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "C", b.getmt().get(0).get(2).getContingut());
		assertEquals("Cella test1:", "D", b.getmt().get(1).get(0).getContingut());
		assertEquals("Cella test1:", "E", b.getmt().get(1).get(1).getContingut());
		assertEquals("Cella test1:", "F", b.getmt().get(1).get(2).getContingut());
		assertEquals("Cella test1:", "G", b.getmt().get(2).get(0).getContingut());
		assertEquals("Cella test1:", "H", b.getmt().get(2).get(1).getContingut());
		assertEquals("Cella test1:", "I", b.getmt().get(2).get(2).getContingut());
	}
	
	@Test
	public void testModificarContinguts() {
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("1");
		f.getCella(0, 1).setContingut("2");
		f.getCella(0, 2).setContingut("0");
		b = new Bloc(0,0,1,3,f);
		
		assertEquals("Cella test1:", "1", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(2).getContingut());
		
		b.modificarContinguts("test");
		
		assertEquals("Cella test1:", "test", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "test", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "test", b.getmt().get(0).get(2).getContingut());
	}
	
	@Test
	public void testReemplassar() {
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("1");
		f.getCella(0, 1).setContingut("2");
		f.getCella(0, 2).setContingut("0");
		b = new Bloc(0,0,1,3,f);
		
		assertEquals("Cella test1:", "1", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(2).getContingut());
		
		b.reemplassar("1", "test");
		
		assertEquals("Cella test1:", "test", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(2).getContingut());
		
		// Test de prova per a un canvi d'una string que no es troba al bloc:
		// No genera cap canvi:
		
		b.reemplassar("academia", "test");
		
		assertEquals("Cella test1:", "test", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(2).getContingut());
	}
	
	@Test
	public void testEsborrar() {
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("1");
		f.getCella(0, 1).setContingut("2");
		f.getCella(0, 2).setContingut("0");
		b = new Bloc(0,0,1,3,f);
		
		assertEquals("Cella test1:", "1", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "2", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "0", b.getmt().get(0).get(2).getContingut());
		
		b.esborrar();
		
		assertEquals("Cella test1:", "", b.getmt().get(0).get(0).getContingut());
		assertEquals("Cella test1:", "", b.getmt().get(0).get(1).getContingut());
		assertEquals("Cella test1:", "", b.getmt().get(0).get(2).getContingut());
	}
	
	@Test
	public void testCercaContinguts() {
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("1");
		f.getCella(0, 1).setContingut("2");
		f.getCella(0, 2).setContingut("0");
		b = new Bloc(0,0,1,3,f);
		
		int count = b.cercaContinguts("1");
		
		assertEquals("Recompte:", 1, count);
		
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("test");
		f.getCella(0, 1).setContingut("test");
		f.getCella(0, 2).setContingut("test");
		b = new Bloc(0,0,1,3,f);
		
		count = b.cercaContinguts("test");
		
		assertEquals("Recompte:", 3, count);
		
		count = b.cercaContinguts("1");
		
		assertEquals("Recompte:", 0, count);
	}
	
	@Test
	public void testInit() {
		f = new Full(10,10);
		f.getCella(0, 0).setContingut("test");
		f.getCella(0, 1).setContingut("test");
		f.getCella(0, 2).setContingut("test");
		b = new Bloc(0,0,1,3,f);
		
		var oldMt = b.getmt();
		b.initialize();
		
		//Es genera una nova mt buida:
		assertNotNull("New MT:", b.getmt());
		assertNotEquals("MT comparacio:", oldMt, b.getmt());
		assertEquals("New Bloc Columns:", 1, b.getCols());
		assertEquals("New Bloc Columns:", 3, b.getRows());
	}

}
