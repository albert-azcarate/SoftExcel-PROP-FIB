package test;

import Dominio.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


/* 								***IMPORTANT***
 * 					Mai tindrem contingut de cel·la = null;
 * Quan volem representar una cel·la buida, es representa amb "", no amb null.
*/
public class CellaTest {
	Cella cell;
	Full f = new Full(10,10);
	@Before
	public void SetUp() {
		cell = new Cella(0, 0, f);
	}
	
	@Test
	public void CreationTest()
	{
		cell = new Cella(0,0, f);
	}
	
	@Test
	public void CreationCopiedTest()
	{
		cell = new Cella(0,0,f);
		
		cell.setContingut("Copied test");
		cell.setColor(120120);
		
		Cella tested = new Cella(cell);
		assertEquals("Hauria de retornar:", cell.getContingut(), tested.getContingut());
		assertEquals("Hauria de retornar:", cell.getColor(), tested.getColor());
		assertEquals("Hauria de retornar:", cell.getTipus(), tested.getTipus());
	}
	
	@Test
	public void settersIGetters()
	{
		cell = new Cella(0,0, f);
		
		assertEquals("Hauria de retornar:", 0, cell.getRows());
		assertEquals("Hauria de retornar:", 0, cell.getCols());
		
		cell.setContingut("patata");
		assertEquals("Hauria de retornar:", "patata", cell.getContingut());
		
		cell.setColor(450062);
		assertEquals("Hauria de retornar:", 450062, cell.getColor());
		
		cell.setFormatBold(false);
		assertEquals("Hauria de retornar:", false, cell.getFormatBold());
		cell.setFormatBold(true);
		assertEquals("Hauria de retornar:", true, cell.getFormatBold());
		
		cell.setFormatItalics(false);
		assertEquals("Hauria de retornar:", false, cell.getFormatItalics());
		cell.setFormatItalics(true);
		assertEquals("Hauria de retornar:", true, cell.getFormatItalics());
		
		cell.setFormatUnderline(false);
		assertEquals("Hauria de retornar:", false, cell.getFormatUnderline());
		cell.setFormatUnderline(true);
		assertEquals("Hauria de retornar:", true, cell.getFormatUnderline());
		
		cell.setTipus('T');
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setFormatConditional(false);
		assertEquals("Hauria de retornar:", false, cell.getFormatConditional());
		cell.setFormatConditional(true);
		assertEquals("Hauria de retornar:", true, cell.getFormatConditional());
		
		cell.setFormula("=SUM(A1,A3)");
		assertEquals("Hauria de retornar:", "=SUM(A1,A3)", cell.getFormula());
		
		cell.setFull(f);
		assertEquals("Hauria de retornar:", f, cell.getFull());
	}
	
	@Test
	public void esborraTest()
	{
		cell = new Cella(4,2, f);
		cell.setContingut("patata");
		cell.setColor(450062);
		cell.setFormatBold(true);
		cell.setTipus('N');
		cell.setFormula("=SUM(A1,A3)");
		
		cell.esborrarContingut();
		
		assertEquals("Hauria de retornar:", 4, cell.getCols());
		assertEquals("Hauria de retornar:", 2, cell.getRows());
		assertEquals("Hauria de retornar:", "", cell.getContingut());
		assertEquals("Hauria de retornar:", 0, cell.getColor());
		assertEquals("Hauria de retornar:", false, cell.getFormatBold());
		assertEquals("Hauria de retornar:", false, cell.getFormatItalics());
		assertEquals("Hauria de retornar:", false, cell.getFormatUnderline());
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		assertEquals("Hauria de retornar:", "", cell.getFormula());
	}
	
	@Test
	public void checkTipus()
	{
		cell = new Cella(0, 0, f);
		cell.setContingut("");
		assertEquals("Hauria de retornar:", "", cell.getContingut());
		
		cell.setContingut("MarvelStudios");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("100");
		assertEquals("Hauria de retornar:", 'N', cell.getTipus());
		
		cell.setContingut("-25");
		assertEquals("Hauria de retornar:", 'N', cell.getTipus());
		
		cell.setContingut("-2.57");
		assertEquals("Hauria de retornar:", 'N', cell.getTipus());
		
		cell.setContingut("1.618");
		assertEquals("Hauria de retornar:", 'N', cell.getTipus());
		
		cell.setContingut("1.6.18");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("1,618");
		assertEquals("Hauria de retornar:", 'N', cell.getTipus());
		
		cell.setContingut("1,6,18");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("A1");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("1/02/2024");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("31/01/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("31/12/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("30/04/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("30/06/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("30/09/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("30/11/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("28/02/2022");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("29/02/2024");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("1/1/0001");
		assertEquals("Hauria de retornar:", 'D', cell.getTipus());
		
		cell.setContingut("0b101110");
		assertEquals("Hauria de retornar:", 'B', cell.getTipus());
		
		cell.setContingut("0x45AB");
		assertEquals("Hauria de retornar:", 'H', cell.getTipus());
		
		cell.setContingut("0bA7");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("0xPCH");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("0xabcd");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("0x-1111");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("0b");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("0x");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("Home/Dona");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("Ho/Do/NA");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("/");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("1//1000//1");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("29886/01/05");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("0/02/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("30/02/4400");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("29/02/0200");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("29/02/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("31/04/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("32/05/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("1/0/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("1/13/2022");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("1/1/0000");
		assertEquals("Hauria de retornar:", 'T', cell.getTipus());
		
		cell.setContingut("");
		assertEquals("Hauria de retornar:", "", cell.getContingut());
	}
	
	@Test
	public void boolDecimal()
	{
		cell = new Cella(0, 0, f);
		
		cell.setContingut("2567936702.95");
		assertEquals("Hauria de retornar:", true, cell.esDecimal(cell.getContingut()));
		cell.setContingut("2567936702,95");
		assertEquals("Hauria de retornar:", true, cell.esDecimal(cell.getContingut()));
		
		cell.setContingut("1234567890");
				assertEquals("Hauria de retornar:", false, cell.esDecimal(cell.getContingut()));
		cell.setContingut("0");
		assertEquals("Hauria de retornar:", false, cell.esDecimal(cell.getContingut()));
		cell.setContingut("-200");
		assertEquals("Hauria de retornar:", false, cell.esDecimal(cell.getContingut()));
		
		cell.setContingut("test");
		assertEquals("Hauria de retornar:", false, cell.esDecimal(cell.getContingut()));
	}
	
	@Test
	public void numTrunc()
	{
		cell = new Cella(0,0,f);
		
		cell.setContingut("0");
		cell.numericaTruncament("TRUNCINT");
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("0.0");
		cell.numericaTruncament("TRUNCINT");
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("1.5");
		cell.numericaTruncament("TRUNCINT");
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
		
		cell.setContingut("-2.75");
		cell.numericaTruncament("TRUNCINT");
		assertEquals("Hauria de retornar:", "-2", cell.getContingut());
		
		// No vàlid per a truncament:
		cell.setContingut("test");
		cell.numericaTruncament("TRUNCINT");
		assertEquals("Hauria de retornar:", "test", cell.getContingut());
		
		cell.setContingut("125.575");
		cell.numericaTruncament("INCORRECT OPTION HERE");
		assertEquals("Hauria de retornar:", "125.575", cell.getContingut());
	}
	
	@Test
	public void numTruncDec()
	{
		cell = new Cella(0,0,f);
		
		// TRUNCDEC Testing:
		cell.setContingut("0");
		cell.numericaTruncament("TRUNCDEC", 1);
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("123.55");
		cell.numericaTruncament("TRUNCDEC", 1);
		assertEquals("Hauria de retornar:", "123.5", cell.getContingut());
		
		cell.setContingut("1.5");
		cell.numericaTruncament("TRUNCDEC", 0);
		assertEquals("Hauria de retornar:", "1.0", cell.getContingut());
		
		cell.setContingut("1.54321");
		cell.numericaTruncament("TRUNCDEC", 3);
		assertEquals("Hauria de retornar:", "1.543", cell.getContingut());
		
		cell.setContingut("-2.75");
		cell.numericaTruncament("TRUNCDEC", 0);
		assertEquals("Hauria de retornar:", "-2.0", cell.getContingut());
		
		cell.setContingut("test");
		cell.numericaTruncament("TRUNCDEC", 10);
		assertEquals("Hauria de retornar:", "test", cell.getContingut());
		
		cell.setContingut("125.575");
		cell.numericaTruncament("TRUNCEC", 10);
		assertEquals("Hauria de retornar:", "125.575", cell.getContingut());
	}
	
	@Test
	public void conversióDecimal()
	{
		cell = new Cella(0,0,f);
		
		// CONVDEC Testing:
		cell.setContingut("1.0");
		cell.numericaConversio("CONVDC");
		assertEquals("Hauria de retornar:", "1.0", cell.getContingut());
		
		cell.setContingut("Text");
		cell.numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1");
		cell.numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
		
		cell.setContingut("-1");
		cell.numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "-1", cell.getContingut());
		
		cell.setContingut("3,14156593");
		cell.numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "3.14156593", cell.getContingut());
		
		cell.setContingut("3.14156593");
		cell.numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "3,14156593", cell.getContingut());
		
		cell.setContingut("3.14156593");
		cell.numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "3,14156593", cell.getContingut());
		cell.numericaConversio("CONVDEC");
		assertEquals("Hauria de retornar:", "3.14156593", cell.getContingut());
	}
	
	@Test
	public void numConversio()
	{
		cell = new Cella(0,0,f);
		
		// Decimal a binari / hexa:
		cell.setContingut("1");
		cell.numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b1", cell.getContingut());
		
		cell.setContingut("1");
		cell.numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0x1", cell.getContingut());
		
		cell.setContingut("67");
		cell.numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b1000011", cell.getContingut());
		
		cell.setContingut("67");
		cell.numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0x43", cell.getContingut());
		
		cell.setContingut("10");
		cell.numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0xA", cell.getContingut());
		
		
		// Binari a hexa / decimal:
		cell.setContingut("0b1");
		cell.numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0x1", cell.getContingut());
		
		cell.setContingut("0b1");
		cell.numericaConversio("CONVBASE", 'D');
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
		
		cell.setContingut("0b11011");
		cell.numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0x1B", cell.getContingut());
		
		cell.setContingut("0b11011");
		cell.numericaConversio("CONVBASE", 'D');
		assertEquals("Hauria de retornar:", "27", cell.getContingut());
		
		cell.setContingut("0b1111");
		cell.numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "0xF", cell.getContingut());
		
		// Hexa a binari / decimal:
		cell.setContingut("0x1");
		cell.numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b1", cell.getContingut());
		
		cell.setContingut("0x1");
		cell.numericaConversio("CONVBASE", 'D');
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
		
		cell.setContingut("0xA3");
		cell.numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b10100011", cell.getContingut());
		
		cell.setContingut("0xA3");
		cell.numericaConversio("CONVBASE", 'D');
		assertEquals("Hauria de retornar:", "163", cell.getContingut());
		
		cell.setContingut("0xF");
		cell.numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "0b1111", cell.getContingut());
		
		// Casos especials:
		cell.setContingut("test");
		cell.numericaConversio("CONVBASE", 'H');
		assertEquals("Hauria de retornar:", "test", cell.getContingut());
		
		cell.setContingut("25.75");
		cell.numericaConversio("CONVBASE", 'B');
		assertEquals("Hauria de retornar:", "25.75", cell.getContingut());
		
		cell.setContingut("1");
		cell.numericaConversio("INPUT INCORRECTE", 'H');
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
		
		cell.setContingut("1");
		cell.numericaConversio("CONVBASE", 'P');
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
		
		cell.setContingut("0b1");
		cell.numericaConversio("CONVBASE", 'P');
		assertEquals("Hauria de retornar:", "0b1", cell.getContingut());
		
		cell.setContingut("0x1");
		cell.numericaConversio("CONVBASE", 'P');
		assertEquals("Hauria de retornar:", "0x1", cell.getContingut());
	}
	
	@Test
	public void testUnaria()
	{
		cell = new Cella(0,0,f);
		
		// INC Testing:
		cell.setContingut("0");
		cell.unaria("NC", 0);
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("0");
		cell.unaria("INC", 0);
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("-15");
		cell.unaria("INC", 1);
		assertEquals("Hauria de retornar:", "-14", cell.getContingut());
		
		cell.setContingut("1.5");
		cell.unaria("INC", 1);
		assertEquals("Hauria de retornar:", "2.5", cell.getContingut());
		
		cell.setContingut("-2.25");
		cell.unaria("INC", 4);
		assertEquals("Hauria de retornar:", "1.75", cell.getContingut());
		
		cell.setContingut("test");
		cell.unaria("INC", 10);
		assertEquals("Hauria de retornar:", "test", cell.getContingut());
		
		// ABS Testing:
		cell.setContingut("0");
		cell.unaria("AB");
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("0");
		cell.unaria("ABS");
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("-15");
		cell.unaria("ABS");
		assertEquals("Hauria de retornar:", "15", cell.getContingut());
		
		cell.setContingut("1.5");
		cell.unaria("ABS");
		assertEquals("Hauria de retornar:", "1.5", cell.getContingut());
		
		cell.setContingut("-2.25");
		cell.unaria("ABS");
		assertEquals("Hauria de retornar:", "2.25", cell.getContingut());
		
		cell.setContingut("test");
		cell.unaria("ABS");
		assertEquals("Hauria de retornar:", "test", cell.getContingut());
	}
	
	@Test
	public void testNaries()
	{
		//SUM, RES, MUL, DIV
		cell = new Cella(0,0,f);
		Cella cell2 = new Cella(0,1,f);
		
		/* 						***IMPORTANT***
		 * 
		 *  Per raons de normalitzacio, les operacions amb decimals
		 *  sempre converteixen el simbol decimal a un punt.
		 *  
		 */
		
		cell.setContingut("");
		cell.naria("SUM", cell.getContingut());
		assertEquals("Hauria de retornar:", "", cell.getContingut());
		
		cell.setContingut("0");
		cell.naria("SUM", cell.getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		// SUM Testing:
		cell.setContingut("0");
		cell2.setContingut("0");
		cell.naria("SUM", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("15");
		cell2.setContingut("5");
		cell.naria("SUM", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "20", cell.getContingut());
		
		cell.setContingut("15");
		cell2.setContingut("-5");
		cell.naria("SUM", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "10", cell.getContingut());
		
		cell.setContingut("15.5");
		cell2.setContingut("5.5");
		cell.naria("SUM", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "21.0", cell.getContingut());
		
		cell.setContingut("15,5");
		cell2.setContingut("5,5");
		cell.naria("SUM", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "21.0", cell.getContingut());
		
		cell.setContingut("15.5");
		cell2.setContingut("5,5");
		cell.naria("SUM", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "21.0", cell.getContingut());
		
		cell.setContingut("-15.5");
		cell2.setContingut("5.5");
		cell.naria("SUM", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-10.0", cell.getContingut());
		
		cell.setContingut("-15.5");
		cell2.setContingut("5,5");
		cell.naria("SUM", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-10.0", cell.getContingut());
		
		// RES Testing:
		cell.setContingut("0");
		cell2.setContingut("0");
		cell.naria("RES", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("15");
		cell2.setContingut("5");
		cell.naria("RES", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "10", cell.getContingut());
		
		cell.setContingut("15");
		cell2.setContingut("-5");
		cell.naria("RES", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "20", cell.getContingut());
		
		cell.setContingut("15.5");
		cell2.setContingut("5.5");
		cell.naria("RES", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "10.0", cell.getContingut());
		
		cell.setContingut("15,5");
		cell2.setContingut("5,5");
		cell.naria("RES", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "10.0", cell.getContingut());
		
		cell.setContingut("15.5");
		cell2.setContingut("5,5");
		cell.naria("RES", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "10.0", cell.getContingut());
		
		cell.setContingut("-15.5");
		cell2.setContingut("5.5");
		cell.naria("RES", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-21.0", cell.getContingut());
		
		cell.setContingut("-15.5");
		cell2.setContingut("5,5");
		cell.naria("RES", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-21.0", cell.getContingut());
		
		// MUL Testing
		cell.setContingut("0");
		cell2.setContingut("0");
		cell.naria("MUL", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("15");
		cell2.setContingut("5");
		cell.naria("MUL", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "75", cell.getContingut());
		
		cell.setContingut("15");
		cell2.setContingut("-5");
		cell.naria("MUL", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-75", cell.getContingut());
		
		cell.setContingut("15.5");
		cell2.setContingut("5.5");
		cell.naria("MUL", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "85.25", cell.getContingut());
		
		cell.setContingut("15,5");
		cell2.setContingut("5,5");
		cell.naria("MUL", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "85.25", cell.getContingut());
		
		cell.setContingut("15.5");
		cell2.setContingut("5,5");
		cell.naria("MUL", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "85.25", cell.getContingut());
		
		cell.setContingut("-15.5");
		cell2.setContingut("5.5");
		cell.naria("MUL", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-85.25", cell.getContingut());
		
		cell.setContingut("-15.5");
		cell2.setContingut("5,5");
		cell.naria("MUL", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-85.25", cell.getContingut());
		
		
		// DIV Testing:
		cell.setContingut("0");
		cell2.setContingut("1");
		cell.naria("DV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("0");
		cell2.setContingut("1");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "0", cell.getContingut());
		
		cell.setContingut("15");
		cell2.setContingut("5");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "3", cell.getContingut());
		
		cell.setContingut("15");
		cell2.setContingut("-5");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-3", cell.getContingut());
		
		cell.setContingut("555.5");
		cell2.setContingut("12.5");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "44.44", cell.getContingut());
		
		cell.setContingut("555,5");
		cell2.setContingut("12,5");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "44.44", cell.getContingut());
		
		cell.setContingut("555.5");
		cell2.setContingut("-12,5");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-44.44", cell.getContingut());
		
		cell.setContingut("-555.5");
		cell2.setContingut("12.5");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-44.44", cell.getContingut());
		
		cell.setContingut("-555.5");
		cell2.setContingut("12,5");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "-44.44", cell.getContingut());
		
		cell.setContingut("100");
		cell2.setContingut("0");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "100", cell.getContingut());
		
		cell.setContingut("100");
		cell2.setContingut("3;5");
		cell.naria("DIV", cell.getContingut() + "; " + cell2.getContingut());
		assertEquals("Hauria de retornar:", "100", cell.getContingut());
	}
	
	
	@Test
	public void dataTest()
	{
		cell = new Cella(0,0,f);
		
		// DATADIA Testing:
		cell.setContingut("Text");
		cell.data("DATADA");
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.data("DATADA");
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.data("DATADA");
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dilluns", cell.getContingut());
		
		cell.setContingut("18/04/22");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dilluns", cell.getContingut());
		
		cell.setContingut("19/04/2022");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dimarts", cell.getContingut());
		
		cell.setContingut("19/04/22");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dimarts", cell.getContingut());
		
		cell.setContingut("20/04/2022");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dimecres", cell.getContingut());
		
		cell.setContingut("20/04/22");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dimecres", cell.getContingut());
		
		cell.setContingut("21/04/2022");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dijous", cell.getContingut());
		
		cell.setContingut("21/04/22");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dijous", cell.getContingut());
		
		cell.setContingut("22/04/2022");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Divendres", cell.getContingut());
		
		cell.setContingut("22/04/22");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Divendres", cell.getContingut());
		
		cell.setContingut("23/04/2022");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dissabte", cell.getContingut());
		
		cell.setContingut("23/04/22");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Dissabte", cell.getContingut());
		
		cell.setContingut("24/04/2022");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Diumenge", cell.getContingut());
		
		cell.setContingut("24/04/22");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "Diumenge", cell.getContingut());
		
		cell.setContingut("32/04/22");
		cell.data("DATADIA");
		assertEquals("Hauria de retornar:", "32/04/22", cell.getContingut());
		
		// DATELEM Testing:
		cell.setContingut("Text");
		cell.data("DATELM", 'C');
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.data("DATELM", 'C');
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.data("DATELM", 'C');
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.data("DATELM", 'D');
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.data("DATELM", 'D');
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.data("DATELM", 'D');
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.data("DATELEM", 'D');
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.data("DATELEM", 'D');
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.data("DATELEM", 'D');
		assertEquals("Hauria de retornar:", "18", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.data("DATELEM", 'M');
		assertEquals("Hauria de retornar:", "4", cell.getContingut());
		
		cell.setContingut("18/12/2022");
		cell.data("DATELEM", 'M');
		assertEquals("Hauria de retornar:", "12", cell.getContingut());
		
		cell.setContingut("18/04/0001");
		cell.data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
		
		cell.setContingut("18/04/0010");
		cell.data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "10", cell.getContingut());
		
		cell.setContingut("18/04/0100");
		cell.data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "100", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "2022", cell.getContingut());
		
		cell.setContingut("18/04/22");
		cell.data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "2022", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.data("DATELEM", 'A');
		assertEquals("Hauria de retornar:", "2022", cell.getContingut());
		
		cell.setContingut("18/04/22");
		cell.data("DATELEM", 'C');
		assertEquals("Hauria de retornar:", "18/04/22", cell.getContingut());
	}
	
	@Test
	public void substituirTest()
	{
		cell = new Cella(0,0,f);
		
		// MINMAJ Testing:
		cell.setContingut("1234");
		cell.textSubstituir("MINMJ", 'A');
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textSubstituir("MINMJ", 'A');
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textSubstituir("MINMJ", 'A');
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.textSubstituir("MINMAJ", 'A');
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textSubstituir("MINMAJ", 'A');
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textSubstituir("MINMAJ", 'A');
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.textSubstituir("MINMAJ", 'M');
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textSubstituir("MINMAJ", 'M');
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textSubstituir("MINMAJ", 'M');
		assertEquals("Hauria de retornar:", "TEXT", cell.getContingut());
		
		cell.setContingut("TEXT");
		cell.textSubstituir("MINMAJ", 'M');
		assertEquals("Hauria de retornar:", "TEXT", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textSubstituir("MINMAJ", 'm');
		assertEquals("Hauria de retornar:", "text", cell.getContingut());
		
		cell.setContingut("text");
		cell.textSubstituir("MINMAJ", 'm');
		assertEquals("Hauria de retornar:", "text", cell.getContingut());
		
		// REECAR Testing:
		cell.setContingut("1234");
		cell.textSubstituir("REECR", "x", "s");
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textSubstituir("REECR", "x", "s");
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textSubstituir("REECR", "x", "s");
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.textSubstituir("REECAR", "x", "s");
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textSubstituir("REECAR", "x", "s");
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textSubstituir("REECAR", "x", "s");
		assertEquals("Hauria de retornar:", "Test", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textSubstituir("REECAR", "s", "x");
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
	}
	
	@Test
	public void longitudTest()
	{
		cell = new Cella(0,0,f);
		
		// NUMCAR Testing:
		cell.setContingut("1234");
		cell.textLongitud("NUMCR");
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textLongitud("NUMCR");
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textLongitud("NUMCR");
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.textLongitud("NUMCAR");
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textLongitud("NUMCAR");
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textLongitud("NUMCAR");
		assertEquals("Hauria de retornar:", "4", cell.getContingut());
		
		// NUMCON Testing:
		cell.setContingut("1234");
		cell.textLongitud("NUMCN", "1");
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textLongitud("NUMCN", "1");
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textLongitud("NUMCN", "x");
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1234");
		cell.textLongitud("NUMCON", "1");
		assertEquals("Hauria de retornar:", "1234", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.textLongitud("NUMCON", "1");
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textLongitud("NUMCON", "x");
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
		
		cell.setContingut("Text");
		cell.textLongitud("NUMCON", "Text");
		assertEquals("Hauria de retornar:", "1", cell.getContingut());
	}
	
	@Test
	public void estadisticaTest()
	{
		cell = new Cella(0,0,f);
		
		// MIT Testing:
		cell.setContingut("18/04/2022");
		cell.estadistica("MT", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.estadistica("MT", cell.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell.estadistica("MT", cell.getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.estadistica("MIT", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.estadistica("MIT", cell.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;2;1;4");
		cell.estadistica("MIT", cell.getContingut());
		assertEquals("Hauria de retornar:", "2.0", cell.getContingut());
		
		// MED Testing:
		cell.setContingut("18/04/2022");
		cell.estadistica("MD", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.estadistica("MD", cell.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell.estadistica("MD", cell.getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.estadistica("MED", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.estadistica("MED", cell.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("2;5;7;-9;0");
		cell.estadistica("MED", cell.getContingut());
		assertEquals("Hauria de retornar:", "2", cell.getContingut());
		
		cell.setContingut("1;2;8;4");
		cell.estadistica("MED", cell.getContingut());
		assertEquals("Hauria de retornar:", "3.0", cell.getContingut());
		
		// VAR Testing:
		cell.setContingut("18/04/2022");
		cell.estadistica("VR", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.estadistica("VR", cell.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell.estadistica("VR", cell.getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.estadistica("VAR", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.estadistica("VAR", cell.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell.estadistica("VAR", cell.getContingut());
		assertEquals("Hauria de retornar:", "2.333333333333333", cell.getContingut());
		
		// STDEV Testing:
		cell.setContingut("18/04/2022");
		cell.estadistica("STDV", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.estadistica("STDV", cell.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell.estadistica("STDV", cell.getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell.estadistica("STDEV", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell.estadistica("STDEV", cell.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell.estadistica("STDEV", cell.getContingut());
		assertEquals("Hauria de retornar:", "1.5275252316519465", cell.getContingut());
		
		Cella cell2 = new Cella(0,1,f);
		
		// COVAR Testing:
		cell.setContingut("18/04/2022");
		cell2.setContingut("19/04/2022");
		cell.estadistica("COVR", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell2.setContingut("Text");
		cell.estadistica("COVR", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell2.setContingut("2;5;6");
		cell.estadistica("COVR", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell2.setContingut("19/04/2022");
		cell.estadistica("COVAR", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell2.setContingut("Text");
		cell.estadistica("COVAR", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell2.setContingut("2;5;6");
		cell.estadistica("COVAR", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "3.166666666666667", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell2.setContingut("2;5;6;7");
		cell.estadistica("COVAR", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getContingut());
		
		cell.setContingut("Text");
		cell2.setContingut("2;5;6");
		cell.estadistica("COVAR", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		// PEARSON Testing:
		cell.setContingut("18/04/2022");
		cell2.setContingut("19/04/2022");
		cell.estadistica("PEARSN", cell.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell2.setContingut("Text");
		cell.estadistica("PEARSN", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell2.setContingut("2;5;6");
		cell.estadistica("PEARSN", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getContingut());
		
		cell.setContingut("18/04/2022");
		cell2.setContingut("19/04/2022");
		cell.estadistica("PEARSON", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "18/04/2022", cell.getContingut());
		
		cell.setContingut("Text");
		cell2.setContingut("Text");
		cell.estadistica("PEARSON", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell2.setContingut("2;5;6");
		cell.estadistica("PEARSON", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "0.9958705948858225", cell.getContingut());
		
		cell.setContingut("1;3;4");
		cell2.setContingut("2;5;6;7");
		cell.estadistica("PEARSON", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "1;3;4", cell.getContingut());
		
		cell.setContingut("Text");
		cell2.setContingut("2;5;6");
		cell.estadistica("PEARSON", cell.getContingut(), cell2.getContingut());
		assertEquals("Hauria de retornar:", "Text", cell.getContingut());
	}
	
	@Test
	public void formatTest()
	{
		cell = new Cella(0,0,f);
		
		// Bold Testing:
		cell.formatBold();
		assertEquals("Hauria de retornar:", true, cell.getFormatBold());
		
		// Italics Testing:
		cell.formatItalics();
		assertEquals("Hauria de retornar:", true, cell.getFormatItalics());
		
		// Underline Testing:
		cell.formatUnderline();
		assertEquals("Hauria de retornar:", true, cell.getFormatUnderline());
	}
}