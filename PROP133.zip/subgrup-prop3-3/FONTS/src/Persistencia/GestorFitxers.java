package Persistencia;

import Dominio.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.pdmodel.PDPage;
//import org.apache.pdfbox.pdmodel.PDPageContentStream;
//import org.apache.pdfbox.pdmodel.common.PDRectangle;
//import org.apache.pdfbox.pdmodel.font.PDType1Font;

public class GestorFitxers {
		
	/*
	 * Funcio escriuFitxer: Parametres d'entrada: path a on es vol guardar (si d ja te path, d.GetPath()).
	 * 
	 * Escriu en format String els continguts del Document de manera que queda en un format com el seguent:
	 * 
	 * [Versio]
	 * 'Nom Document'
	 * With length (Longitud de la Llibreta)
	 * Full i 'Nom Full'
	 * NumRows\NumCols
	 * 'Contingut'_'Formula'_Tipus_Mida_formatBold_formatItalics_formatUnderline_formatCondicional// [Per a totes les caselles que hi ha al full]
	*/
	
	public static void escriuFitxer(String path)
	{
		try {
			String TextDoc = "JavaDoc versio 0.1\r\n";
			TextDoc = TextDoc.concat("'").concat(ControladorDomini.getNomDocument()).concat("'").concat("\r\n").concat("With length ").concat(Integer.toString(ControladorDomini.getLenghtLlibreta())).concat("\r\n");
			for (int i = 0; i < ControladorDomini.getLenghtLlibreta(); ++i)
			{
				TextDoc = TextDoc.concat("Full " + Integer.toString(i) + " ");
				
				ControladorDomini.modificarFullActiu(i);
				TextDoc = TextDoc.concat("'" + ControladorDomini.getNomFull() + "'" + "\r\n");
				int iFullx = ControladorDomini.getNumCols();
				int iFully = ControladorDomini.getNumRows();
				
				TextDoc = TextDoc.concat(iFully + "_" + iFullx + "\r\n");
				
				for(int k = 0; k < iFully; ++k) {
					for(int j = 0; j < iFullx; ++j)
					{
						TextDoc = TextDoc.concat("'" + ControladorDomini.getContingut(k,j) + "'" + "_" + 
										"'" + ControladorDomini.getFormula(k,j) + "'" + "_" + 
										ControladorDomini.getTipus(k,j) + "_" +
										ControladorDomini.getMida(k,j) + "_" +
										ControladorDomini.getColor(k,j));
						
						if (ControladorDomini.getFormatBold(k,j)) TextDoc = TextDoc.concat("_t");
						else TextDoc = TextDoc.concat("_f");
						
						if (ControladorDomini.getFormatItalics(k,j)) TextDoc = TextDoc.concat("_t");
						else TextDoc = TextDoc.concat("_f");
						
						if (ControladorDomini.getFormatUnderline(k,j)) TextDoc = TextDoc.concat("_t");
						else TextDoc = TextDoc.concat("_f");
						
						if (ControladorDomini.getFormatConditional(k,j)) TextDoc = TextDoc.concat("_t");
						else TextDoc = TextDoc.concat("_f");
						
						TextDoc = TextDoc.concat("//");
					}
					TextDoc = TextDoc.concat("\r\n");
				}
				
			}
			FileWriter fw = new FileWriter(path);
			fw.append(TextDoc);
			fw.flush();
			fw.close();
			

	    }
	    catch(Exception e) {
		e.printStackTrace();
    	}
	
	
    }
	
	public static void escriuFitxerCSV(String path) {
		try{
			String TextDoc = new String();
			int iFullx = ControladorDomini.getNumCols();
			int iFully = ControladorDomini.getNumRows();
			for(int i = 0; i < iFully; ++i) {
				for(int j = 0; j < iFullx; ++j)
				{
					TextDoc = TextDoc.concat(ControladorDomini.getContingut(i,j));
					if (j != iFully - 1) TextDoc = TextDoc.concat(",");
				}
				TextDoc = TextDoc.concat("\r\n");
			}
			FileWriter fw = new FileWriter(path);
			fw.append(TextDoc);
			fw.flush();
			fw.close();
			
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
		
		
	}


/*Guarda al path el document en format pdf*/	
public static void escriuFitxerPDF(String path){
	PDDocument document = new PDDocument();
	for (int i = 0; i < ControladorDomini.getLenghtLlibreta(); ++i) {
		ControladorDomini.modificarFullActiu(i);
		PDPage page = new PDPage(PDRectangle.A4);
		document.addPage(page);
		try (PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true)) {
			PDFont font = PDType1Font.TIMES_ROMAN;
			float fontSize = 12.5f;
			if(ControladorDomini.getMode()) {
				Settings settings = Settings.builder()
					.font(font)
					.fontSize((int) fontSize)
					.horizontalAlignment(HorizontalAlignment.CENTER)
					.verticalAlignment(VerticalAlignment.MIDDLE)
					.backgroundColor(Color.WHITE)
					.wordBreak(true)
					.build();
				Table.TableBuilder tableBuilder = Table.builder().borderColor(Color.BLACK).wordBreak(true);
			}
			else {
				Settings settings = Settings.builder()
						.font(font)
						.fontSize((int) fontSize)
						.horizontalAlignment(HorizontalAlignment.CENTER)
						.verticalAlignment(VerticalAlignment.MIDDLE)
						.backgroundColor(Color.WHITE)
						.wordBreak(true)
						.build();
					Table.TableBuilder tableBuilder = Table.builder().borderColor(Color.BLACK).wordBreak(true);
			}
			// Build the table
			int rows = ControladorDomini.getNumRows();
			int cols = ControladorDomini.getNumCols();
			for (int col = 0; col < cols; col++) {
				tableBuilder.addColumnOfWidth(ControladorDomini.getMida(0, col));
			}
			for (int row = 0; row < rows; row++) {
				Row.RowBuilder rowBuilder = Row.builder().wordBreak(true);
				for (int col = 0; col < cols; col++) {
					String colData = ControladorDomini.getContingut(row, col);
					rowBuilder.add(TextCell.builder().settings(settings).text(colData).borderWidth(0.5f).build());
				}
				tableBuilder.addRow(rowBuilder.build());
			}
			Table myTable = tableBuilder.build();
			float tableHeight = myTable.getHeight();
			// Set up the drawer
			float x = 30f;
			float y = page.getMediaBox().getUpperRightY() - 30f;
			TableDrawer tableDrawer = TableDrawer.builder()
					.contentStream(contentStream)
					.startX(x)
					.startY(y)
					.table(myTable)
					.build();
			// And go for it!
			tableDrawer.draw();
			contentStream.restoreGraphicsState();
			}
	}
	
	document.save(path);
	document.close();

}

/*Llegeix el fitxer del path*/	
public static String llegeixFitxer(String path)
	{
		try {
			String TextDoc = new String();
			FileReader f = new FileReader(path);
			BufferedReader b = new BufferedReader(f);
			String line;
			while ((line = b.readLine()) != null) {
				TextDoc = TextDoc.concat(line);
				TextDoc = TextDoc.concat("\r\n");
			}
			b.close();
			return TextDoc;
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}

/* Carrega el document amb els continguts d'un Document de format Propi */
public static void carregarDocPropi(String Text, String path) throws FuncioNoAplicable
	{
	try {
	//Aquesta funcio sera desenvolupada per a properese entregues.
			ControladorDomini.init();
			ControladorDomini.setPath(path);
			String [] info = Text.split("\r\n");
			info[1] = info[1].substring(1, info[1].length() - 1);
			ControladorDomini.setNom(info[1]);
			String longitud[] = info[2].split(" ");
			int longllibreta = Integer.parseInt(longitud[2]);
			for (int i = ControladorDomini.getLenghtLlibreta(); i < longllibreta; ++i) {
				ControladorDomini.afegirFull();
			}
			int aux = 3;
			for (int i = 0; i < longllibreta; ++i) {
				if(i != 0) ++aux;
				String full[] = info[aux].split(" ");
				int f = Integer.parseInt(full[1]);
				ControladorDomini.modificarFullActiu(f);
				String nomF = new String();
				int n = full.length;
				for (int j = 2; j < full.length; ++j) {
					if(j == 2 & j!= full.length - 1) nomF = nomF.concat(full[j].substring(1, full[j].length()) + " ");
					else if (j == full.length -1 & j != 2) nomF = nomF.concat(full[j].substring(0, full[j].length() - 1));
					else if (j == 2 & j == full.length -1) nomF = nomF.concat(full[j].substring(1, full[j].length() - 1));
					else nomF = nomF.concat(full[j] + " ");
				}
					
				ControladorDomini.getFull(f).nombrarFull(nomF);
				String NumRowCol[] = info[aux + 1].split("_");
				int numRow = Integer.parseInt(NumRowCol[0]);
				int numCol = Integer.parseInt(NumRowCol[1]);
				if(numCol > ControladorDomini.getFull(f).getNumColumns()) ControladorDomini.getFull(f).addColSet(0, numCol-ControladorDomini.getFull(f).getNumColumns());
				else if(numCol < ControladorDomini.getFull(f).getNumColumns()) ControladorDomini.getFull(f).deleteColSet(0, ControladorDomini.getFull(f).getNumColumns() - numCol);
				if(numCol > ControladorDomini.getFull(f).getNumRows())ControladorDomini.getFull(f).addRowSet(0, numRow-ControladorDomini.getFull(f).getNumRows());
				else if(numRow < ControladorDomini.getFull(f).getNumRows()) ControladorDomini.getFull(f).deleteRowSet(0, ControladorDomini.getFull(f).getNumRows() - numRow);
				aux += 2;
				for (int j = 0; j < numRow - 1 ; ++j) {
					String celles[] = info[aux].split("//");
					for(int k = 0; k < numCol; ++k) {
						String atributs[] = celles[k].split("_");
						String cont = atributs[0].substring(1, atributs[0].length() - 1);
						ControladorDomini.getFull(f).getCella(j,k).getDada().setContingut(cont);
						String form = atributs[1].substring(1, atributs[1].length() - 1);
						try {
						if(!form.equals("")) cont = ControladorDomini.parser(form, j, k, true);
						} catch (FuncioNoAplicable e){
							
						}
						ControladorDomini.getFull(f).getCella(j,k).getDada().setContingut(cont);
						ControladorDomini.getFull(f).getCella(j,k).getDada().setFormula(form);
						ControladorDomini.getFull(f).getCella(j,k).getDada().setTipus(atributs[2].charAt(0));
						ControladorDomini.getFull(f).getCella(j,k).setMida(Double.parseDouble(atributs[3]));
						ControladorDomini.getFull(f).getCella(j,k).setColor(Integer.parseInt(atributs[4]));
						if(atributs[5].equals("t")) ControladorDomini.getFull(f).getCella(j,k).setFormatBold(true);
						else ControladorDomini.getFull(f).getCella(j,k).setFormatBold(false);
						if(atributs[6].equals("t")) ControladorDomini.getFull(f).getCella(j,k).setFormatItalics(true);
						else ControladorDomini.getFull(f).getCella(j,k).setFormatItalics(false);
						if(atributs[7].equals("t")) ControladorDomini.getFull(f).getCella(j,k).setFormatUnderline(true);
						else ControladorDomini.getFull(f).getCella(j,k).setFormatUnderline(false);
						if(atributs[8].equals("t")) ControladorDomini.getFull(f).getCella(j,k).setFormatConditional(true);
						else ControladorDomini.getFull(f).getCella(j,k).setFormatConditional(false);
						ControladorDomini.recalcularReferencies(j, k);
					}
					++aux;
				}
			}
	} catch(ArrayIndexOutOfBoundsException e) {
		throw new FuncioNoAplicable("Document corrupte");
	} catch(IndexOutOfBoundsException e) {
		throw new FuncioNoAplicable("Document corrupte");
	} catch(Exception e) {
		throw new FuncioNoAplicable("Document corrupte");
	}

	}

/* Carrega el document amb els continguts d'un Document de format CSV */
public static void carregarDocCSV(String Text, String path) throws FuncioNoAplicable
	{
		ControladorDomini.init();
		ControladorDomini.setPath(path);
		String nomDoc [] = path.split("/");
		String nom = nomDoc[nomDoc.length - 1];
		String nomD = nom.substring(0, nom.length() - 4);
		ControladorDomini.setNom(nomD);
		String files [] = Text.split("\r\n");
		if(files.length > ControladorDomini.getFull(0).getNumRows()) {
			ControladorDomini.getFull(0).addRowSet(0, files.length - ControladorDomini.getFull(0).getNumRows());
		}
		else if(files.length < ControladorDomini.getFull(0).getNumRows()) {
			ControladorDomini.getFull(0).deleteRowSet(0, ControladorDomini.getFull(0).getNumRows() - files.length);
		}
		
		String fila0 [] = files[0].split(",", -1);
		if(fila0.length > ControladorDomini.getFull(0).getNumColumns()) {
			ControladorDomini.getFull(0).addColSet(0, fila0.length - ControladorDomini.getFull(0).getNumColumns());
		}
		else if(fila0.length < ControladorDomini.getFull(0).getNumColumns()) {
			ControladorDomini.getFull(0).deleteColSet(0, ControladorDomini.getFull(0).getNumColumns() - files.length);
		}
		for (int i = 0; i < ControladorDomini.getFull(0).getNumRows(); ++i) {
			String celles [] = files[i].split(",", -1);
			for(int j = 0; j < ControladorDomini.getFull(0).getNumColumns(); ++j) {
				ControladorDomini.getFull(0).getCella(i,j).getDada().setContingut(celles[j]);
			}
		}
	}
	
	/*Elimina el fitxer del path*/
	public static void deleteDoc(String path) {
		File fichero = new File(path);
		fichero.delete();
		ControladorDomini.init();
	}


}
