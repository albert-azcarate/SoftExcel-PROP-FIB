package main;
import java.util.ArrayList;
import java.util.Scanner;

import Dominio.*;
import Presentacion.*;

public class main {
	
	static Document d;
	
	public static void main(String[] args) {
		String input;
		Scanner scanner = new Scanner(System.in).useDelimiter("\\n");
		
		ArrayList<Cella> func_dinam = new ArrayList<>();
		
		int i = 0;
		int j = 0, z = 0;

		ControladorDomini.init();
		CtrlPresentacio.init();

		
		d = Document.GetDoc();
		
		while(z == 0)
		{
			input = scanner.next();
			
			int fullActiu = d.GetFullActiu();
			Full f = d.GetFull(fullActiu);
			try {
				if (input.charAt(0) == '=') {
					if(input.charAt(1) == 'u') {
						for( Cella c: func_dinam) {
							//falta arreglar el afegir les celles a la matriu de referencies
							String a = ControladorDomini.parser("a" + c.getDada().getFormula(),c.getCols(),c.getRows(),true);
							//f.getCelles().get(c.getCols()).get(c.getRows()).setDada(a, c.getDada().getFormula());
						}
					} else {
						Cella c = f.getCelles().get(i).get(j);
						if(func_dinam.contains(c)){
							func_dinam.remove(c);
							func_dinam.add(c);
						} else {
							func_dinam.add(c);
						}
						input = input.substring(0, input.length()-1);
						String a = ControladorDomini.parser(input,i,j,true);
//						//System.out.print("Resultat = " + a + "\n" + input + "\n");
					}
				}
				else if(input.charAt(0) == '!') {
					input = input.substring(1);
					String formula, parametres;
					formula = input.substring(0, input.indexOf('('));
					parametres = input.substring(input.indexOf('(')+1, input.length()-2);
					String data[] = parametres.split(";");

					switch (formula)
					{
						case "COPIAR":
							ControladorDomini.copiar(data, f);
							f.print();
							break;
						case "ENGANXAR":
							ControladorDomini.enganxar(data, f);
							f.print();
							break;
						case "REEMP":
							ControladorDomini.substituir(data, f);
							f.print();
							break;
						case "MODIFICAR":
							ControladorDomini.modificar(data, f);
							f.print();
							break;
						case "ESBORRAR":
							ControladorDomini.esborrar(data, f);
							f.print();
							break;	
						case "ORDENAR":
							ControladorDomini.ordenar(data, f);
							f.print();
							break;
						case "APLICAR":
							ControladorDomini.aplicarFuncio(data, f);
							f.print();
							break;
						default:
							break;
					}
				}
				else {
					if(input.length()>2) { 
					String comprovacio = new String(""+input.charAt(0)+input.charAt(1));
					String entrada = "";
					int x = 0, y = 0;
					input = new String(input.substring(0, input.length() - 1));
					if (comprovacio.equals("ES") || comprovacio.equals("CO"))
					{
						input = new String(input.substring(0, input.length() - 1));
						String[] valor = input.split("\\(");
						input = new String(valor[0]);
						entrada = new String(valor[1]);
						
						if (comprovacio.equals("CO"))
						{
							valor = entrada.split(",");
						    
						    x = Integer.parseInt(valor[0]);
						    y = Integer.parseInt(valor[1]);
						}
					}
					switch (input)
					{
						case "LLEGIR":
							f.print();
							break;
						case "ESCRIU":
							f.getCelles().get(i).get(j).getDada().setContingut(entrada);
							//f.print();
							break;
						case "COORD":
							i = x;
							j = y;
							break;
						case "EXIT":
							//System.exit(0);
						default:
							break;
					}
					
					}
				}
				
				
			} catch (FuncioNoAplicable e) {
				System.out.print(e.getMessage());
			}
			
		}
	}
}