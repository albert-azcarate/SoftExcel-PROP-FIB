package Dominio;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import Persistencia.GestorFitxers;

public class ControladorDomini {

	private static Document d;
	
	private static List<String> formules;
	
	/* Inicialitzacio del controlador a un document donat */
	public static void init () {
		Document.creaSingleton();
		d = Document.GetDoc();
		saveFormules();
	}
	
	/* Getters */
	public static Boolean getMode() {
		return d.GetMode();
	}
	
	public static String getNomDocument() {
		return d.GetNom();
	}
	
	public static int getFullActiu() {
		return d.GetFullActiu();
	}
	
	public static Full getFull(int index) {
		return d.GetFull(index);
	}
	
	public static int getLenghtLlibreta() {
		return d.GetLengthLlibreta();
	}
	
	public static String getNomFull() {
		int index = d.GetFullActiu();
		return d.GetFull(index).getNomFull();
	}
	
	public static int getNumCols(){
		int index = d.GetFullActiu();
		return d.GetFull(index).getNumColumns();
	}
	
	public static int getNumRows(){
		int index = d.GetFullActiu();
		return d.GetFull(index).getNumRows();
	}
	
	public static Cella getCella(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y);
	}
	
	public static Dada getDada(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getDada();
	}
	
	public static String getContingut(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getDada().getContingut();
	}
	
	public static String getFormula(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getDada().getFormula();
	}
	
	public static char getTipus(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getDada().getTipus();
	}
	
	public static double getMida(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getMida();
	}
	
	public static int getColor(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getColor();
	}
	
	public static Boolean getFormatBold(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getFormatBold();
	}
	
	public static Boolean getFormatItalics(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getFormatItalics();
	}
	
	public static Boolean getFormatConditional(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getFormatConditional();
	}
	
	public static Boolean getFormatUnderline(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		return d.GetFull(index).getCella(x, y).getFormatUnderline();
	}
	
	public static String getPath() {
		return d.GetPath();
	}
	
	public static void setNom(String nom) {
		int index = d.GetFullActiu();
		d.GetFull(index).nombrarFull(nom);
	}


	
	/* Setter */
	public static void setPath(String fileName) {
		d.SetPath(fileName);
	}
	
	public static void setMida(int x, int y, double mida) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		d.GetFull(index).getCella(x, y).setMida(mida);
	}
	
	public static void setColor(int x, int y, int color) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		d.GetFull(index).getCella(x, y).setColor(color);
	}
	
	public static void setFormatBold(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		d.GetFull(index).getCella(x, y).formatBold();
	}
	
	public static void setFormatItalics(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		d.GetFull(index).getCella(x, y).formatItalics();
	}
	
	public static void setFormatUnderline(int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		d.GetFull(index).getCella(x, y).formatUnderline();
	}
	
	public static void switchFixatCol(int n) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).switchFixatCol(n);;
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No existeix la columna a la posicio " + n);
		}
	}
	
	public static void switchFixatRow(int n) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).switchFixatRow(n);;
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No existeix la columna a la posicio " + n);
		}
	}
	
	public static void switchOcultCol(int n) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).switchOcultCol(n);;
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No existeix la columna a la posicio " + n);
		}
	}

	
	/* Escriu un String a una cella */
	public static void escriu(String nou, int x, int y) throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		d.GetFull(index).getCella(x,y).getDada().setContingut(nou);
	}
	
	/* Modifica quin es el full amb el que es treballa */	
	public static void modificarFullActiu(int index) throws IndexNoValid {
		try {
			d.setFullActiu(index);
		}
		catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("El full " + index + " no existeix");		
		}
	}
	
	/* Mou el contingut d'un conjunt de Celles del Full actiu a les coordenades indicades */
	public static void moure(String inici, String fi, String desti) throws FuncioNoAplicable {
		String[] coordenades = {inici, fi, desti};
		List<String> celles = referencia(coordenades);
		
		Full f = d.GetFull(d.GetFullActiu());
		
		Cella a = f.getCella(Integer.parseInt(celles.get(0).split(";")[0]), Integer.parseInt(celles.get(0).split(";")[1]));
		Cella b = f.getCella(Integer.parseInt(celles.get(1).split(";")[0]), Integer.parseInt(celles.get(1).split(";")[1]));
		Cella c = f.getCella(Integer.parseInt(celles.get(2).split(";")[0]), Integer.parseInt(celles.get(2).split(";")[1]));
		
		f.moure(a, b, c);
	}

	
	/* Afegeix un full al final al document */
	public static void afegirFull() {
		d.afegirFull();
	}
	
	/* Nombra el full actiu amb nom */
	public static void nombrarFull(String nom) {
		int index = d.GetFullActiu();
		d.GetFull(index).nombrarFull(nom);
	}
	
	/* Mou el full i a la posicio j*/
	public static void ordenarFull(int i, int j) throws IndexNoValid {
		try{
			d.ordenarFulls(i, j);
		}
		catch (IndexOutOfBoundsException e) { 
			throw new IndexNoValid("Un dels fulls " + i + "," + " no existeix");
		}
	}
	
	/* Elimina un full per index */
	public static void eliminarFull(int index) throws IndexNoValid {
		try {
			d.eliminarFull(index);
		}
		catch(IndexOutOfBoundsException e) {
			throw new IndexNoValid("El full " + index + " no existeix");
		}
	}
	
	/* Afegeix una fila al full actiu */
	public static void addRow(int coord) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).addRow(coord);
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No es pot afegir la fila a la posicio " + coord);
		}
	}
	
	/* Afegeix un conjunt de files al full actiu */
	public static void addRowSet(int coord, int n) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).addRowSet(coord, n);
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No es pot afegir la fila a la posicio " + coord);
		}
	}
	
	/* Afegeix una columna al full actiu */
	public static void addCol(int coord) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).addCol(coord);
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No es pot afegir la columna a la posicio " + coord);
		}
	}
	
	/* Afegeix un conunt de columnes al full actiu */
	public static void addColSet(int coord, int n) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).addColSet(coord, n);
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No es pot afegir la columna a la posicio " + coord);
		}
	}
	
	/* Elimina una fila del full actiu */
	public static void delRow(int coord) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).deleteRow(coord);
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No existeix la fila a la posicio " + coord);
		}
	}
	
	/* Elimina una columna del full actiu */
	public static void delCol(int coord) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			d.GetFull(index).deleteCol(coord);
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No existeix la columna a la posicio " + coord);
		}
	}
	
	/* Elimina un conjunt de files del full actiu */
	public static int delRowSet(int coord, int n) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			int elim = d.GetFull(index).deleteRowSet(coord, n);
			return elim;
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No existeix la fila a la posicio " + coord);
		}
	}
	
	/* Elimina un conjunt de columnes del full actiu */
	public static int delColSet(int coord, int n) throws IndexNoValid {
		try {
			int index = d.GetFullActiu();
			int elim = d.GetFull(index).deleteColSet(coord, n);
			return elim;
		} catch (IndexOutOfBoundsException e) {
			throw new IndexNoValid("No existeix la columna a la posicio " + coord);
		}
	}
	
	/* Canvia el mode de color */
	public static void switchMode() {
		d.SwitchMode();
	}
	
	/* Modifica tot el contingut del full actiu per al nou string */
	public static void modificarContingutFull(String nou) {
		int index = d.GetFullActiu();
		d.GetFull(index).modificarContinguts(nou);
	}
	
	/* Desfa l'ultima accio del full actiu */
	public static void desfes() throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		d.GetFull(index).desfes();
	}
	
	/* Refa l'ultima accio del full actiu */
	public static void refer() throws FuncioNoAplicable {
		int index = d.GetFullActiu();
		d.GetFull(index).refer();
	}
	
	/* Guarda un document en format csv al path*/
	public static void guardarDocCSV(String path) throws IndexNoValid, IOException{
		GestorFitxers.escriuFitxerCSV(path);
	}
	
	/* Guarda un document en format pdf al path*/
	public static void guardarDocPDF(String path) throws IndexNoValid, IOException{
		GestorFitxers.escriuFitxerPDF(path);
	}
	
	/* Guarda un document en format propi al path*/
	public static void guardarDocFormatPropi(String path) throws IndexNoValid, IOException, FuncioNoAplicable{
		GestorFitxers.escriuFitxer(path);
	}
	
	/* Recalcula el contingut de les celles que tenen alguna referencia a la cella x,y*/
	public static void recalcularReferencies(int x, int y) throws FuncioNoAplicable{
		int index = d.GetFullActiu();
		Cella c = d.GetFull(index).getCella(x, y);
			//per a la cella recent cambiada recorrem tota la matriu mirant si tenim refencies daquesta
		for( int i = 0; i < d.GetFull(index).getNumRows(); ++i) {
			for(int j = 0; j < d.GetFull(index).getNumColumns(); ++j) {
					//si aquesta cella es referenciada per algú entrem
				if(d.GetFull(index).getReferencies().get(i).get(j).contains(c)) {
						//afagem la formula, la passem de nou pel parser i guardem la nova dada
					String og = d.GetFull(index).getCella(i, j).getDada().getContingut();
					String formula = d.GetFull(index).getCella(i, j).getDada().getFormula();
					try {
						String cont = ControladorDomini.parser(formula, i, j, true);
						d.GetFull(index).getCella(i, j).setDada(cont, formula);
					}catch(FuncioNoAplicable e) {
						d.GetFull(index).getCella(i, j).setDada(og, formula);
					}
						//ja que hem cambiat aquesta cella, cal revisar si aquesta te referencies a altres
					recalcularReferencies(i, j);
				}
			}
		}		
	}
	
	/*Eliminia el fitxer del path*/
	public static void eliminarDoc(String path) {
		GestorFitxers.deleteDoc(path);
	}

	
	/*Carrega el document en format csv del path*/
	public static void carregarDocCSV(String path) throws FileNotFoundException, IOException, FuncioNoAplicable {
		String Text = GestorFitxers.llegeixFitxer(path);
		GestorFitxers.carregarDocCSV(Text, path);
	}
	
	/*Carrega el document en format propi del path*/
	public static void carregarDocFormatPropi(String path) throws FileNotFoundException, IOException, FuncioNoAplicable {
		String Text = GestorFitxers.llegeixFitxer(path);
		GestorFitxers.carregarDocPropi(Text,path);
	}
	
	/* Parser recursiu per a les formules de les celles */
	public static String parser(String input, int x, int y, boolean primera) throws FuncioNoAplicable {
		String origin = new String(input);

		if(input.equals(""))
		{
			d.GetFull(d.GetFullActiu()).getCelles().get(x).get(y).setDada("", "");
			return "";
		}
		if(input.equals("=")) throw new FuncioNoAplicable("Funcio incompleta \n");
			//No s'ha insertat una formula a la Cella, sino un input basic
		if (input.contains("_")) throw new FuncioNoAplicable("El simbol _ no es un caracter permes.");
		    //El simbol _ es fa servir per al format propi i no el podem permetre com a part del contingut del full de calcul
		if (input.charAt(0) != '=' && primera)
		{
			Full f =  d.GetFull(d.GetFullActiu());
			Cella old = f.getCelles().get(x).get(y);
			f.getCanvis().push(new Cella(old));
			f.getDesfets().clear();
				//S'esborra la formula (si n'hi havia) de la Dada de la Cella
			if(!input.equals(old.getDada().getContingut())) 
				old.getDada().setFormula("");
				//S'escriu el nou valor al contingut de la Dada de la Cella
			old.getDada().setContingut(input);
			f.removeReferencia(old);
			recalcularReferencies(x,y);
			return input;
		}
		
		if (input.charAt(0) == '=') input = input.substring(1);
		
		if(input.matches("[a-zA-Z]{1,4}\\d{1,4}")) {
			Full f =  d.GetFull(d.GetFullActiu());
			String[] ref = {input};
			List<String> refe = referencia(ref);
			
			ref = refe.get(0).split(";");
			Cella c =  f.getCelles().get(Integer.parseInt(ref[0])).get(Integer.parseInt(ref[1]));
			Cella newc = f.getCelles().get(x).get(y);
			
			if(!f.addReferencia(newc, c)) throw new FuncioNoAplicable("Error al fer la referencia: bucles no admesos");
			
			f.getCanvis().push(new Cella(newc));
			f.getDesfets().clear();
			newc.setDada(c.getDada().getContingut(), origin);
			recalcularReferencies(x,y);
			
			return newc.getDada().getContingut();
		}
			//Comprovacio de parentesis
		int ob = 0, tan = 0;
		for (int i = 0; i < input.length(); i++){
			if (input.charAt(i) == '(') ob++;
			else if (input.charAt(i) == ')') tan++;
			if (tan > ob) {
				throw new FuncioNoAplicable("Error en els parentesis: " + input.substring(0, i+1) + "\n");
			}
		}
		if (ob != tan) {
			throw new FuncioNoAplicable("Error en els parentesis \n");
		}
		
		if(input.length()>1) {
			int i = 1;
			while (input.charAt(input.length()-i) != ')') {
				if(input.charAt(input.length()-i) != ' ' && i != 1)
					throw new FuncioNoAplicable("Parametres invalids: " + input.charAt(input.length()-i) + "\n");
				i++;
			}
			input = input.substring(0,input.length()-i);
		}
		
		Cella old;
		if(primera) old = new Cella(d.GetFull(d.GetFullActiu()).getCelles().get(x).get(y));
		else old = null;
		
		//System.out.print(input + "\n");
		String funcio = "";
		String parametres = "";
		
			//Cas base: funcio amb nomes parametres reals i no subfuncions
		if (ob == 1 && tan == 1) {
				//Separem el nom de la funcio que volem fer
			funcio = input.substring(0, input.indexOf('('));
			//System.out.print(funcio + " BASE \n");
				//parametres passa de ser FUNC(1;C2;4;[...]) a 1;C2;4;[...]
			try {
				parametres = input.substring(input.indexOf('(')+1);
			} catch (IndexOutOfBoundsException e) {
				throw e;
			}
			//System.out.print(parametres + " BASE \n");
				//Es divideix el vector per la | (si es dona el cas que n'hi ha)
			String[] factors;
			factors = parametres.split("\\|");
				//La primera meitat de (o tot) parametres passa de ser 1;2;SUM(B1;2);4;[...] a {1},{2},{SUM(B1;2)},{4},[...]
			List<String> sts = referencia(factors[0].split(";"));
			parametres = "";
				//parametres passa a ser 1;(contingut_C2);4;[...]
			Full f = d.GetFull(d.GetFullActiu());
			for (String s : sts) {
				//System.out.print(s + "\n");
				if (s.contains(";")) {
					int coordx = Integer.parseInt(s.substring(0, s.indexOf(';')));
					int coordy = Integer.parseInt(s.substring(s.indexOf(';') + 1, s.length()));
					Cella cref = f.getCelles().get(coordx).get(coordy);
					if(coordx >= 0 && coordx <=  f.getNumRows() && coordy >= 0 && coordy <= f.getNumColumns()) {
						s = new String(cref.getDada().getContingut());
					}
					else throw new FuncioNoAplicable("Index fora de rang: " + getAlpha(coordy+1) + coordx + "\n");
					if(!f.addReferencia(f.getCella(x, y), cref)) throw new FuncioNoAplicable("Error al fer la referencia: bucles no admesos");
				}
				parametres += s + ";";
			}
				//Si la funcio inclou un | i es tracta de COVAR i PEARSON (les dues uniques funcions amb divisio entre dos conjunts de valors) es repeteix la revisio de referencies
			if (factors.length == 2 && (funcio.equals("COVAR") || funcio.equals("PEARSON")))
			{
					//S'elimina l'ultim ; sobrant
				parametres = parametres.substring(0,parametres.length()-1);
					//S'afegeix el | de separacio a parametres altre cop
				parametres += "|";
					//La segona meitat de parametres passa de ser 1;2;SUM(B1;2);4;[...] a {1},{2},{SUM(B1;2)},{4},[...]
				List<String> segonConjunt = referencia(factors[1].split(";"));
				for (String c : segonConjunt) {
					//System.out.print(c + "\n");
					if (c.contains(";")) {
						int coordx = Integer.parseInt(c.substring(0, c.indexOf(';')));
						int coordy = Integer.parseInt(c.substring(c.indexOf(';') + 1, c.length()));
						Cella cref = f.getCelles().get(coordx).get(coordy);
						if(coordx >= 0 && coordx <=  f.getNumColumns() && coordy >= 0 && coordy <= f.getNumRows())
							c = new String(cref.getDada().getContingut());
						else throw new FuncioNoAplicable("Index fora de rang: " + getAlpha(coordy+1) + coordx + "\n");
						if(!f.addReferencia(f.getCella(x, y), cref)) throw new FuncioNoAplicable("Error al fer la referencia: bucles no admesos");
					}
					parametres += c + ";";
				}
			}
				//Si qualsevol funcio que no sigui COVAR i PEARSON te un |, o COVAR o PEARSON tenen mes d'un |, salta l'excepcio
			else if (factors.length > 1) throw new FuncioNoAplicable("Comprova que no hagis usat | en algun input. No es un caracter permes a les operacions.\n");
				//S'elimina l'ultim ; sobrant
			parametres = parametres.substring(0,parametres.length()-1);
			//System.out.print("Parametres despres del parser: " + parametres + "\n");
			String matematiques;
			if(primera) {
				f.getCanvis().push(new Cella(old));
				f.getDesfets().clear();
				matematiques = funcions_matematiques(funcio, parametres, x, y);
				f.getCella(x, y).setDada(matematiques, origin);
			}
			else matematiques = funcions_matematiques(funcio, parametres, x, y);
			recalcularReferencies(x,y);
			
			return matematiques;
		}
			//Cas recursiu: tenim minim una subfuncio dins
		else {
			if (input.contains("COVAR") || input.contains("PEARSON")) throw new FuncioNoAplicable("Les funcions compostes no admeten les operacions COVAR ni PEARSON.");
			if(!input.contains("(")) throw new FuncioNoAplicable("El contingut introduit no es una funcio valida");
				//Separem el nom de la funcio que volem fer
			funcio = input.substring(0, input.indexOf('('));
			//System.out.print(funcio + " RECURS \n");
				//parametres passa de ser FUNC(1;2;SUM(B1;2);4;[...]) a 1;2;SUM(B1;2);4;[...]
			parametres = input.substring(input.indexOf('(')+1);
			//System.out.print(parametres+ " RECURS \n");
				//parametres passa de ser 1;2;SUM(B1;2);4;[...] a {1},{2},{SUM(B1;2)},{4},[...]
			List<String> param = separar_param(parametres);
				//Buidem el string parametres
			parametres = "";
				//Iterem sobre tots els strings de parametres generals 
			for (String s : param){
					//Si es una subformula cridem de nou al parser
				if (s.contains("(")) {
					String new_formula = s.substring(0, s.indexOf('('));
					if (formules.contains(new_formula)){
						try {
							s = parser(s,x,y, false);
						} catch (FuncioNoAplicable e) {
							throw e;
						}
					}
					else throw new FuncioNoAplicable(new_formula + ": la formula no es valida.");
				}
					//Si es un parametre que es una referencia a una cella
				else if (s.matches("[a-zA-Z]{1,4}\\d{1,4}")) {
					List<String> sts = referencia(s.split(";"));
					s = sts.get(0); 
					if (s.contains(";")) {
						int coordx = Integer.parseInt(s.substring(0, s.indexOf(';')));
						int coordy = Integer.parseInt(s.substring(s.indexOf(';') + 1, s.length()));
						Full f = d.GetFull(d.GetFullActiu());
						Cella cref =  f.getCelles().get(coordx).get(coordy);
						s = cref.getDada().getContingut();
						if(!f.addReferencia(f.getCella(x, y), cref)) throw new FuncioNoAplicable("Error al fer la referencia: bucles no admesos");
						
					}
				}
					//Afegim s a parametres
				parametres += s + ";";
			}
			parametres = parametres.substring(0, parametres.length()-1);
			//System.out.print(parametres + " final \n");
			String matematiques;
			if(primera) {
				Full f = d.GetFull(d.GetFullActiu());
				f.getCanvis().push(new Cella(old));
				f.getDesfets().clear();
				matematiques = funcions_matematiques(funcio, parametres, x, y);
				f.getCella(x, y).setDada(matematiques, origin);
			}
			else matematiques = funcions_matematiques(funcio, parametres, x, y);
			recalcularReferencies(x,y);
			
			return matematiques;
		}
	}

	
	// CAL AVISAR QUE HI HA CELLES REFERENCIADES ABANS D'ESBORRAR EL CONTINGUT D'UNA CELLA
	
	/* Copia el contingut d'un Bloc del Full actiu al porta-retalls del Document d */
	public static void copiar(String[] data, Full f) throws FuncioNoAplicable {
		Bloc b = creaBloc(data,f);
		b.copiar(d);
	}
	
	/* Enganxa el contingut del porta-retalls del Document d a un Bloc */
	public static void enganxar(String[] data, Full f) throws FuncioNoAplicable {
		if(data.length != 1)throw new FuncioNoAplicable("Parametres invalids\n");
			//clonem la copia dins del document
		Bloc b = d.GetCopia().clone();
		String[] pros_dat = new String[2];
		data[0] = data[0].toUpperCase();
		if(data[0].matches("[a-zA-Z]{1,4}\\d{1,4}")) {
				//separem la fila i la columna
			for(int i = 0; i < data[0].length(); i++) {
				if(data[0].charAt(i) >= '0' && data[0].charAt(i) <= '9') {
					pros_dat[1] = data[0].substring(i);
					pros_dat[0] = data[0].substring(0,i);
				}
			}
			int col = fromBase26(pros_dat[0]) - 1;
			int rows = Integer.parseInt(pros_dat[1]) + b.getRows();
			int cols = col + b.getCols();
			if(rows > f.getNumRows() ||cols > f.getNumColumns()) throw new FuncioNoAplicable("Atencio: Anaves a enganxar una cosa fora del full\n");
				//si les dades son valides, enganxem la copia
			b.enganxar(d, f, Integer.parseInt(pros_dat[1]), col);
		}
		else throw new FuncioNoAplicable("Parametres invalids\n");
	}
	
	/* Modifica el contingut d'un Bloc del Full actiu */
	public static void modificar(String[] data, Full f) throws FuncioNoAplicable {
		if(data.length != 3)throw new FuncioNoAplicable("Parametres invalids\n");
		Bloc b = creaBloc(data,f);
			//si la dada a posar es una referencia, extreiem la dada de la cella
		if(data[2].matches("[a-zA-Z]{1,4}\\d{1,4}")) {
			String refe[] = new String[1]; String coord[] = new String[2];
			refe[0] = data[2];
			coord = referencia(refe).get(0).split(";");
			Cella c = f.getCella(Integer.parseInt(coord[0]), Integer.parseInt(coord[1]));
			b.modificarContinguts(c.getDada().getContingut());
		}
		else{
			b.modificarContinguts(data[2]);
		}
		b.to_full(f);
	}
	
	/* Substitueix el contingut de les Celles coincidents d'un Bloc del Full actiu */
	public static void substituir(String[] data, Full f) throws FuncioNoAplicable {
		if(data.length != 4) throw new FuncioNoAplicable("Parametres invalids\n");
			//si cap dels dos valors a substituir es una referencia agafem la dada corresponent
		if(data[2].matches("[a-zA-Z]{1,4}\\d{1,4}")) {
			String refe[] = new String[1]; String coord[] = new String[2];
			refe[0] = data[2];
			coord = referencia(refe).get(0).split(";");
			Cella c = f.getCella(Integer.parseInt(coord[0]), Integer.parseInt(coord[1]));
			data[2] = c.getDada().getContingut();
		}
		if(data[3].matches("[a-zA-Z]{1,4}\\d{1,4}")) {
			String refe[] = new String[1]; String coord[] = new String[2];
			refe[0] = data[3];
			coord = referencia(refe).get(0).split(";");
			Cella c = f.getCella(Integer.parseInt(coord[0]), Integer.parseInt(coord[1]));
			data[3] = c.getDada().getContingut();
		}

		Bloc b = creaBloc(data,f);
		b.reemplassar(data[2], data[3]);
		b.to_full(f);
		
	}
	
	/* Esborra el contingut d'un Bloc del Full actiu */
	public static void esborrar(String[] data, Full f) throws FuncioNoAplicable {
		Bloc b = creaBloc(data,f);
		b.esborrar();
		for(int i = 0; i < b.getmt().size(); i++) 
			for(int j = 0; j < b.getmt().get(i).size(); j++) f.removeReferencia(b.getmt().get(i).get(j));
		b.to_full(f);
	}
	
	/* Busca el contingut de les Celles coincidents d'un Bloc del Full actiu 
	 * Retornem el valor a data[0] per que vista ho tingui
	 * */
	public static void buscar(String[] data, Full f) throws FuncioNoAplicable {
		if(data.length != 3) throw new FuncioNoAplicable("Parametres invalids\n");
		//si la dada a buscar es una referencia, extreiem la dada de la cella
		if(data[2].matches("[a-zA-Z]{1,4}\\d{1,4}")) {
			String refe[] = new String[1]; String coord[] = new String[2];
			refe[0] = data[2];
			coord = referencia(refe).get(0).split(";");
			Cella c = f.getCella(Integer.parseInt(coord[0]), Integer.parseInt(coord[1]));
			data[2] = c.getDada().getContingut();
		}
		Bloc b = creaBloc(data,f);
		data[0] = String.valueOf(b.cercaContinguts(data[2]));
	}
	
	/* Ordena el contingut d'un Bloc del Full actiu */
	public static void ordenar(String[] data, Full f) throws FuncioNoAplicable {
		if(data.length != 3) throw new FuncioNoAplicable("Parametres invalids\n");
		Bloc b = creaBloc(data,f);
			//ordenem el bloc segons el criteri de data[2]
		b.ordenar(data[2]);
		for(int i = 0; i < b.getmt().size(); i++) 
			for(int j = 0; j < b.getmt().get(i).size(); j++) f.removeReferencia(b.getmt().get(i).get(j));
		b.to_full(f);
	}
	
	public static void aplicarFuncio(String[] data, Full f) throws FuncioNoAplicable{
		if(data.length != 2) throw new FuncioNoAplicable("Parametres invalids\n");
		Bloc b = creaBloc(data,f);
			//comprobem que siguin o files o columnes
		if(b.getCols() > 1 && b.getRows() > 1) throw new FuncioNoAplicable("Nomes es pot aplicar una funcio a files o columnes\n");
			//agafem la cella origianl de la qual hem de extendre la funcio
		Cella c_orig = b.getmt().get(0).get(0);
			//per a cada cella del bloc aplicarem la nova funcio i cridarem de nou al parser
		b.aplicarFuncio(c_orig, f);
		for(int i = 0; i < b.getmt().size(); i++) {
			for(int j = 0; j < b.getmt().get(i).size(); j++) {
				Cella c = b.getmt().get(i).get(j);
				try {
						//contant el desplasament del bloc, posem la dada recalculada
					String resul = parser(c.getDada().getFormula(), c.getCols(), c.getRows(),true);
					f.getCelles().get(i+b.getinitX()).get(j+b.getinitY()).setDada(resul,c.getDada().getFormula());
				}catch(FuncioNoAplicable e) {
						//si la funcio no es possible per a males referencies, podem error
					f.getCelles().get(c.getCols()).get(c.getRows()).getDada().setFormula("");
					f.getCelles().get(c.getCols()).get(c.getRows()).getDada().setContingut("#ERROR");
				}
			}
		}
	}
	
	/* Pinta un Bloc */
	public static void pintarBloc(String[] data, Full f) throws FuncioNoAplicable {
		if (data.length != 3) throw new FuncioNoAplicable("Has d'introduir tres parametres:\nCella inicial;Cella final;Color");
		Bloc b = creaBloc(data,f);
		b.setColors(data[2], f);
	}

	
		//crea un bloc de tamany especificar a data[0] i data[1]
	private static Bloc creaBloc(String data[], Full f) throws FuncioNoAplicable{
		if(data.length <= 1) {
			throw new FuncioNoAplicable("Parametres Erronis \n");
		}
		String data_ref[] = {data[0],data[1]}; 
		List<String> dat = referencia(data_ref);
		data[0] = dat.get(0);
		data[1] = dat.get(1);
		String[] data1 = data[0].split(";");
		////System.out.print(data1[0] +" "+ data1[1] +" "+ data2[0]+" "+ data2[1]+" " );
		String[] data2 = data[1].split(";");
		
		String format = "[a-zA-Z]{1,4}\\d{1,4}";
		if(data_ref[0].matches(format) && data_ref[1].matches(format)) {
			if((Integer.valueOf(data2[0]) - Integer.valueOf(data1[0])) < 0) {
				throw new FuncioNoAplicable("El rang seleccionat es negatiu \n");
			}
			if(Integer.valueOf(data2[1]) - Integer.valueOf(data1[1]) < 0) {
				throw new FuncioNoAplicable("El rang seleccionat es negatiu \n");
			}
			
			Bloc b = new Bloc(Integer.valueOf(data1[0]) , Integer.valueOf(data1[1]) ,Integer.valueOf(data2[0])-Integer.valueOf(data1[0])+1,  Integer.valueOf(data2[1])-Integer.valueOf(data1[1])+1, f);
			return b;
		}
		else throw new FuncioNoAplicable("Parametres no valids: " + data_ref[0] + ";" + data_ref[1] + "\n");
	}

	
	/* Seleccio de les funcions de Cella */
	public static String funcions_matematiques(String formula, String parametres, int i, int j) throws FuncioNoAplicable {
		List<String> param = new ArrayList<String>(separar_param(parametres));
		
			//Iterem sobre tots els Strings de parametres generals 
		Full f = d.GetFull(d.GetFullActiu());
		
		switch (formula)
		{
			case "TRUNCDEC":
				try {
					try {
						if (param.size() == 1) f.getCelles().get(i).get(j).getDada().numericaTruncament(formula, "", Integer.parseInt(param.get(0)));
						else if (param.size() == 2) f.getCelles().get(i).get(j).getDada().numericaTruncament(formula, param.get(0), Integer.parseInt(param.get(1)));
						else throw new FuncioNoAplicable("L'operacio no admet " + param.size() + " parametres. El minim es 1 i el maxim son 2.");
					}
					catch (NumberFormatException nfe) {
						throw new FuncioNoAplicable(formula + ": la quantitat de xifres decimals indicada a deixar despres de truncar ha de ser un valor enter.");
					}
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "TRUNCINT":
				try {
					if (param.size() == 0) f.getCelles().get(i).get(j).getDada().numericaTruncament(formula, "");
					else if (param.size() == 1) f.getCelles().get(i).get(j).getDada().numericaTruncament(formula, param.get(0));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim son 0 i el maxim es 1.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "CONVDEC":
				try {
					if (param.size() == 0) f.getCelles().get(i).get(j).getDada().numericaConversio(formula, "");
					else if (param.size() == 1) f.getCelles().get(i).get(j).getDada().numericaConversio(formula, param.get(0));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim son 0 i el maxim es 1.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "CONVBASE":
				try {
					if (param.size() == 1) f.getCelles().get(i).get(j).getDada().numericaConversio(formula, "", param.get(0).charAt(0));
					else if (param.size() == 2) f.getCelles().get(i).get(j).getDada().numericaConversio(formula, param.get(0), param.get(1).charAt(0));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim es 1 i el maxim son 2.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "INC":
				try {
					try {
						if (param.size() == 1) f.getCelles().get(i).get(j).getDada().unaria(formula, "", Integer.parseInt(param.get(0)));
						else if (param.size() == 2) f.getCelles().get(i).get(j).getDada().unaria(formula, param.get(0), Integer.parseInt(param.get(1)));
						else throw new FuncioNoAplicable("L'operacio no admet " + param.size() + " parametres. El minim es 1 i el maxim son 2.");
					}
					catch (NumberFormatException nfe) {
						throw new FuncioNoAplicable(formula + ": la quantitat d'increments ha de ser un numero (decimal o enter).");
					}
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "ABS":
				try {
					if (param.size() == 0) f.getCelles().get(i).get(j).getDada().unaria(formula, "");
					else if (param.size() == 1) f.getCelles().get(i).get(j).getDada().unaria(formula, param.get(0));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim son 0 i el maxim es 1.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "SUM":
				try {
					f.getCelles().get(i).get(j).getDada().naria(formula, parametres);
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "RES":
				try {
					f.getCelles().get(i).get(j).getDada().naria(formula, parametres);
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "MUL":
				try {
					f.getCelles().get(i).get(j).getDada().naria(formula, parametres);
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "DIV":
				try {
					f.getCelles().get(i).get(j).getDada().naria(formula, parametres);
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "DATELEM":
				try {
					if (param.size() == 1) f.getCelles().get(i).get(j).getDada().data(formula, "", param.get(0).charAt(0));
					else if (param.size() == 2) f.getCelles().get(i).get(j).getDada().data(formula, param.get(0), param.get(1).charAt(0));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim es 1 i el maxim son 2.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "DATADIA":
				try {
					if (param.size() == 0) f.getCelles().get(i).get(j).getDada().data(formula, "");
					else if (param.size() == 1) f.getCelles().get(i).get(j).getDada().data(formula, param.get(0));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim son 0 i el maxim es 1.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "REECAR":
				try {
					if (param.size() == 2) f.getCelles().get(i).get(j).getDada().textSubstituir(formula, "", param.get(0), param.get(1));
					else if (param.size() == 3) f.getCelles().get(i).get(j).getDada().textSubstituir(formula, param.get(0), param.get(1), param.get(2));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim son 2 i el maxim son 3.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "MINMAJ":
				try {
					if (param.size() == 1) f.getCelles().get(i).get(j).getDada().textSubstituir(formula, "", param.get(0).charAt(0));
					else if (param.size() == 2) f.getCelles().get(i).get(j).getDada().textSubstituir(formula, param.get(0), param.get(1).charAt(0));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim es 1 i el maxim son 2.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "NUMCAR":
				try {
					if (param.size() == 0) f.getCelles().get(i).get(j).getDada().textLongitud(formula, "");
					else if (param.size() == 1) f.getCelles().get(i).get(j).getDada().textLongitud(formula, param.get(0));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim son 0 i el maxim es 1.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "NUMCON":
				try {
					if (param.size() == 1) f.getCelles().get(i).get(j).getDada().textLongitud(formula, "", param.get(0));
					else if (param.size() == 2) f.getCelles().get(i).get(j).getDada().textLongitud(formula, param.get(0), param.get(1));
					else throw new FuncioNoAplicable(formula + ": l'operacio no admet " + param.size() + " parametres. El minim es 1 i el maxim son 2.");
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "MIT":
				try {
					f.getCelles().get(i).get(j).getDada().estadistica(formula, parametres);
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "MED":
				try {
					f.getCelles().get(i).get(j).getDada().estadistica(formula, parametres);
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "VAR":
				try {
					f.getCelles().get(i).get(j).getDada().estadistica(formula, parametres);
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "COVAR":
				if (parametres.contains("|"))
				{
					String[] p = parametres.split("\\|");
					try {
						f.getCelles().get(i).get(j).getDada().estadistica(formula, p[0], p[1]);
					}
					catch (FuncioNoAplicable fna) {
						throw fna;
					}
				}
				break;
			case "STDEV":
				try {
					f.getCelles().get(i).get(j).getDada().estadistica(formula, parametres);
				}
				catch (FuncioNoAplicable fna) {
					throw fna;
				}
				break;
			case "PEARSON":
				if (parametres.contains("|"))
				{
					String[] p = parametres.split("\\|");
					try {
						f.getCelles().get(i).get(j).getDada().estadistica(formula, p[0], p[1]);
					}
					catch (FuncioNoAplicable fna) {
						throw fna;
					}
				}
				break;
			default:
				throw new FuncioNoAplicable("Funcio no valida: " + formula);
		}
		return f.getCelles().get(i).get(j).getDada().getContingut();
	}
	
  	/* Retorna una llista dels arguments que es troben al mateix nivell */
    private static List<String> separar_param (String param) {
        List<String> parametres_fin = new ArrayList<String>();
        	//Comptador de parentesis
        int par = 0;
        	//Index d'on comenca el seguent argument
        int newIdx = 0;
        
        for (int i = 0; i < param.length(); i++) {
            if (param.charAt(i) == '(') par++;
            else if (param.charAt(i) == ')') par--;
            else if (param.charAt(i) == ';' /* || param.charAt(i) == '|' */) {
                if (par == 0) {
                		//Si par == 0 significa que no estem dins una subfuncio
                	parametres_fin.add(param.substring(newIdx, i));
                    newIdx = i + 1;
                }
            }
        }
        
        	//Afegir l'utim argument
        if (newIdx < param.length()) parametres_fin.add(param.substring(newIdx));
        return parametres_fin;
    }
	
    /* Retorna la cella on apunta una referencia */
    public static List<String> referencia (String[] dades) throws FuncioNoAplicable {
    	List<String> ret = new ArrayList<String>();
    	
    	for(int i = 0; i < dades.length; i++) ret.add(null);
		try{
				//Iterem respecte a tots els parametres per passar-los de coordenades alfanumeriques a coordenades de Cella
			for(int i = 0; i < dades.length; i++) {
				int temp2 = 0;
				ret.set(i, "");
				String lletres = new String();
				String nums = new String();
				Boolean encara_lletra = true;
				Character dada;
				

				if(dades[i].matches("[a-zA-Z]{1,4}\\d{1,4}")) {
					for(int j = 0; j < dades[i].length(); j++) {
						dada = dades[i].charAt(j);
							//Dins de cada parametre busquem les lletres
						if (encara_lletra &&(dada >= 'A' && dada <= 'Z' || dada >= 'a' && dada <= 'z' )) {
							lletres += (dada);
							
						} else if (dada <= '9' && dada >= '0') {
							temp2 = (dada - '0');
							nums += temp2;
							encara_lletra = false;
						}
							//Si es un espai no fem res
						else if (dada == ' ');
						else {
								//Aquest cas es en el que es un char no valid o una referencia de erronea Ex: A2A
							throw new FuncioNoAplicable("Error dins la formula: " + lletres + nums + dades[i].substring(j) + "\n");
						}
					}
				}
				else ret.set(i, dades[i] + ";");
				
					//Passem de String a int
				if(nums.length() > 0) {
					temp2 = Integer.valueOf(nums);
					int columnes = fromBase26(lletres.toUpperCase())-1;
					if(temp2 >= d.GetFull(d.GetFullActiu()).getNumRows()) throw new IndexOutOfBoundsException("row:"+temp2);
					if(columnes >= d.GetFull(d.GetFullActiu()).getNumColumns()) throw new IndexOutOfBoundsException("col:" +  lletres.toUpperCase());
					if(lletres.length() == 0)ret.set(i, temp2 + ";");
					else ret.set(i, temp2 + ";" + (fromBase26(lletres.toUpperCase())-1) + ";");
				}
				
					//Afegim al vector de celles el valor cella o el numero que ens ha entrat directe
				ret.set(i, ret.get(i).substring(0, ret.get(i).length()-1));
				
			}
		}
			//Si hi ha una excepcio, anirem al catch 
		catch (IndexOutOfBoundsException e) {
			String err = e.getMessage();
			if(err.charAt(0) == 'r') {
				throw new FuncioNoAplicable("Error: Cella no existent al full, fila no creada " + err.substring(err.indexOf(":")+1) + "\n");
			}
			else {
				throw new FuncioNoAplicable("Error: Cella no existent al full, columna no creada " + err.substring(err.indexOf(":")+1) + "\n");
			}
		}
		return ret;
	}

    /* Passa de base alpha 26(A-Z) a numerica (0-9) */
    private static int fromBase26 (String number) {
		int s = 0;
		if (number != null && number.length() > 0) {
			s = (number.charAt(0) - 'A' +1);
			for (int i = 1; i < number.length(); i++) {
			s *= 26;
			s += (number.charAt(i) - 'A'+1);
			}
		}
		return s;
	}
	
    /* Passa de base numerica(0-9) a base alpha 26 (A-Z) */
	private static String getAlpha (int num) {
	    String result = "";
	    while (num > 0) {
	      num--; // 1 => a, not 0 => a
	      int remainder = num % 26;
	      char digit = (char) (remainder + 97);
	      result = digit + result;
	      num = (num - remainder) / 26;
	    }

	    return result.toUpperCase();
	}
	
	/* Emmagatzema totes les possibles funcions en una llista */
	private static void saveFormules ()
	{
		String[] formules_dat = {"TRUNCDEC","TRUNCINT","CONVDEC","CONVBASE","INC","ABS","SUM","RES","MUL","DIV","DATELEM","DATADIA","REECAR","MINMAJ","NUMCAR","NUMCON","MIT","MED","VAR","STDEV","COVAR","PEARSON"};
		formules = new ArrayList<String>();
		
		for (String f : formules_dat) formules.add(f);
	}
}
