package Dominio;

public class Entera extends Numerica {
	public Entera (Cella casella, String contingut, String formula) {
		super(casella, contingut, formula);
	}
	
	/* Funcions de conversio */
	public String numericaConversio (String tipus, String factor, char nou) throws FuncioNoAplicable {	
		if (tipus.equals("CONVBASE"))
		{
			int numConvertit = Integer.parseInt(factor);
				
				//Es converteix el valor enter a binari (si s'indica B) o hexadecimal (H)
			if (nou == 'B') return ("0b"+Integer.toBinaryString(numConvertit));
			else if (nou == 'H') return ("0x"+Integer.toHexString(numConvertit).toUpperCase());
			else throw new FuncioNoAplicable(tipus + ": no es pot convertir la dada al tipus " + nou + ".");
				//En cas que s'hagi introduit un tipus incorrecte al qual convertir el valor enter, salta l'excepcio FuncioNoAplicable
		}
		else if (tipus.equals("CONVRAD"))
		{
			// Opcional
		}
		
		return getContingut();
	}
}