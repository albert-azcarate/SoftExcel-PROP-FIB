package Dominio;
import java.util.*;

public class Full {

	private String nomFull;

	private int numRows;

	private int numColumns;
	
	private Stack<Cella> canvis;

	private Stack<Cella> desfets;

	private ArrayList<ArrayList<Cella>> celles;
	
	private ArrayList<ArrayList<Boolean>> fixat;
	
	private ArrayList<ArrayList<Boolean>> ocult;
	
	private ArrayList<ArrayList<ArrayList<Cella>>> referencies;

	/* Creadora d'un full donades files i columnes*/
	public Full (int xAxis, int yAxis)
	{
		nomFull = "New Sheet";
		numRows = xAxis;
		numColumns = yAxis;
		celles = new ArrayList<>(numColumns);
		fixat = new ArrayList<>(numColumns);
		ocult = new ArrayList<>(numColumns);
		referencies = new ArrayList<>(numColumns);
		for(int i=0; i < numRows; i++) {
			celles.add(new ArrayList<Cella>());
			fixat.add(new ArrayList<Boolean>());
			ocult.add(new ArrayList<Boolean>());
			referencies.add(new ArrayList<>());

		}

		for (int i = 0; i < xAxis; ++i)
		{
			for (int j = 0; j < yAxis; ++j)
			{				
				Cella c = new Cella(i,j, this);
				celles.get(i).add(j, c);
				fixat.get(i).add(j, false);
				ocult.get(i).add(j, false);
				referencies.get(i).add(new ArrayList<Cella>());
			}
		}
		canvis = new Stack<>();
		desfets = new Stack<>();
	}
	public Full (){
		nomFull = null;
	}
	
	/* Setters */
	public void nombrarFull(String nom) {
		nomFull = nom;
	}
	
	public void setCelles(ArrayList<ArrayList<Cella>> old) {
		celles = old;
	}
	
	public void switchFixatCol(int x) {
		for(int i = 0; i < numColumns; ++i) {
            fixat.get(i).set(x,!fixat.get(i).get(x));
		}
	}
	
	public void switchOcultCol(int x) {
		for(int i = 0; i < numColumns; ++i) {
            ocult.get(i).set(x,!ocult.get(i).get(x));
		}
	}
	
	public void switchFixatRow(int x) {
		for(int i = 0; i < numRows; ++i) {
            fixat.get(x).set(i,!fixat.get(x).get(i));
		}
	}
	
	public void switchOcultRow(int x) {
		for(int i = 0; i < numRows; ++i) {
            ocult.get(x).set(i,!ocult.get(x).get(i));
		}
	}






	/* Getters */
	public String getNomFull(){return nomFull;}

	public int getNumRows(){return numRows;}

	public int getNumColumns(){return numColumns;}
	
	public ArrayList<ArrayList<Boolean>> getOcult(){
		return ocult;
	}
	
	public ArrayList<ArrayList<Boolean>> getFixat(){
		return fixat;
	}

	public ArrayList<ArrayList<Cella>> getCelles(){
		return celles;
	}
	
	public ArrayList<ArrayList<ArrayList<Cella>>> getReferencies(){
		return referencies;
	}
	public Cella getCella(int x, int y) throws FuncioNoAplicable 
	{ 
		try {
			return celles.get(x).get(y);
		} catch (IndexOutOfBoundsException e) {
			throw new FuncioNoAplicable("Cella no existent");
		}
	}
	
	public Stack<Cella> getCanvis(){return canvis;}
	
	public Stack<Cella> getDesfets(){return desfets;}
	
	
	/* Detecta si existeix algun bucle en les referencies de celles*/
	public Boolean detectarBucle(ArrayList<Cella> ref, int it) {
		Boolean bucle = false;
		Cella c = ref.get(it);
		int x = c.getCols();
		int y = c.getRows();
		for (int i = it + 1; i < ref.size() & !bucle; ++i) {
			if (referencies.get(x).get(y).contains(ref.get(i))) bucle = true;
		}
		
		if (!bucle) {
			Boolean b = false;
			int j = 0;
			while(!b & j < referencies.get(x).get(y).size()) {
				ref.add(ref.size() - 1, referencies.get(x).get(y).get(j));
				b = detectarBucle(ref, it + 1);
				ref.remove(ref.size() - 1);
				++j;
			}
			
			return b;
			
		}
		else return bucle;
	}
	
	/*Afegeix la cella referenciada al conjunt de celles que la cella origen te referenciades,
	  en cas de que aixo generi un bucle no l'afegira i retornar false, altrament retorna true*/
	public Boolean addReferencia(Cella origen, Cella referenciada) {
		int x = origen.getCols();
		int y = origen.getRows();
		ArrayList<Cella> ref = new ArrayList<>();
		ref.add(referenciada);
		ref.add(origen);
		Boolean b = detectarBucle(ref, 0);
		if(!b) {
			referencies.get(x).get(y).add(referenciada);
			return true;
		}else return false;
	}
	
	/*Elimina les referencies del la cella c*/
	public void removeReferencia(Cella c) {
		int x = c.getCols();
		int y = c.getRows();
		while(!referencies.get(x).get(y).isEmpty()) {
			referencies.get(x).get(y).remove(0);
		}
	}
	
	/*Afegeix una fila*/
	public void addRow(int coord){
		celles.add(coord, new ArrayList<>(numColumns));
		referencies.add(coord, new ArrayList<>(numColumns));
		ocult.add(coord, new ArrayList<>(numColumns));
		fixat.add(coord, new ArrayList<>(numColumns));
		for (int j = 0; j < numColumns; ++j) {				
			Cella c = new Cella(coord, j, this);
			celles.get(coord).add(j, c);
			referencies.get(coord).add(j, new ArrayList<Cella>());
			ocult.get(coord).add(j, false);
			fixat.get(coord).add(j, false);
		}
		++numRows;
	}
	
	/*Afegeix una columna*/
	public void addCol(int coord){
		for (int i = 0; i < numRows; ++i) {
			Cella c = new Cella(coord, i, this);
			celles.get(i).add(coord, c);
			referencies.get(i).add(coord, new ArrayList<Cella>());
			ocult.get(i).add(coord, false);
			fixat.get(i).add(coord, false);
		}
		++numColumns;
		
	}
	
	/*Afegeix un conjunt de files*/
	public void addRowSet(int coord, int n){
		for (int i = 1; i <= n; ++i) {
			addRow(coord);
			++coord;
		}
	}
	
	/*Afegeix un conjunt de columnes*/
	public void addColSet(int coord, int n){
		for (int i = 1; i <= n; ++i) {
			addCol(coord);
			++coord;
		}
	}

	/*Elimina la fila coord*/
	public void deleteRow(int coord){
		celles.remove(coord);
		referencies.remove(coord);
		ocult.remove(coord);
		fixat.remove(coord);
		--numRows;
	}

	/*Elimina la columna coord*/
	public void deleteCol(int coord){
		for (int i = 0; i < numRows; ++i) {
			celles.get(i).remove(coord);
			referencies.get(i).remove(coord);
			ocult.get(i).remove(coord);
			fixat.get(i).remove(coord);
		}
		--numColumns;
	}
	
	/*Elimina n files desde la posicio coord*/
	public int deleteRowSet(int coord, int n){
		int rowEliminades = 0;
		if (coord < numRows) {
			for (int i = 1; i <= n; ++i){
				deleteRow(coord);
				++rowEliminades;
			}
		}
		
		return rowEliminades;
		
	}
	public int deleteColSet(int coord, int n){
		int colEliminades = 0;
		if (coord < numColumns) {
			for (int i = 1; i <= n; ++i){
				deleteCol(coord);
				++colEliminades;
			}
		}
		
		return colEliminades;
		
	}

	public void desfes() throws FuncioNoAplicable{
		if(!canvis.isEmpty()) {
			Cella canvi = new Cella(canvis.pop());
			Cella canviada = new Cella(celles.get(canvi.getCols()).get(canvi.getRows()));
			desfets.push(canviada);
			celles.get(canvi.getCols()).set(canvi.getRows(), new Cella(canvi));
		}else throw new FuncioNoAplicable("No hi ha res a desfer");
			
	}
	
	public void refer() throws FuncioNoAplicable{
		if(!desfets.isEmpty()) {
			Cella refet = new Cella(desfets.pop());
			Cella canviada = new Cella(celles.get(refet.getCols()).get(refet.getRows()));
			canvis.push(canviada);
			celles.get(refet.getCols()).set(refet.getRows(), new Cella(refet));
		}else throw new FuncioNoAplicable("No hi ha res a refer");
	}
	
	public void modificarContinguts(String contingut) {
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numColumns; j++) {
				celles.get(i).get(j).getDada().setContingut(contingut);
			}
		}
	}
	
	public void modificarCella(String contingut, int x, int y) {
		celles.get(x).get(y).getDada().setContingut(contingut);
	}
	
	
	public void print() {
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numColumns; j++) {		
				print_cell(celles.get(i).get(j).getDada().getContingut());
			}
			System.out.println();
		}
		System.out.println();
	}
	
	//funcio test per imprimir el contingut de la cella
	private void print_cell(String x) {
		System.out.printf("[");
		System.out.printf(" " + x + " ");
		System.out.printf("]");
	}
	
	/*Mou les celles entre inici i fi a desti*/
	public void moure(Cella inici, Cella fi, Cella desti)
	{
		int xDesti = desti.getRows();
		int yDesti = desti.getCols();
		int xInici = inici.getRows();
		int yInici = inici.getCols();
		int xFi = fi.getRows();
		int yFi = fi.getCols();
		for (int i = 0; i <= xFi - xInici; ++i) {
			for (int j = 0; j <= yFi - yInici; ++j) {
				Cella c = celles.get(i + xInici).get(j + yInici);
				c.setCols(j + yDesti);
				c.setRows(i + xDesti);
				celles.get(j + yDesti).set(i + xDesti, c);
				Cella buida = new Cella(i + xInici,j + yInici,this);
				celles.get(i +xInici).set(j + yInici, buida);
			}
		}
	}
	
}
