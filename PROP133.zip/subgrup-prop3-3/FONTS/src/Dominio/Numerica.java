package Dominio;

import java.util.ArrayList;

public class Numerica extends Dada {
	public Numerica (Cella casella, String contingut, String formula) {
		super(casella, contingut, formula);
	}
	
	/* Canvi de ',' a '.' per representar el valor adequadament per poder operar-hi com a double (prerequisit: valor N decimal) */
	public String aPunt (String valor) {
			//Es divideix el valor pel caracter ','
		String[] meitats = valor.split(",");
			//Es retorna el valor re-enganxat amb un '.' en lloc de la coma (si ja estava representat amb '.' i per tant no s'ha dividit en dos fragments, es retorna el valor original)
		if (meitats.length == 2) return (meitats[0] + '.' + meitats[1]);
		else return valor;
	}
	
	/* Canvi de '.' a ',' (prerequisit: valor N decimal) */
	public String aComa (String valor) {
			//Es divideix el valor pel caracter '.'
		String[] meitats = valor.split("\\.");
			//Es retorna el valor re-enganxat amb una ',' en lloc del punt (si ja estava representat amb ',' i per tant no s'ha dividit en dos fragments, es retorna el valor original)
		if (meitats.length == 2)
			return (meitats[0] + ',' + meitats[1]);
		else return valor;
	}
	
	private boolean esDecimal (String[] v)
	{
			//Es comprova que no hi hagi cap valor decimal dins el conjunt
		for (int i = 0; i < v.length; ++i)
		{
				//S'eliminen els espais que l'usuari podria haver afegit al caracter
			v[i] = new String(v[i]).trim();
				//Es compara el format del caracter amb el d'un numero decimal (N)
			if (v[i].matches("-{0,1}\\d{1,}(\\.\\d{1,}|,\\d{1,})")) return true;
		}
		
		return false;
	}
	
	/* Creadora d'una nova subclasse que coincideixi amb el tipus (canviant) de Dada */
	private void creaNumericaConcreta (String factor)
	{
		char tipusDada = checkTipus(factor);
		
		if (tipusDada == 'E') entera = new Entera(getCella(), factor, getFormula());
		else if (tipusDada == 'N') decimal = new Decimal(getCella(), factor, getFormula());
		else if (tipusDada == 'B')	binaria = new Binaria(getCella(), factor, getFormula());
		else if (tipusDada == 'H') hexadecimal = new Hexadecimal(getCella(), factor, getFormula());
	}
	
	/* Funcions de truncament */
	public String numericaTruncament (String tipus, String factor) throws FuncioNoAplicable
	{
		creaNumericaConcreta(factor);
		
		return decimal.numericaTruncament(tipus, factor);
	}
	
	public String numericaTruncament (String tipus, String factor, int decimal) throws FuncioNoAplicable
	{
		creaNumericaConcreta(factor);
		
		return this.decimal.numericaTruncament(tipus, factor, decimal);
	}
	
	/* Funcions de conversio */
	public String numericaConversio (String tipus, String factor) throws FuncioNoAplicable
	{
		creaNumericaConcreta(factor);
		
		return decimal.numericaConversio(tipus, factor);
	}
	
	public String numericaConversio (String tipus, String factor, char nou) throws FuncioNoAplicable
	{	
		creaNumericaConcreta(factor);
		
		char tipusDada = checkTipus(factor);
		
			//Segons el tipus (E, B, H) de la dada s'executa la funcio en una o altra subclasse
		if (tipusDada == 'E') return entera.numericaConversio(tipus, factor, nou);
		else if (tipusDada == 'B') return binaria.numericaConversio(tipus, factor, nou);
		else if (tipusDada == 'H') return hexadecimal.numericaConversio(tipus, factor, nou);
		else throw new FuncioNoAplicable("La dada a convertir ha de ser entera (E), binaria (B) o hexadecimal (H). Has introduit: " + tipusDada);
	}
	
	/* Funcions unaries */
	public String unaria (String tipus, String factor) throws FuncioNoAplicable
	{
		char tipusDada = checkTipus(factor);
		
		String fixed = new String(aPunt(factor));
		double unariNum = Double.parseDouble(fixed);
		
			//Es calcula el valor absolut del contingut de la dada
		if (tipus.equals("ABS"))
			if (tipusDada == 'N') return (""+Math.abs(unariNum));
			else return (""+(int)Math.abs(unariNum));
		
		return getContingut();
	}
	
	public String unaria (String tipus, String factor, int valor) throws FuncioNoAplicable
	{
		char tipusDada = checkTipus(factor);
		
		String fixed = aPunt(factor);
		double unariNum = Double.parseDouble(fixed);
		
		if (tipus.equals("INC"))
		{
				//S'incrementa el valor del contingut de la cella per tantes unitats com s'ha indicat
			unariNum += valor;
			if (tipusDada == 'N') return (""+unariNum);
			else return (""+(int)unariNum);
		}
		else if (tipus.equals("LOG"))
		{
			// Opcional
		}
		
		return getContingut();
	}
	
	/* Funcions n-aries */
	public String naria (String tipus, String n) throws FuncioNoAplicable
	{
			//Se separen tots els valors introduits a la funcio
		String[] v = n.split(";");
		
		boolean esDecimal = esDecimal(v);
		
			//Es canvia el tipus de la cella segons si hi ha algun decimal o no
		if (esDecimal) setTipus('N');
		else setTipus('E');
		
		ArrayList<String> valors;
		valors = new ArrayList<String>(valorsDelText(n));
			//S'emmagatzemen per separat tots els valors introduits per l'usuari (si i nomes si son decimals o numerics)
		
		if (valors.size() > 1)
		{
				//S'inicialitza el resultat sobre el qual s'iterara al primer valor de la llista introduida
			double resultat = Double.parseDouble(valors.get(0));
			
			if (tipus.equals("SUM"))
			{
				for (int i = 1; i < valors.size(); ++i)
					resultat += Double.parseDouble(valors.get(i));
					//Se sumen tots els valors introduits
			}
			else if (tipus.equals("RES"))
			{
				for (int i = 1; i < valors.size(); ++i)
					resultat -= Double.parseDouble(valors.get(i));
					//Es resten tots els valors introduits, en l'ordre que han estat introduits
			}
			else if (tipus.equals("MUL"))
			{
				for (int i = 1; i < valors.size(); ++i)
					resultat *= Double.parseDouble(valors.get(i));
					//Es multipliquen tots els valors introduits
			}
			else if (tipus.equals("DIV"))
			{
				if (valors.size() == 2 && Double.parseDouble(valors.get(1)) != 0)
					resultat = Double.parseDouble(valors.get(0)) / Double.parseDouble(valors.get(1));
					//Es divideix el primer valor introduit pel segon; sempre que el segon no sigui zero
				else if (Double.parseDouble(valors.get(1)) == 0) throw new FuncioNoAplicable(tipus + ": el divident no pot ser zero.");
					//Si s'intenta dividir un valor entre zero salta l'excepcio FuncioNoAplicable
				else throw new FuncioNoAplicable(tipus + ": cal que una divisio tingui estrictament dos valors: el divisor i el divident.");
					//Si s'intenten dividir mes de 2 valors salta l'excepcio FuncioNoAplicable
			}
			else return n;
				//En cas que no es pugui dur a terme l'operacio, es retorna el conjunt de valors introduits
			
			char tipusDada = getTipus();
			
			if (tipusDada == 'N') return (""+resultat);
			else return (""+(int)resultat);
		}
		else throw new FuncioNoAplicable(tipus + ": cal que una operacio n-aria tingui mes d'un valor.");
			//Si s'intenta operar sobre un o menys valors salta l'excepcio FuncioNoAplicable
	}
	
	/* Funcions d'estadistica */
	public String estadistica(String tipus, String n) throws FuncioNoAplicable {
			//Se separen tots els valors introduits a la funcio
		String[] v = n.split(";");
		
		boolean esDecimal = esDecimal(v);
		
			//Es canvia el tipus de la cella segons si hi ha algun decimal o no
		if (esDecimal) setTipus('N');
		else setTipus('E');
		
		ArrayList<String> valors;
		valors = new ArrayList<String>(valorsDelText(n));
		
		if (valors.size() > 1)
		{
			char tipusDada = getTipus();
			
			if (tipus.equals("MIT"))
			{
				if (tipusDada == 'N') return (""+mitjana(valors));
				else return (""+(int)mitjana(valors));
			}
			else if (tipus.equals("MED"))
			{
					//S'ordenen els valors ascendentment (nomes entren a valors els N o E)
				valors.sort(null);
				
				int llista = valors.size();
				
				if(llista%2==1)
				{
					if (tipusDada == 'N') return (""+Double.parseDouble(valors.get((llista+1)/2-1)));
					else return (""+Integer.parseInt(valors.get((llista+1)/2-1)));
				}
				else
				{
					if (tipusDada == 'N') return (""+(Double.parseDouble(valors.get(llista/2-1))+Double.parseDouble(valors.get(llista/2)))/2);
					else return (""+(Integer.parseInt(valors.get(llista/2-1))+Integer.parseInt(valors.get(llista/2)))/2);
				}
				
			}
			else if (tipus.equals("VAR"))
			{
				if (tipusDada == 'N') return (""+variancia(valors));
				else return (""+(int)variancia(valors));
			}
			else if (tipus.equals("STDEV"))
			{
				if (tipusDada == 'N') return (""+Math.sqrt(variancia(valors)));
				else return (""+(int)Math.sqrt(variancia(valors)));
			}
		}
		else throw new FuncioNoAplicable(tipus + ": cal que l'operacio estadistica tingui mes d'un valor.");
		
		return getContingut();
	}
	
	public String estadistica(String tipus, String n, String m) throws FuncioNoAplicable {
			//Se separen tots els valors introduits a la funcio
		String[] v = n.split(";");
		String[] w = m.split(";");
		
		boolean esDecimal = (esDecimal(v) && esDecimal(w));
		
			//Es canvia el tipus de la cella segons si hi ha algun decimal o no
		if (esDecimal) setTipus('N');
		else setTipus('E');
			
		ArrayList<String> primerConjunt;
		ArrayList<String> segonConjunt;
		primerConjunt = new ArrayList<String>(valorsDelText(n));
		segonConjunt = new ArrayList<String>(valorsDelText(m));
		
		if (primerConjunt.size() > 1 && primerConjunt.size() == segonConjunt.size())
		{
			char tipusDada = getTipus();
			
			if (tipus.equals("COVAR"))
			{
				if (tipusDada == 'N') return (""+covariancia(primerConjunt, segonConjunt));
				else return (""+(int)covariancia(primerConjunt, segonConjunt));
			}
			else if (tipus.equals("PEARSON"))
			{
				if (tipusDada == 'N') return (""+covariancia(primerConjunt, segonConjunt)/(Math.sqrt(variancia(primerConjunt))*Math.sqrt(variancia(segonConjunt))));
				else return (""+(int)covariancia(primerConjunt, segonConjunt)/(int)(Math.sqrt(variancia(primerConjunt))*Math.sqrt(variancia(segonConjunt))));
			}
		}
		else throw new FuncioNoAplicable(tipus + ": cal que l'operacio estadistica tingui mes d'un valor a cada conjunt, i que ambdos conjunts siguin de la mateixa mida.");
		
		return getContingut();
	}
	
	/* Calcul de la mitjana de tots els valors (estrictament decimals o enters) introduits */
	private double mitjana (ArrayList<String> valors)
	{
		double mitjana = 0;
		for (int i = 0; i < valors.size(); ++i)
			mitjana += Double.parseDouble(valors.get(i));
		mitjana /= valors.size();
		
		return mitjana;
	}
	
	/* Calcul de la variancia de tots els valors (estrictament decimals o enters) introduits */
	private double variancia (ArrayList<String> valors)
	{
		double mitjana = mitjana(valors);
		
		double variancia = 0;
		for (int i = 0; i < valors.size(); i++) {
			variancia += Math.pow(Double.parseDouble(valors.get(i)) - mitjana, 2);
		}
		variancia /= (valors.size() - 1);
		
		return variancia;
	}
	
	/* Calcul de la covariancia de tots els valors (estrictament decimals o enters) introduits */
	private double covariancia (ArrayList<String> primerConjunt, ArrayList<String> segonConjunt)
	{
		double primeraMitjana = mitjana(primerConjunt);
		double segonaMitjana = mitjana(segonConjunt);
		double covariancia = 0;
		for (int i = 0; i < primerConjunt.size(); ++i)
			covariancia += ((Double.parseDouble(primerConjunt.get(i)) - primeraMitjana)*(Double.parseDouble(segonConjunt.get(i)) - segonaMitjana));
		covariancia /= (primerConjunt.size() - 1);
		
		return covariancia;
	}
	
	/* Atributs de Numerica */
	private Entera entera;
	private Decimal decimal;
	private Binaria binaria;
	private Hexadecimal hexadecimal;
}