package Dominio;
import java.util.*;

public class Cella {
	
	/* Creadora d'una cella buida */
	public Cella (int coordenadaX, int coordenadaY, Full full) {
		x = coordenadaX;
		y = coordenadaY;
		color = 0;
		mida = 10.0;
		format = new ArrayList<>(4);
		
		for (int i = 0; i < 4; ++i) format.add(false);
		
		foli = full;
		dada = new Dada(this);
	}
	
	/* Creadora d'una cella copiada */
	public Cella (Cella c) {
		x = c.x;
		y = c.y;
		color = c.color;
		mida = c.mida;
		format = new ArrayList<>(c.format);
		foli = c.foli;
	    dada = new Dada(this);
		dada.setCella(this);
		dada.setContingut(new String(c.getDada().getContingut()));
		dada.setFormula(new String(c.getDada().getFormula()));
		char tipus = c.getDada().getTipus();
		dada.setTipus(tipus);
	}

	/* Esborrar el contingut d'una cella */
	public void esborrarContingut () {
		Cella nova = new Cella(this.x, this.y, this.foli);
		color = nova.color;
		mida = nova.mida;
		format = nova.format;
		dada = nova.dada;
	}
	
	/* Setters */
	public void setCols (int i) {
		x = i;
	}
	
	public void setRows (int j) {
		y = j;
	}
	
	public void setDada (String contingut, String formula) {
		dada = new Dada(this, contingut, formula);
	}
	
	public void setColor (int nou) {
		//this.getFull().getCanvis().push(this);
		color = nou;
	}
	
	/* Ja actua com a metode per canviar la mida del contingut */
	public void setMida (double nou) {
		//this.getFull().getCanvis().push(this);
		mida = nou;
	}
	
	public void setFormatBold (boolean nou) {
		//this.getFull().getCanvis().push(this);
		format.set(0, nou);
	}
	
	public void setFormatItalics (boolean nou) {
		//this.getFull().getCanvis().push(this);
		format.set(1, nou);
	}
	
	public void setFormatUnderline (boolean nou) {
	//	this.getFull().getCanvis().push(this);
		format.set(2, nou);
	}
	
	public void setFormatConditional (boolean nou) {
	
	//	this.getFull().getCanvis().push(this);
		format.set(3, nou);
	}
	
	public void setFull (Full nou) {
		foli = nou;
	}
	
	/* Getters */
	public int getCols () {
		return x;
	}
	
	public int getRows () {
		return y;
	}
	
	public Dada getDada () {
		return dada;
	}
	
	public int getColor () {
		return color;
	}
	
	public double getMida () {
		return mida;
	}
	
	public Boolean getFormatBold () {
		return format.get(0);
	}
	
	public Boolean getFormatItalics () {
		return format.get(1);
	}
	
	public Boolean getFormatUnderline () {
		return format.get(2);
	}
	
	public Boolean getFormatConditional () {
		return format.get(3);
	}
	
	public Full getFull () {
		return foli;
	}
	
	/* Alterna entre el format bold (negreta) i sense */
	public void formatBold ()
	{
		boolean b = !this.format.get(0);
		
		setFormatBold(b);
	}
	
	/* Alterna entre el format italics (cursiva) i sense */
	public void formatItalics ()
	{
		boolean i = !this.format.get(1);
		
		setFormatItalics(i);
	}
	
	/* Alterna entre el format underline (subratllat) i sense */
	public void formatUnderline ()
	{
		boolean u = !this.format.get(2);
		
		setFormatUnderline(u);
	}
	
	/* Adjudica un format concret en funcio de la condicio indicada */
	public void formatConditional (String condicio)
	{
		// Opcional
	}
	
	/* Atributs de cella */
	private int x, y;
	private Dada dada;
	private int color;
	private double mida;
	private ArrayList<Boolean> format;
		// format[0] = BOLD, format[1] = ITALICS, format[2] = UNDERLINE, format[3] = CONDITIONAL
	private Full foli;
}