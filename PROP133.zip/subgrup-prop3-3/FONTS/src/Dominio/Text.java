package Dominio;

import java.util.ArrayList;

public class Text extends Dada {
	public Text (Cella casella, String contingut, String formula) {
		super(casella, contingut, formula);
	}
	
	/* Funcions de substitucio */
	public String textSubstituir(String tipus, String factor, char canvi) throws FuncioNoAplicable {
		if (tipus.equals("MINMAJ"))
		{								
			String minMAJ = new String(factor);
			
				//Si s'introdueix 'M' com a canvi el text passa a ser tot en majscules
			if (canvi == 'M') minMAJ = minMAJ.toUpperCase();
			else if (canvi == 'm') minMAJ = minMAJ.toLowerCase();
				//Si s'introdueix 'm' com a canvi el text passa a ser tot en minscules
			else throw new FuncioNoAplicable(tipus + ": la funcio admet els indicadors m (transormar a minuscules) i M (transformar a majuscules). Has introduit: " + canvi + '.');
			
			return minMAJ;
		}
		
		return getContingut();
	}
	
	public String textSubstituir(String tipus, String factor, String vell, String nou) {
		if (tipus.equals("REECAR"))
		{				
				//Es reemplacen els fragments que coincideixin amb vell pel fragment nou
			String substitut = factor.replace(vell, nou);
			return substitut;
		}
		
		return getContingut();
	}
	
	/* Funcions de longitud */
	public String textLongitud(String tipus, String factor) {
		if (tipus.equals("NUMCAR"))
				//Es retorna la longitud en caracters del text
			return (""+factor.length());
		
		return getContingut();
	}
	
	public String textLongitud(String tipus, String factor, String recompte) {
		if (tipus.equals("NUMCON"))
		{
			int n = 0;
			int chunk = recompte.length();
			
				//Es compten les coincidencies amb el fragment recompte que hi ha al text
			for (int i = 0; (i + chunk - 1) < factor.length(); ++i)
			{				
					//Comportament: per al text [ABCDEFG] i el recompte [EF] els substrings generats seran [AB], [BC], [CD], [DE], [EF] i [FG]
				String segment = factor.substring(i, i+chunk);
				
				if (segment.equals(recompte)) ++n;
					//Si es troba una coincidencia, s'augmenta el comptador
			}
			
			return (""+n);
		}
		
		return getContingut();
	}
}