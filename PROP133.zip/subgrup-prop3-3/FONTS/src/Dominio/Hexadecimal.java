package Dominio;

public class Hexadecimal extends Numerica {
	public Hexadecimal (Cella casella, String contingut, String formula) {
		super(casella, contingut, formula);
	}
	
	public String numericaConversio (String tipus, String factor, char nou) throws FuncioNoAplicable {	
		if (tipus.equals("CONVBASE"))
		{
			int numConvertit;
			
				//Treu el "0x" del principi
			String valor = factor.substring(2, getContingut().length());
			
				//Es converteix el valor hexadecimal a enter (si s'indica E) o binari (B)
			if (nou == 'E')
			{
				numConvertit = Integer.parseInt(valor, 16);
				return (""+numConvertit);
			}
			else if (nou == 'B')
			{
				numConvertit = Integer.parseInt(valor, 16);
				return "0b"+Integer.toBinaryString(numConvertit);
			}
			else throw new FuncioNoAplicable(tipus + ": no es pot convertir la dada al tipus " + nou + ".");
				//En cas que s'hagi introduit un tipus incorrecte al qual convertir el valor enter, salta l'excepcio FuncioNoAplicable
		}
		
		return getContingut();
	}
}
