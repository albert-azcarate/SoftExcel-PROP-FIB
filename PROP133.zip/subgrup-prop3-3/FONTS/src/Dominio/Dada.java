package Dominio;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Dada {
	/* Cella en blanc */
	public Dada (Cella casella) {
		cella = casella;
		contingut = new String("");
		tipus = checkTipus(contingut);
		formula = new String ("");
	}
	
	/* Cella amb contingut */
	public Dada (Cella casella, String contingut, String formula) {
		cella = casella;
		this.contingut = new String(contingut);
		this.tipus = checkTipus(contingut);
		this.formula = new String(formula);
	}
	
	/* Setters */
	public void setCella (Cella casella) {
		cella = casella;
	}
	
	public void setContingut (String nou) {
			//Quan es canvia el contingut de la dada es revisa el seu tipus i es crea la subclasse necessaria.
		//cella.getFull().getCanvis().push(cella);
		setTipus(checkTipus(nou));
		creaDadaConcreta(nou);
		contingut = new String(nou);
	}
	
	public void setTipus (char nou) {
		tipus = nou;
	}
	
	public void setFormula (String nou) {
		//cella.getFull().getCanvis().push(cella);
		formula = new String(nou);
	}
	
	/* Getters */
	public Cella getCella () {
		return cella;
	}
	
	public String getContingut () {
		return contingut;
	}
	
	public char getTipus () {
		
		return tipus;
	}
	
	public String getFormula () {
		return formula;
	}
	
	/* Determinacio del tipus de la dada */
	public char checkTipus(String contingut)
	{
		String formatEnter = "-{0,1}\\d{1,}";
		String formatDecimal = "-{0,1}\\d{1,}(\\.\\d{1,}|,\\d{1,})";
		String formatBinari = "0b(0|1){1,}";
		String formatHexadecimal = "0x[A-F0-9]{1,}";
		String formatData = "\\d{1,2}/\\d{1,2}/\\d{2,4}";
		
		if (contingut.matches(formatEnter))
			return 'E';
		else if (contingut.matches(formatDecimal))
			return 'N';
		else if (contingut.matches(formatBinari))
			return 'B';
		else if (contingut.matches(formatHexadecimal))
			return 'H';
		else if (contingut.matches(formatData))
		{
			Date data = null;
			try {
				data = DateFormat.getDateInstance(DateFormat.SHORT).parse(contingut);
			} catch (ParseException e) { }
			
			Calendar calendari = Calendar.getInstance();
			calendari.setTime(data);
			
			String[] elements = contingut.split("/");
			
			int dia = Integer.parseInt(elements[0]);
			int mes = Integer.parseInt(elements[1]);
			int any = Integer.parseInt(elements[2]);
			
			boolean traspas = false;
			
		    if (any % 4 == 0)
		    	if (any % 100 == 0) { if (any % 400 == 0) traspas = true; }
		    	else traspas = true;
		    
		    int minDia = calendari.getMinimum(Calendar.DAY_OF_MONTH);
			int maxDia;
			if (mes == 2)
			{
				if (traspas) maxDia = 29;
				else maxDia = 28;
			}
			else if (mes == 4 || mes == 6 || mes == 9 || mes == 11)
				maxDia = 30;
			else maxDia = calendari.getMaximum(Calendar.DAY_OF_MONTH);
			int minMes = (calendari.getMinimum(Calendar.MONTH) + 1);
			int maxMes = (calendari.getMaximum(Calendar.MONTH) + 1);
			int minAny = calendari.getMinimum(Calendar.YEAR);
			
			if (dia >= minDia && dia <= maxDia && mes >= minMes && mes <= maxMes && any >= minAny)
				return 'D';
		}

		return 'T';
	}
	
	public ArrayList<String> valorsDelText (String text) throws FuncioNoAplicable
	{
		ArrayList<String> valors;
		valors = new ArrayList<String>();
		
		String[] v = text.split(";");
		
		for (int i = 0; i < v.length; ++i)
		{
			if (v[i].length() > 0)
			{
				String valor = new String(v[i]).trim();
				
				char t = checkTipus(valor);	
				if (t == 'N' || t == 'E')
				{
					if (t == 'N' && valor.matches("-{0,1}\\d{1,},\\d{1,}"))
					{
						String[] coma = valor.split(",");
						valor = coma[0] + '.' + coma[1];
					}
					valors.add(valor);
				}
				else throw new FuncioNoAplicable("La dada " + v[i] + " no es un numero.");
			}
		}
		
		return valors;
	}
	
	
	/* Creadora d'una nova subclasse que coincideixi amb el tipus (canviant) de Dada o el factor d'una funcio */
	private void creaDadaConcreta (String factor)
	{
		char tipusDada = checkTipus(factor);
		
		if (tipusDada == 'D') data = new Data(cella, contingut, formula);
		else if (tipusDada == 'T') text = new Text(cella, contingut, formula);
		else if (tipusDada == 'E' || tipusDada == 'N' || tipusDada == 'B' || tipusDada == 'H') numerica = new Numerica(cella, contingut, formula);
	}

	/* Funcions de truncament */
	public String numericaTruncament (String tipus, String factor) throws FuncioNoAplicable
	{		
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ')');
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N')
		{
			creaDadaConcreta(factor);
			setContingut(numerica.numericaTruncament(tipus, factor));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot truncar una dada a enter que no sigui decimal. Has introduit " + tipusFactor + ".");
		}
		
		return contingut;
	}
	
	public String numericaTruncament (String tipus, String factor, int decimal) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ';' + decimal + ')');
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N')
		{
			creaDadaConcreta(factor);
			setContingut(numerica.numericaTruncament(tipus, factor, decimal));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot truncar una dada que no sigui decimal. Has introduit " + tipusFactor + "."); 
		}
			
		return contingut;
	}
	
	/* Funcions de conversio */
	public String numericaConversio (String tipus, String factor) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ')');
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N')
		{
			creaDadaConcreta(factor);
			setContingut(numerica.numericaConversio(tipus, factor));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot convertir una dada que no sigui decimal. Has introduit " + tipusFactor + "."); 
		}
			
		return contingut;
	}
	
	public String numericaConversio (String tipus, String factor, char nou) throws FuncioNoAplicable
	{	
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ';' + nou + ')');
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'E' || this.tipus == 'B' || this.tipus == 'H')
		{
			creaDadaConcreta(factor);
			setContingut(numerica.numericaConversio(tipus, factor, nou));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot convertir una dada que no sigui entera, binaria o hexadecimal. Has introduit " + tipusFactor + "."); 
		}
			
		return contingut;
	}
	
	/* Funcions unaries */
	public String unaria (String tipus, String factor) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ')');
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N' || this.tipus == 'E')
		{
			creaDadaConcreta(factor);
			setContingut(numerica.unaria(tipus, factor));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot calcular el valor absolut d'una dada que no sigui decimal o entera. Has introduit " + tipusFactor + ".");
		}
		
		return contingut;
	}
	
	public String unaria (String tipus, String factor, int valor) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ';' + valor + ')');
		
			//Segons el tipus de la dada s'executa la funcio en una o altra subclasse; si el tipus no coincideix amb cap opcio admesa salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'N'|| this.tipus == 'E')
		{
			creaDadaConcreta(factor);
			setContingut(numerica.unaria(tipus, factor, valor));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot aplicar una operacio unaria a una dada que no sigui decimal o entera. Has introduit " + tipusFactor + ".");
		}
		
		return contingut;
	}
	
	/* Funcions n-aries */
	public String naria (String tipus, String n) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + n + ')');
		
		creaDadaConcreta("1.0");
		
		setContingut(numerica.naria(tipus, n));
			//No s'activa l'excepcio FuncioNoAplicable perque si s'introdueix cap altre tipus de dada sera ignorat per l'operacio
		
		return contingut;
	}
	
	/* Funcions de data */
	public String data (String tipus, String factor) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ')');
		
			//Si el tipus de la dada no coincideix amb Data (D) salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'D')
		{
			creaDadaConcreta(factor);
			setContingut(data.data(tipus, factor));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot aplicar una operacio de data a una dada que no sigui una data. Has introduit " + tipusFactor + ".");
		}
		
		return contingut;
	}
	
	public String data (String tipus, String factor, char instant) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ';' + instant + ')');
			
			//Si el tipus de la dada no coincideix amb Data (D) salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'D')
		{
			creaDadaConcreta(factor);
			setContingut(data.data(tipus, factor, instant));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot aplicar una operacio de data a una dada que no sigui una data. Has introduit " + tipusFactor + ".");
		}
		
		return contingut;
	}
	
	/* Funcions de substitucio */
	public String textSubstituir(String tipus, String factor, char canvi) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ';' + canvi + ')');
		
			//Si el tipus de la dada no coincideix amb Text (T) salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'T')
		{
			creaDadaConcreta(factor);
			setContingut(text.textSubstituir(tipus, factor, canvi));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot modificar text d'una dada que no sigui un text. Has introduit " + tipusFactor + ".");
		}
		
		return contingut;
	}
	
	public String textSubstituir(String tipus, String factor, String vell, String nou) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ';' + vell + ';' + nou + ')');
		
			//Si el tipus de la dada no coincideix amb Text (T) salta l'excepcio FuncioNoAplicable
		if (this.tipus == 'T')
		{
			creaDadaConcreta(factor);
			setContingut(text.textSubstituir(tipus, factor, vell, nou));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es pot substituir text d'una dada que no sigui un text. Has introduit " + tipusFactor + ".");
		}
		
		return contingut;
	}
	
	/* Funcions de longitud */
	public String textLongitud(String tipus, String factor) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ')');
		
		if (this.tipus == 'T')
		{
			creaDadaConcreta(factor);
			setContingut(text.textLongitud(tipus, factor));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es poden comptar els caracters d'una dada que no sigui un text. Has introuit "+ tipusFactor + ".");
		}
		
		return contingut;
	}
	
	public String textLongitud(String tipus, String factor, String recompte) throws FuncioNoAplicable
	{
			//Si no s'escriu res a factor (allo sobre el qual s'opera) s'assumeix que es vol operar sobre el mateix contingut de la Dada
		if (factor.equals("")) factor = contingut;
		else setTipus(checkTipus(factor));
		
		setFormula('=' + tipus + '(' + factor + ';' + recompte + ')');
		
		if (this.tipus == 'T')
		{
			creaDadaConcreta(factor);
			setContingut(text.textLongitud(tipus, factor, recompte));
		}
		else
		{
			char tipusFactor = getTipus();
			if (!factor.equals(contingut)) setTipus(checkTipus(contingut));
				//Si el tipus del factor no s l'adequat per a la funcio i no es el contingut (si ho fos, el tipus ja seria el que s'hauria de desar a la Dada), es recupera el tipus del contingut
			throw new FuncioNoAplicable(tipus + ": no es poden comptar les coincidencies d'una dada que no sigui un text. Has introuit "+ tipusFactor + ".");
		}
		
		return contingut;
	}
	
	/* Funcions d'estadistica */
	public String estadistica(String tipus, String n) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + n + ')');
		
		creaDadaConcreta("1.0");
		
		setContingut(numerica.estadistica(tipus, n));
			//No s'activa l'excepcio FuncioNoAplicable perque si s'introdueix cap altre tipus de dada sera ignorat per l'operacio
		
		return contingut;
	}
	
	public String estadistica(String tipus, String n, String m) throws FuncioNoAplicable
	{
		setFormula('=' + tipus + '(' + n + '|' + m + ')');

		creaDadaConcreta("1.0");
		
		setContingut(numerica.estadistica(tipus, n, m));
			//No s'activa l'excepcio FuncioNoAplicable perque si s'introdueix cap altre tipus de dada sera ignorat per l'operacio
		
		return contingut;
	}
	
	/* Atributs de Dada */
	private Cella cella;
		//Cella a la qual s'associa la dada
	private Numerica numerica;
	private Data data;
	private Text text;
		//Instancies de les possibles subclasses de la dada
	private String contingut;
		//Conjunt de caracters d'una cella sobre el qual s'opera
	private char tipus;
		//Text (T), Enter (E), Decimal (N), Binari (B), Hexadecimal (H), Data (D)
	private String formula;
}