package Dominio;

public class IndexNoValid extends Exception {
	public IndexNoValid (String missatge)
	{
		super(missatge);
	}
}
