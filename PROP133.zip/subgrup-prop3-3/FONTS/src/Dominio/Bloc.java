package Dominio;
import java.util.ArrayList;
import java.util.Arrays;
import java.math.*;

public class Bloc implements Cloneable {

	/*Creadores i Clonadora*/
	
	//per poder fer una deep copy del bloc tenim auesta funcio
	@Override
    public Bloc clone() {
		Bloc clonedBloc = null;
        try {
        	//clonacio dels atributs basics
        	clonedBloc = (Bloc) super.clone();
        	//creacio de la nova 2d ArrayList
        	clonedBloc.mt = new ArrayList<>(nRows);
        	for(int i=0; i < nRows; i++) {
        		clonedBloc.mt.add(new ArrayList<>());
    		}
        	//deep copy de les celles
        	traspassar(this, clonedBloc);
        	
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return clonedBloc;
	}
	
	/* Creadora d'un bloc */
	public Bloc(int x, int y, int nr, int nc, Full f) throws FuncioNoAplicable {
		//si x o y son negatius o mes grans que la coordenada maxima del full, error
		if(x < 0 || y < 0 || x > f.getNumRows() || y > f.getNumColumns()) {
			//System.out.print(" " + x + " " + y + " " + nr + " " + nc);
			throw new FuncioNoAplicable("Error: Coordenades inicials no valides \n");
		}
		
		//si el num de columnes o el num de files son negatives, invertim 
		if(nc < 0 || nr < 0) {
			nc = Math.abs(nc);
			nr = Math.abs(nr);
			x = x-nc-1;
			y = y-nr-1;
			nc ++;
			nr ++;
			//return;
		}
		//si la suma de la x inicial + el numero de columnes del bloc o y + el numero de files del bloc surten del full, error
		if(x + nr > f.getNumRows() || y + nc > f.getNumColumns()) {
			throw new FuncioNoAplicable("Error: El rang del bloc surt fora del Full " + x + " " + f.getNumColumns() + " " + y + " "+ f.getNumRows() + " " + "\n");
		}
		
		initXcoord = x;
		initYcoord = y;
		nRows = nr;
		nCols = nc;
		
		
		//creem la arraylist amb les celles del full selecionades
		mt = new ArrayList<>(nRows);
		for(int i=0; i < nRows; i++) {
		    mt.add(new ArrayList<>());
		}
		for(int i = 0; i < nRows; i++) {
			for(int j = 0; j < nCols; j++) {	
				mt.get(i).add(new Cella(f.getCelles().get(i+initXcoord).get(j+initYcoord)));
			}
		}
		
		return;
	}
	

	/* Getters */
	
	public int getinitX() {
		return this.initXcoord;
	}
	public int getinitY() {
		return this.initYcoord;
	}
	public int getRows() {
		return this.nRows;
	}
	public int getCols() {
		return this.nCols;
	}
	
	public ArrayList<ArrayList<Cella>> getmt() {
		return this.mt;
	}
	
	/* Setter */
	
	public void setColors(String color, Full f) throws FuncioNoAplicable {
		int c = 0;
		try {
			c = Integer.parseInt(color);
			if (c < 0 || c > 4) throw new FuncioNoAplicable("L'indicador de color nomes pot trobar-se entre el 0 i el 4.");
		} catch (NumberFormatException nfe) {
			throw new FuncioNoAplicable("El color ha de ser un valor enter.");
		}
		for(int i = 0; i < nRows; i++)
			for(int j = 0; j < nCols; j++)
				mt.get(i).get(j).setColor(c);
		to_full(f);
	}
	
	/* Guardem una deep copy del bloc al bloc privat del document per enganxar mes endavant */
	public void copiar(Document docu) {
		//clonem el bloc
		Bloc copia = (Bloc)this.clone();
		//guardem la copia al document
		docu.SetCopia(copia);
	}
	
	
	/* Deep copy de les dades d'un bloc old a un bloc nou de igual mida */
	private void traspassar(Bloc old, Bloc nou) {
		//creacio d'un array termporal per a les celles amb tamany del bloc a copiar(old == this)
		Cella [][] tempcell = new Cella[nRows][nCols];
    	
		for(int i = 0; i < nRows; i++) {
			for(int j = 0; j < nCols; j++) {
				//per a cada cella creem una deep copy
				tempcell [i][j] = new Cella(old.mt.get(i).get(j));
			}
		}
    	
		for(int i = 0; i < nRows; i++) {
			for(int j = 0; j < nCols; j++) {	
				//per a cada posicio del 2d ArrayList nou afegim la cella del array 
				nou.mt.get(i).add(tempcell [i][j]);
			}
		}
	}
	
	/* Passem les dades d'un bloc a un full */
	private void traspassar_a_foli(Bloc old, Full f) {
		//creacio d'un array termporal per a les celles amb tamany del bloc a copiar(old == this)
		ArrayList<ArrayList<Cella>> nou = f.getCelles();
		Cella [][] tempcell = new Cella[nRows][nCols];
    	
		for(int i = 0; i < nRows; i++) {
			for(int j = 0; j < nCols; j++) {	
				//per a cada cella creem una deep copy
				tempcell [i][j] = new Cella(old.mt.get(i).get(j));
			}
		}
    	
		for(int i = 0; i < nRows; i++) {
			for(int j = 0; j < nCols; j++) {	
				//per a cada posicio del 2d ArrayList nou afegim la cella del array 
				nou.get(i+initXcoord).set(j+initYcoord, new Cella(tempcell [i][j]));
			}
		}
	}
	
	/* Enganxa el bloc copiat al document al full amb coordenades inicials x,y */
	public void enganxar(Document docu, Full f, int x, int y) {
		this.initXcoord = x;
		this.initYcoord = y;
		traspassar_a_foli(this,f);
	}

	/* Ordenacio d'un bloc 
	 * 
	 * 
	 * CAMBIAR A QUE SIGUI UN ARRAY DE DADES PERO COMPARO CONTINGUTS
	 * 
	 * */
	public void ordenar(String criteri) throws FuncioNoAplicable {
		//afegim tot els continguts del bloc a un array
		criteri = criteri.toUpperCase();
		Cella[] arrayc;
		ArrayList<ArrayList<Cella>> mttemp = new ArrayList<>(nRows);
		
		if(criteri.equals("DESCENDENT") || criteri.equals("ASCENDENT")) {
			arrayc = new Cella[nRows*nCols];
			for(int i = 0; i < nRows; i++) {
				for(int j = 0; j < nCols; j++) {
					arrayc[j+i*nCols] = new Cella(mt.get(i).get(j));
				}
			}
		}
		//inicialitzem un Array amb tot el contingut de la 1a columna i inicializem una matriu temporal
		else if(criteri.contains("COLUMNA")) {
			arrayc = new Cella[nRows];
			for(int i = 0; i < nRows; i++) {
				arrayc[i] = new Cella(mt.get(i).get(0));
				mttemp.add(new ArrayList<Cella>());
				for(int j = 0; j < nCols; j++) {
					mttemp.get(i).add(new Cella(mt.get(i).get(j)));
				}
			}
		}
		else throw new FuncioNoAplicable("Parametre d'ordenacio incorrecte");
		
		//ordenem l'array ascendentment
		for(int i = 0; i<arrayc.length; i++) {
	         for (int j = i+1; j<arrayc.length; j++) {
            	String arr = arrayc[i].getDada().getContingut();
            	String arr2 = arrayc[j].getDada().getContingut();
            	try {
            		if(Integer.parseInt(arr) > Integer.parseInt(arr2)) {
            			Cella temp = new Cella(arrayc[j]);
	            		arrayc[j] = arrayc[i];
	            		arrayc[i] = temp;
            		}
            	} catch(NumberFormatException e) {
            		if(arr.compareTo(arr2)>0) {
	            		Cella temp = new Cella(arrayc[j]);
	            		arrayc[j] = arrayc[i];
	            		arrayc[i] = temp;
	            	}
            	}
	         }
		}
		//si es descendent, invertim larray
		if(criteri.contains("DESCENDENT")) {
			for (int i = 0; i < arrayc.length / 2; i++) {
		        Cella temp = new Cella(arrayc[i]);
		        arrayc[i] = arrayc[arrayc.length - 1 - i];
		        arrayc[arrayc.length - 1 - i] = temp;
		    }
        }
		
		//si es ascendent o descendent passem cella a cella a la matriu
		if(criteri.equals("DESCENDENT") || criteri.equals("ASCENDENT")) {
			//passem les dades del array al bloc
			for(int i = 0; i < nRows; i++) {
				for(int j = 0; j < nCols; j++) {
					mt.get(i).set(j, new Cella(arrayc[j+i*nCols]));
					mt.get(i).get(j).setCols(i + initXcoord);
					mt.get(i).get(j).setRows(j + initYcoord);
					
				}
			}
		}
		//si volem ordenar un bloc respecte a la primera columna:
		else if(criteri.contains("COLUMNA")){
			
			//per a cada posicio del array ordenat, buscarem dins la 1a columna del bloc la 1a cella que coincideixi
			for(int k = 0; k < arrayc.length; k++) {
				for(int i = 0; i < nRows; i++) {
					if(!mt.get(i).get(0).getDada().getFormula().equals("Feta servir") && mt.get(i).get(0).getDada().getContingut().equals(arrayc[k].getDada().getContingut())) {
						//si es igual, copiem tota la fila a la matriu temporal
						for(int j = 0; j < nCols; j++) {
							mttemp.get(k).set(j,mt.get(i).get(j));
						}
						//buidem aquella fila per a no agafarla de nou i sortim del bucle per a la nova posicio del array
						mt.get(i).get(0).getDada().setFormula("Feta servir");
						i = nRows;
					}
				}
			}
			
			//passem les dades del array al bloc
			for(int i = 0; i < nRows; i++) {
				mt.add(new ArrayList<Cella>());
				for(int j = 0; j < nCols; j++) {
					mt.get(i).add(j, new Cella(mttemp.get(i).get(j)));
					mt.get(i).get(j).setCols(i + initXcoord);
					mt.get(i).get(j).setRows(j + initYcoord);
					mt.get(i).get(j).getDada().setFormula("");
				}
			}
		}
	}
	
	/* Passem les dades del bloc al foli */
	public void to_full(Full f) {
		traspassar_a_foli(this,f);
	}
	
	/* Tots els continguts de les celles del bloc canvien per el nou contingut */
	public void modificarContinguts(String contingut) {
		for(int i = 0; i < nRows; i++) {
			for(int j = 0; j < nCols; j++) {
				mt.get(i).get(j).getDada().setContingut(contingut);
			}
		}
	}
	
	/* Totes les celles que el seu contingut sigui igual a old, es canvia per reemp */
	public void reemplassar(String old, String reemp) throws FuncioNoAplicable { 
		for(int i = 0; i < nRows; i++) {
			for(int j = 0; j < nCols; j++) {
				if(mt.get(i).get(j).getDada().getContingut().contains(old)) {
					String contingut = mt.get(i).get(j).getDada().getContingut();
					contingut = contingut.replace(old, reemp);
					mt.get(i).get(j).getDada().setContingut(contingut);
				}
			}
		}
	}
	
	/* Tot el bloc queda amb contingut buit */
	public void esborrar() {
		modificarContinguts("");
	}
	
	/* Cerca dins del bloc */
	public int cercaContinguts(String buscar) {
		int quantitat = 0;
		for(int i = 0; i < nRows; i++) {
			for(int j = 0; j < nCols; j++) {
				//si el contingut conte, sumem un a quantitat
				if(mt.get(i).get(j).getDada().getContingut().contains(buscar)) {
					quantitat++;
				}
			}
		}
		return quantitat;
	}
	

	/* Aplica una funcio de Cella a tot un Bloc. PREREQUISIT: la formula no es composta i nomes s'ha seleccionat una fila o una columna */
	public void aplicarFuncio(Cella c, Full f) throws FuncioNoAplicable {
		String formula = new String(c.getDada().getFormula());
		String indicador = "";
		
		if(formula.charAt(0) == '=') {
			formula = formula.substring(1);
			if(!formula.matches("[a-zA-Z]{1,4}\\d{1,4}")) {
				indicador = formula.substring(0, formula.indexOf("("));
				formula = formula.substring(formula.indexOf("(") + 1, formula.length() - 1);
				
			}
		}
		
		
		for (int i = 0; i < nRows; ++i)
			for (int j = 0; j < nCols; ++j)
			{
				int x = c.getCols() + j;
				int y = c.getRows() + i;
				
				String[] parametres = formula.split("\\|");
				String[] par = parametres[0].split(";");
				
				String canvis = new String("");
				
				for (String p : par)
				{
						//Si hi ha una referencia:
					if (p.matches("[a-zA-Z]{1,4}\\d{1,4}"))
					{
							//Dividir els seus caracters (individualment)
						String[] prm = p.split("|");
						
						String lletres = new String("");
						String numeros = new String("");
							//Destriar numeros de lletres dins les referencies
						for (int l = 0; l < prm.length; ++l)
						{
							if (prm[l].matches("[a-zA-Z]")) lletres += prm[l];
							if (prm[l].matches("\\d")) numeros += prm[l];
						}
						
							//Un cop dividits, canviar el valor i o j de la referencia
						if (nCols == 1)
						{
							int pra = Integer.parseInt(numeros);
							pra += i;
							numeros = new String("" + pra);
						}
						if (nRows == 1)
						{
								//Es converteix la lletra a lletres a un numero
							int s = 0;
							if (lletres != null && lletres.length() > 0) {
								s = (lletres.charAt(0) - 'A');
								for (int k = 0; k < lletres.length(); k++) {
								s *= 26;
								s += (lletres.charAt(k) - 'A');
								}
							}
								//Se suma el desplaÃ§ament de la referencia al numero
							s += j + 1;
								//Es torna a passar el numero a lletra
							String z = new String("");
							while (s > 0) {
								s--;
								int remainder = s % 26;
								char digit = (char) (remainder + 97);
								z = digit + z;
								s = (s - remainder) / 26;
							}
								//La lletra ha de ser majuscula
							lletres = z.toUpperCase();
						}
							//Es reconstrueix la nova referencia
						p = lletres + numeros;
					}
						//Es reuniexen els parametres (sigui una referencia actualitzada o no)
					canvis += p + ";";
				}
					//S'elimina l'ultim ; (que sobra)
				canvis = canvis.substring(0, canvis.length() - 1);
				
					//En cas que hi hagues un | i l'operacio demanada sigui COVAR o PEARSON es repeteix el proces
				if (!formula.matches("[a-zA-Z]{1,4}\\d{1,4}") && parametres.length == 2 && (indicador.equals("=COVAR") || indicador.equals("=PEARSON")))
				{
					String[] parms = parametres[1].split(";");
					String cambis = new String("");
					
					for (String pm : parms)
					{
							//Si hi ha una referencia:
						if (pm.matches("[a-zA-Z]{1,4}\\d{1,4}"))
						{
								//Dividir els seus caracters (individualment)
							String[] pmers = pm.split("|");
							
							String lletres = new String("");
							String numeros = new String("");
								//Destriar numeros de lletres dins les referencies
							for (int l = 0; l < pmers.length; ++l)
							{
								if (pmers[l].matches("[a-zA-Z]")) lletres += pmers[l];
								if (pmers[l].matches("\\d")) numeros += pmers[l];
							}
							
								//Un cop dividits, canviar el valor i o j de la referencia
							if (nCols == 1)
							{
								int pam = Integer.parseInt(numeros);
								pam += j;
								numeros = new String("" + pam);
							}
							if (nRows == 1)
							{
									//Es converteix la lletra a lletres a un numero
								int s = 0;
								if (lletres != null && lletres.length() > 0) {
									s = (lletres.charAt(0) - 'A');
									for (int k = 0; k < lletres.length(); k++) {
									s *= 26;
									s += (lletres.charAt(k) - 'A');
									}
								}
									//Se suma el desplaÃ§ament de la referencia al numero
								s += i + 1;
									//Es torna a passar el numero a lletra
								String z = new String("");
								while (s > 0) {
									s--;
									int remainder = s % 26;
									char digit = (char) (remainder + 97);
									z = digit + z;
									s = (s - remainder) / 26;
								}
									//La lletra ha de ser majuscula
								lletres = z.toUpperCase();
							}
							pm = lletres + numeros;
						}
						cambis += pm + ";";
					}
						//S'elimina l'ultim ; (que sobra)
					cambis = cambis.substring(0, cambis.length() - 1);
						//S'adjudica la formula resultant a cada Cella de la seleccio
					if(formula.matches("[a-zA-Z]{1,4}\\d{1,4}")) f.getCella(x, y).getDada().setFormula("=" + canvis);
					else f.getCella(x, y).getDada().setFormula("=" + indicador + "(" + canvis + "|" + cambis + ")");
				}
				else if (parametres.length > 1) throw new FuncioNoAplicable("Funcio en bloc fallida: comprova que no hagis usat | en algun input. No es un caracter permes a les operacions.");
					//Les funcions que no son COVAR ni PEARSON tenen el format:
				else {
					if(formula.matches("[a-zA-Z]{1,4}\\d{1,4}")) mt.get(i).get(j).getDada().setFormula("=" + canvis);
					else mt.get(i).get(j).getDada().setFormula("=" + indicador + "(" + canvis + ")");
				}
			}
	}

	
	
	//atributs
	private ArrayList<ArrayList<Cella>> mt;
	private int initXcoord;
	private int initYcoord;
	private int nRows;
	private int nCols;
}