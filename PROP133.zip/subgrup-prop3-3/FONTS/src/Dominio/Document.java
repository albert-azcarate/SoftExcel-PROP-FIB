package Dominio;
import java.util.*;

public class Document {
	
	private static Document document;
	private String nomDoc;
	private String path;
	private boolean mode;
	private ArrayList<Full> llibreta;
	private Bloc copia;
	private int fullActiu;
	
	/* Crea un document buit */
	private Document() 
	{
		nomDoc = "New Document";
		mode = true;
		path = null;
		llibreta = new ArrayList<Full>(0);
		llibreta.add(new Full(50,50));
		fullActiu = 0;
		try {
			copia = new Bloc(0,0,0,0,llibreta.get(0));
		} catch (FuncioNoAplicable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/* Estableix la instncia del singleton */
	public static void creaSingleton() {
		document = new Document();
	}
	
	// *** Setters i Getters *** //
	
	public static Document GetDoc() { return document; }
	
	public String GetNom() { return nomDoc; }
	public void SetNom(String n) { nomDoc = n; }
	
	public String GetPath() { return path; }
	public void SetPath(String p) { path = p; }
	
	public boolean GetMode() { return mode; }
	public void SetMode(boolean b) { mode = b; }
	
	public Bloc GetCopia() { return copia; }
	public void SetCopia(Bloc c) 
	{ 
		if (c == null) copia = null;
		else copia = (Bloc) c.clone(); 
	}
	
	public void setFullActiu(int a)
	{
		if (a >= 0 && a < GetLengthLlibreta()) fullActiu = a;
	}
	public int GetFullActiu() { return fullActiu; }
	
	public int GetLengthLlibreta() { return llibreta.size(); }
	
	public Full GetFull(int i) { 
		try {
			return llibreta.get(i);
		}
		catch (IndexOutOfBoundsException e) {
			//System.out.print("Error: full no existent " + i + "\n");
			return null;
		}
	}
	
	public Full GetFull(String nom){
		int j = -1;
		Boolean found = false;
		for(int i = 0; !found && i < llibreta.size(); i++) {
			if(llibreta.get(i).getNomFull().equals(nom)) {
				found = true;
				j = i;
			}
		}
		try {
			if(j == -1) return GetFull(Integer.valueOf(nom));
			else return llibreta.get(j);
		}catch (IndexOutOfBoundsException e) {
			//System.out.print("Error: full no existent " + nom + "\n");
			return null;
		}catch (NumberFormatException e1) {
			//System.out.print("Error: full no existent " + nom + "\n");
			return null;
		}
	}
	
	
	// *** Funcions Publiques *** //
	
	/* Inicialitza la llibreta amb un full buit de 10x10 caselles */
	public void InitLlibreta() 
	{
		llibreta.clear();
		llibreta.add(new Full(10,10));
		fullActiu = 0;
	}
	
	
	/* Esborra el contingut del document i s'elimina del sistema tambe */
	public Document eliminarDocument(String nom, String pathDoc)
	{
		for(int i = 0; i < llibreta.size(); ++i)
		{
			eliminarFull(i);
		}
		return null;
	}
	
	/* Afegeix un full nou a la llibreta */
	public void afegirFull()
	{
		llibreta.add(new Full(50,50));
	}
	
	//private void eliminarFull(int i) 					--- Temporalment public per als tests unitaris
	public void eliminarFull(int i) 					// Retorna Full per si implemntem desfer / refer.
	{
		if (i < llibreta.size() && i >= 0) 
		{
			llibreta.remove(i);
			//System.out.print("Full " + i + " eliminat \n" );
		}
		//else System.out.print("Index a ordenar no existents \n" );
	}
	
	/* Canvia el full de la posicio i a j. 
	 * No fa swap de j amb i, sino que va fent swap amb el full contigu, aproximant-se a j. */
	public void ordenarFulls(int i, int j)
	{
		
		if(i < llibreta.size() && j < llibreta.size() && i >= 0 && j >= 0 ) 
		{
			int a = i;
			int b = j;
			if (a<b)
			{
				while(a<b)
				{
					Full aux = llibreta.get(a);
					llibreta.set(a, llibreta.get(b));
					llibreta.set(b, aux);
					--b;
				}	
			}
			else
			{
				while(a>b)
				{
					Full aux = llibreta.get(a);
					llibreta.set(a, llibreta.get(b));
					llibreta.set(b, aux);
					++b;
				}	
			}
			//System.out.print("Full " + i + " mogut a la posicio " + j + "\n");
		}
		else {
			//System.out.print("Index a ordenar no existents \n" );
			return;
		}
		if (i == fullActiu) fullActiu = j;
	}
	
	/* Canvia el mode d'entre clar i fosc. */
	public void SwitchMode()
	{
		mode = !mode;
	}
}
