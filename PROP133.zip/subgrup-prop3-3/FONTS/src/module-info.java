module PROP133 {
	requires java.desktop;
}