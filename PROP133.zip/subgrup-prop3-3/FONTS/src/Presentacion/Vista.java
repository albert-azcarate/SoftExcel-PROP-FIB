package Presentacion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.DebugGraphics;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import Dominio.*;

public class Vista {
	
	private JFrame MainWindow;
	private DefaultTableModel model;
	private JTable Sheet;
	private JMenuBar MenuBar = new JMenuBar();
	private JMenuBar Llibreta = new JMenuBar();
	Cella activa;
	
	
	/*
	 *  Main Window initialitzadora:
	 *  Obra una nova pestanya que et deixa escollir entre crear un document nou i obrir-ne un d'existent com a
	 *  presentacio de l'aplicacio.
	 *  Aquesta primera finestra es tanca en triar alguna de les opcions descrites.
	 *  Tambe pot obrir la documentacio per obtenir ajuda, i ser tancada sense fer res mes.
	 * */

	public void init()
	{
		MainWindow = new JFrame("Full de Calcul 13-3");
		MainWindow.setSize(600,600);
		
		SpringLayout layout = new SpringLayout();
		MainWindow.getContentPane().setLayout(layout);
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
			ex.printStackTrace();
        }
		
		JButton bLoadDoc = new JButton("Obrir Document");
		//bLoadDoc.setBounds(300,350,150,30); 
		bLoadDoc.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){
//				try {
//					String path = ".";
//					Runtime.getRuntime().exec("explorer.exe /select," + path );
//				} catch (IOException e1) {
//					e1.printStackTrace();
//				}
				try {
					treatLoadDoc();
				} catch (FuncioNoAplicable e1) {
					CtrlPresentacio.makePopUp(e1.getMessage());
				}
			}
		});
		bLoadDoc.setVisible(true);
		MainWindow.getContentPane().add(bLoadDoc);
		
		JButton bNewDoc = new JButton("Nou Document");
		//bNewDoc.setBounds(50,350,150,30); 
		bNewDoc.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				CtrlPresentacio.initDoc();
				newDocWindow();
	        }
	    });
		bNewDoc.setVisible(true);
		MainWindow.getContentPane().add(bNewDoc);
		
		JLabel label = new JLabel("Et donem la benvinguda!");
		MainWindow.getContentPane().add(label);
		
		layout.putConstraint(SpringLayout.WEST, bNewDoc, 150, SpringLayout.WEST, MainWindow.getContentPane()); 
		layout.putConstraint(SpringLayout.SOUTH, bNewDoc, -150, SpringLayout.SOUTH, MainWindow.getContentPane()); 
		
		layout.putConstraint(SpringLayout.EAST, bLoadDoc, -150, SpringLayout.EAST, MainWindow.getContentPane()); 
		layout.putConstraint(SpringLayout.SOUTH, bLoadDoc, -150, SpringLayout.SOUTH, MainWindow.getContentPane()); 
		
		layout.putConstraint(SpringLayout.NORTH, label, 300, SpringLayout.NORTH, MainWindow.getContentPane());
		layout.putConstraint(SpringLayout.WEST, label, 240, SpringLayout.WEST, MainWindow.getContentPane());
		MainWindow.setVisible(true);
		MainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MainWindow.setResizable(false);
	}
	
//	public void newDoc()
//	{
//		JFrame MainWindow = new JFrame("Nou Document");
//		MainWindow.setSize(1200,800);
//		MainWindow.setVisible(true);
//		
//		JTable sheet = new JTable(10,10);
//		sheet.setBounds(100,100,1200,800);
//		
//		JScrollPane sp = new JScrollPane(sheet);
//		
//		MainWindow.add(sp);
//	}
//	
	private void newDocWindow()
	{
		MainWindow.setVisible(false);
		MainWindow = new JFrame("Nou Document");
		MainWindow.setSize(1200,800);
		MainWindow.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		MainWindow.setVisible(true);
		MainWindow.setResizable(true);
		
		model  = new DefaultTableModel(CtrlPresentacio.getRows(), CtrlPresentacio.getColumns());
		Sheet = new JTable(model);
		Sheet.setBounds(100,100,1200,800);
		Sheet.setGridColor(new Color(200, 200, 200));
		Sheet.setBackground(new Color(250, 250, 250));
		
		NewCellRenderer ncr = new NewCellRenderer();
		Sheet.setDefaultRenderer(Object.class, ncr);
		
		Sheet.setAutoResizeMode(0);
		newSelectionModel();
		
		// Creacio dels menus de la menubar
		JMenu m1 = new JMenu("Fitxer");
		JMenu m2 = new JMenu("Full");
		JMenu m3 = new JMenu("Blocs");
		
		// Creacio dels items dels menus
		JMenuItem m1i1 = new JMenuItem("Obrir Nou...");
		JMenuItem m1i2 = new JMenuItem("Guardar");
		JMenuItem m1i3 = new JMenuItem("Anomena i Desa");
		JMenuItem m1i4 = new JMenuItem("Exporta CSV");
		JMenuItem m1i5 = new JMenuItem("Exporta PDF");
		JMenuItem m1i6 = new JMenuItem("Elimina Fitxer");
		JMenuItem m1i7 = new JMenuItem("Elimina Full");
		
        JMenuItem m2i1 = new JMenuItem("Afegir Full");
		JMenuItem m2i2 = new JMenuItem("Nombrar Full");
		JMenuItem m2i3 = new JMenuItem("Ordenar Full");
		JMenuItem m2i4 = new JMenuItem("Afegir Columna");
		JMenuItem m2i5 = new JMenuItem("Afegir Fila");
		JMenuItem m2i6 = new JMenuItem("Afegir Columnes...");
		JMenuItem m2i7 = new JMenuItem("Afegir Files...");
		JMenuItem m2i8 = new JMenuItem("Eliminar Columna");
		JMenuItem m2i9 = new JMenuItem("Eliminar Fila");
		JMenuItem m2i10 = new JMenuItem("Eliminar Columnes...");
		JMenuItem m2i11 = new JMenuItem("Eliminar Files...");
		
		JMenuItem m3i1 = new JMenuItem("Modificar");
		JMenuItem m3i2 = new JMenuItem("Copiar");
		JMenuItem m3i3 = new JMenuItem("Enganxar");
		JMenuItem m3i4 = new JMenuItem("Substituir");
		JMenuItem m3i5 = new JMenuItem("Esborrar");
		JMenuItem m3i6 = new JMenuItem("Buscar");
		JMenuItem m3i7 = new JMenuItem("Ordenar");
		JMenuItem m3i8 = new JMenuItem("Aplicar funcio");
		JMenuItem m3i9 = new JMenuItem("Moure");


		//JMenuItem m2i6 = new JMenuItem("Esborrar Full");
		
		
		// Afegim accions als botons del menu
		// Obrir Nou...
		m1i1.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				try {
					treatLoadDoc();
				} catch (FuncioNoAplicable e1) {
					// TODO Auto-generated catch block
					CtrlPresentacio.makePopUp(e1.getMessage());
				}
		       }
		});
		// Guardar
		m1i2.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				try{
					save();
				}
				catch (IndexNoValid | IOException ex) {
					ex.printStackTrace();
				} catch (FuncioNoAplicable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
		});
		// Anomena i Desa
		m1i3.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				try{
					saveAs();
				}
				catch (IndexNoValid | IOException ex) {
					ex.printStackTrace();
				} catch (FuncioNoAplicable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
		});
		// Exporta CSV
		m1i4.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				try{
					exportaCSV();
				}
				catch (IndexNoValid | IOException ex) {
					ex.printStackTrace();
				} catch (FuncioNoAplicable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
		});
		// Exporta PDF
		m1i5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//exportaPDF();
			}
		});
		// Elimina Fitxer
		m1i6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					eliminaFitxer();
				}
				catch (FuncioNoAplicable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		// Elimina Fitxer
		m1i7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteFull();
			}
		});
		
		// *** Fi del Menu 1: Fitxer ***
		// -----------------------------
		// Funcionalitats botons menu format
		
        // Add New Full
		m2i1.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				addFull();
	        }
		});
		// Nombra Full
		m2i2.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				nombrarFull();
	        }
		});
		// Ordena Full
		m2i3.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				ordenarFull();
	        }
		});
		// Add New Column
		m2i4.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				addNewCol();
	        }
		});
		// Add New Row
		m2i5.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				addNewRow();
	        }
		});
		// Add Columns...
		m2i6.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				addColSet();
	        }
		});
		
		// Add Rows...
		m2i7.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				addRowSet();
	        }
		});
		//Eliminar Columna
		m2i8.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				deleteColumn();
			}
		});
				
				//Eliminar Fila
		m2i9.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				deleteRow();
		       }
		});
		
		//Eliminar columnes...
		m2i10.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){ 
				deleteColumnSet();
		       }
		});
		
		//Eliminar Files...
		m2i11.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){ 
				deleteRowSet();
		       }
		});
				

		
//		Esborrar Full
//		m2i6.addActionListener(new ActionListener(){  
//			public void actionPerformed(ActionEvent e){  
//				deleteFull();
//	        }
//		});
		
		// *** Fi del Menu 2: Full ***
		// -----------------------------
		
		m3i1.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				modificarContBloc(); 
	        }
		});
		
		m3i2.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				copiarSeleccio();
	        }
		});
		
		m3i3.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				enganxarCopia();
	        }
		});
		
		m3i4.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				reemContBloc();
	        }
		});
		
		m3i5.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				esborrarContBloc();
	        }
		});
		
		m3i6.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				cercaBloc();
	        }
		});
		
		m3i7.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				ordenarBloc();
	        }
		});
		
		m3i8.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				String input;
				input = JOptionPane.showInputDialog ("A quina columna o fila vols aplicar la formula \nde la cella en la 1a posicio de la regio seleccionada?\n(Format:Cella Inicial; Cella Final)");
				String[] data = input.split(";");
				for(int i = 0; i < data.length; i++)data[i] = data[i].trim();
				try {
					CtrlPresentacio.aplicarFuncio(data);
					refreshSheet();
				} catch (FuncioNoAplicable ef) {
					CtrlPresentacio.makePopUp(ef.getMessage());
        			refreshSheet();
				}
	        }
		});

		
		m3i9.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				moureSeleccio();
	        }
		});

		
		// *** Fi del Menu 3: Blocs ***
		// -----------------------------
		// Creacio de Botons Extres Utils
		JButton bDesfer = new JButton("Desfer");
		bDesfer.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				desfer();
	        }
		});
		
		JButton bRefer = new JButton("Refer");
		bRefer.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				refer();
	        }
		});
		/* Boto de bold */
		JButton bBold = new JButton("B");
		bBold.setFont(new Font(Font.DIALOG, Font.BOLD, 11));
		bBold.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){
				try {
					CtrlPresentacio.setFormatBold(activa.getCols(), activa.getRows());
				} catch (FuncioNoAplicable e1) {
					CtrlPresentacio.makePopUp(e1.getMessage());
				}
				refreshSheet();
	        }
		});
		/* Boto de italics */
		JButton bItalics = new JButton("I");
		bItalics.setFont(new Font(Font.DIALOG, Font.ITALIC, 11));
		bItalics.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				try {
					CtrlPresentacio.setFormatItalics(activa.getCols(), activa.getRows());
				} catch (FuncioNoAplicable e1) {
					CtrlPresentacio.makePopUp(e1.getMessage());
				}
				refreshSheet();
	        }
		});
		/* Boto de underline. NO FUNCIONAL: no existeix manera de fer-ho que hagi trobat; hi ha un codi no funcional a l'ultima classe de l'arxiu */
//		JButton bUnderline = new JButton("U");
//		bUnderline.addActionListener(new ActionListener(){  
//			public void actionPerformed(ActionEvent e){  
//				ControladorDomini.setFormatUnderline(activa.getCols(), activa.getRows());
//	        }
//		});
		/* Boto de mida */
		JButton bMida = new JButton("Mida");
		bMida.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				String mida = JOptionPane.showInputDialog ("Escriu la mida que vols aplicar al contingut de la cella:");
				Double m = 11.0;
				try {
					m = Double.parseDouble(mida);
				} catch (NumberFormatException nfe) {
					CtrlPresentacio.makePopUp("Mida ha de ser un valor enter positiu.");
				} catch (NullPointerException npe) {
					CtrlPresentacio.makePopUp("Has d'introduir un numero.");
				}
				try {
					CtrlPresentacio.setMida(activa.getCols(), activa.getRows(), m);
				} catch (FuncioNoAplicable e1) {
					CtrlPresentacio.makePopUp(e1.getMessage());
				}
				refreshSheet();
	        }
		});
		/* Boto de pintar */
		JButton bColor = new JButton("Pintar");
		bColor.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				String input = JOptionPane.showInputDialog ("Indica el conjunt de celles a pintar:\n(Format:Cella Inicial;Cella Final;Color)\nSelecciona el color:\n0: Blanc, 1: Blau, 2: Verd, 3: Vermell, 4: Groc");
				String[] parametres = input.split(";");
				for(int i = 0; i < parametres.length; i++)parametres[i] = parametres[i].trim();
				try {
					CtrlPresentacio.pintarBloc(parametres);
					refreshSheet();
				} catch (FuncioNoAplicable fna) {
					CtrlPresentacio.makePopUp(fna.getMessage());
	    			refreshSheet();
				}
	        }
		});
		
		
		// Vincula els items del menu al menu corrsponent
		m1.add(m1i1); // Obrir Nou...
		m1.add(new JSeparator());
		m1.add(m1i2); // Guardar
		m1.add(m1i3); // Anomena i Desa
		m1.add(m1i4); // Exportar CSV
		m1.add(m1i5); // Exportar PDF
		m1.add(new JSeparator());
		m1.add(m1i6); // Elimina Fitxer
		m1.add(m1i7); // Elimina Full
		
		m2.add(m2i1); // Afegir Full
		m2.add(m2i2); // Nombrar Full
		m2.add(m2i3); // Ordenar Full
		m2.add(new JSeparator());
		m2.add(m2i4); // Afegir Columna
		m2.add(m2i5); // Afegir Fila
		m2.add(m2i6); // Afegir Columnes
		m2.add(m2i7); // Afegir Files
		m2.add(new JSeparator());
		m2.add(m2i8); // Eliminar Columna
		m2.add(m2i9); // Eliminar Fila
		m2.add(m2i10); // Eliminar Columnes
		m2.add(m2i11); // Eliminar Files
		
		m3.add(m3i1);
		m3.add(m3i2);
		m3.add(m3i3);
		m3.add(m3i4);
		m3.add(m3i5);
		m3.add(m3i6);
		m3.add(m3i7);
		m3.add(m3i8);
		m3.add(m3i9);

		// Creacio de la barra de formules:
		JLabel Formula = new JLabel("Formula:");
		JLabel Coordenada = new JLabel("Coordenades:");
		
		// S'afegeix cada menu a la barra de menu
		MenuBar.add(new JLabel("    PROP    | "));
		MenuBar.add(m1);
		MenuBar.add(new JLabel(" | "));
		MenuBar.add(m2);
		MenuBar.add(new JLabel(" | "));
		MenuBar.add(m3);
		MenuBar.add(new JLabel(" |     "));
		MenuBar.add(bDesfer);
		MenuBar.add(new JLabel(" | "));
		MenuBar.add(bRefer);
		MenuBar.add(new JLabel("     | "));
		MenuBar.add(bBold);
		MenuBar.add(bItalics);
	//	MenuBar.add(bUnderline);
		MenuBar.add(bMida);
		MenuBar.add(bColor);
		MenuBar.add(new JLabel(" | "));
		MenuBar.add(Formula);
		MenuBar.add(new JLabel(" | "));
		MenuBar.add(Coordenada);
		
		// Creacio Barra de canvi de full:
		barraLlibreta();
		
		// S'afegeix la taula en un ScrollPane
		JScrollPane sp = new JScrollPane(Sheet);

		// Es crea un Pane per a tenir el Menu i la Taula alhora
		JPanel p = new JPanel(new BorderLayout());
		
		p.add(MenuBar, BorderLayout.NORTH);
		p.add(sp, BorderLayout.CENTER);
		p.add(Llibreta, BorderLayout.SOUTH);
		
		// S'afegeix tot a la Main Window
		MainWindow.add(p);
		
		MainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void ordenarFull() {
		String input = JOptionPane.showInputDialog("A quina posicio vols moure el full actual? \n(Introdueix un numero. Exemple: 0 per a la primera posicio)");
		try {
			if(Integer.parseInt(input) >= 0 && Integer.parseInt(input) < CtrlPresentacio.getLengthLlibreta()) 
			{
				CtrlPresentacio.ordenaFull(Integer.parseInt(input));
				barraLlibreta();
			}
			else
			{
				CtrlPresentacio.makePopUp("Index de full no valid.");
			}

		} catch (NumberFormatException nfe) {
			CtrlPresentacio.makePopUp("Valor introduit no es numero.");
		}
		
	}

	private void nombrarFull() {
		String input = JOptionPane.showInputDialog("Introdueix el nom que vols posar al full actual.");
		
		Component[] componentList = Llibreta.getComponents();
		
		int i = CtrlPresentacio.getFullActiu();

		for(Component c : componentList)
		{
			if (((AbstractButton) c).getActionCommand().equals(Integer.toString(i)))
			{
				((AbstractButton) c).setText(input);
				if (((AbstractButton) c).getActionCommand().equals(Integer.toString(i)))
					((AbstractButton) c).setActionCommand(Integer.toString(i));
				
				CtrlPresentacio.nombrarFull(input);
				
				break;
			}
		}
	}

	private void copiarSeleccio() {
		String input;
		input = JOptionPane.showInputDialog ("Quina regio vols copiar?\n(Format:Cella Inicial; Cella Final)");
		String[] data = input.split(";");
		for(int i = 0; i < data.length; i++)data[i] = data[i].trim();
		try {
			CtrlPresentacio.copiar(data);
		} catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}
	
	private void modificarContBloc() {
		String input;
		input = JOptionPane.showInputDialog ("Quina regio vols modificar i quin nou valor tindra?\n(Format:Cella Inicial; Cella Final; Nou valor)");
		
		String[] data = input.split(";");
		for(int i = 0; i < data.length - 1; i++)data[i] = data[i].trim();
		try {
			CtrlPresentacio.modificar(data);
			refreshSheet();
		} catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}
	
	private void enganxarCopia() {
		String input;
		input = JOptionPane.showInputDialog ("A on vols enganxar les dades?\n(Format:Cella Inicial)");
		String[] data = {input.trim()};
		try {
			CtrlPresentacio.enganxar(data);
			refreshSheet();
		} catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}
	
	
	private void reemContBloc() {
		String input;
		input = JOptionPane.showInputDialog ("Quina regio vols modificar, quin valor vols cambiar per a quin altre?\n(Format:Cella Inicial; Cella Final; Valor antic; Nou valor)");
		String[] data = input.split(";");
		for(int i = 0; i < data.length - 2; i++)data[i] = data[i].trim();
		try {
			CtrlPresentacio.substituir(data);
			refreshSheet();
		} catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}
	
	private void esborrarContBloc() {
		String input;
		input = JOptionPane.showInputDialog ("Quina regio vols esborrar\n(Format:Cella Inicial; Cella Final)");
		String[] data = input.split(";");
		for(int i = 0; i < data.length; i++)data[i] = data[i].trim();
		try {
			CtrlPresentacio.esborrar(data);
			refreshSheet();
		} catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}
	
	private void cercaBloc() {
		String input;
		input = JOptionPane.showInputDialog ("A quina regio vols buscar que?\n(Format:Cella Inicial; Cella Final; Valor a buscar)");
		String[] data = input.split(";");
		for(int i = 0; i < data.length - 1; i++)data[i] = data[i].trim();
		String valor = data[2];
		try {
			CtrlPresentacio.buscar(data);
			CtrlPresentacio.makePopUp("S'han trobat " + data[0] + " vegades el valor " + valor);
		} catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}
	
	private void ordenarBloc() {
		String input;
		input = JOptionPane.showInputDialog ("Quina regio vols ordenar i amb quin criteri?\n(Format:Cella Inicial; Cella Final; Criteri d'ordenacio)");
		String[] data = input.split(";");
		for(int i = 0; i < data.length; i++)data[i] = data[i].trim();
		try {
			CtrlPresentacio.ordenar(data);
			refreshSheet();
		} catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}

	private void moureSeleccio() {
		String input;
		input = JOptionPane.showInputDialog ("Quina regio vols moure i a on?\n(Format:Cella Inicial; Cella Final; Cella desti)");
		String[] data = input.split(";");
		for(int i = 0; i < data.length; i++)data[i] = data[i].trim();
		try {
			CtrlPresentacio.moure(data);
			refreshSheet();
		} catch (FuncioNoAplicable ef) {
			CtrlPresentacio.makePopUp(ef.getMessage());
		}
	}

	private void deleteFull() {
		int input = JOptionPane.showConfirmDialog(MainWindow, "S'esborrara el full actual. Seguir?", null, JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE, null);
		if (input == 0)
		{
			Component[] componentList = Llibreta.getComponents();

			for(Component c : componentList)
			{
				if (((AbstractButton) c).getActionCommand().equals(Integer.toString(CtrlPresentacio.getFullActiu())) && CtrlPresentacio.getLengthLlibreta() > 1)
				{
					((AbstractButton) c).setVisible(false);
					updateActionContents(Integer.parseInt(((AbstractButton) c).getActionCommand()));
					Llibreta.remove((AbstractButton) c);
					Llibreta.revalidate();
					Llibreta.updateUI();
					CtrlPresentacio.esborrarFull();
					break;
				}
				else if (CtrlPresentacio.getLengthLlibreta() <= 1)
				{
					CtrlPresentacio.makePopUp("Nomes hi ha un full. No es pot eliminar.");
					break;
				}
			}
		}
		else if(input == 1)
		{
			CtrlPresentacio.makePopUp("Cancellat");
		}
	}

	private void updateActionContents(int i) {
		for(Component c : Llibreta.getComponents())
		{
			if (!((AbstractButton) c).getActionCommand().equals("+"))
			if (Integer.parseInt(((AbstractButton) c).getActionCommand()) > (CtrlPresentacio.getFullActiu()) && CtrlPresentacio.getLengthLlibreta() > 0)
			{
				((AbstractButton) c).setActionCommand(Integer.toString(Integer.parseInt(((AbstractButton) c).getActionCommand())-1));
			}
		}
	}

	private void addRowSet() {
		String input;
		input = JOptionPane.showInputDialog("Quantes files vols afegir?");
		
		try {
			if(model.getRowCount() + Integer.parseInt(input) > 100)
			{
				CtrlPresentacio.makePopUp("Massa files. Maxim: 100. Demanades: " + Integer.toString(model.getRowCount() + Integer.parseInt(input)));
			}
			
			else if (Integer.parseInt(input) < 0) CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
			
			else
			{
				for(int i = 0; i < Integer.parseInt(input); ++i)
				{
					addNewRow();
				}
			}
		} catch (NumberFormatException nfe){
			CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
		}
	}

	private void addColSet() {
		String input;
		input = JOptionPane.showInputDialog ("Quantes columnes vols afegir?");
		try {
			if(model.getColumnCount() + Integer.parseInt(input) > 100)
			{
				CtrlPresentacio.makePopUp("Massa columnes. Maxim: 100. Demanades: " + Integer.toString(model.getColumnCount() + Integer.parseInt(input)));
			}
			
			else if (Integer.parseInt(input) < 0) CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
			
			else
			{
				for(int i = 0; i < Integer.parseInt(input); ++i)
				{
					addNewCol();
				}
			}
		} catch (NumberFormatException nfe){
			CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
		}
	}

	private void addFull() 
	{
		CtrlPresentacio.addFull();
	}

	public void barraLlibreta() 
	{
		Component[] componentList = Llibreta.getComponents();

		for(Component c : componentList)
		{
			((AbstractButton) c).setVisible(false);
			Llibreta.remove((AbstractButton) c);
		}
		JButton bNouFull = new JButton("+");
		bNouFull.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addFull();
			}
		});
		
		Llibreta.add(bNouFull);
		
		int fActiu = CtrlPresentacio.getFullActiu();
		
		for(int i = 0; i < CtrlPresentacio.getLengthLlibreta(); ++i)
		{
			CtrlPresentacio.setFullActiu(i);
			makeFullButton(i);
		}
		CtrlPresentacio.setFullActiu(fActiu);
		
		Llibreta.revalidate();
		Llibreta.updateUI();
	}

	public void makeFullButton(int i) {
		JButton FullIessim = new JButton(CtrlPresentacio.getNomFull());
		FullIessim.setActionCommand(Integer.toString(i));
		//System.out.print(FullIessim.getActionCommand());
		FullIessim.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				canviarFull(Integer.parseInt(FullIessim.getActionCommand()));
		    }
		});
		Llibreta.add(FullIessim);
		Llibreta.revalidate();
	}
	
	public void canviarFull(int Full) {
		//Ha de refer la taula amb els valors del Full en questio.
		//System.out.print(Full);
		
		CtrlPresentacio.setFullActiu(Full);
		
		model.setRowCount(CtrlPresentacio.getRows());
		model.setColumnCount(CtrlPresentacio.getColumns());
		
		for(int i = 0; i < CtrlPresentacio.getRows(); ++i)
		{
			for(int j = 0; j < CtrlPresentacio.getColumns(); ++j)
			{
				//Sheet.setValueAt(Integer.toString(i) + Integer.toString(j), i, j); 		// stub per a getContingutAt(x, y);
				try {
					Sheet.setValueAt(CtrlPresentacio.getContingutAt(i, j), i, j);
				} catch (FuncioNoAplicable e) {
					CtrlPresentacio.makePopUp(e.getMessage());
				}
			}
		}
		Sheet.updateUI();
	}

	private void addNewRow() {
		if (Sheet.getRowCount() < 100) 
		{
			CtrlPresentacio.addRow(Sheet.getSelectedRow()+1);
			model.setRowCount(CtrlPresentacio.getRows());
			try {
				actualitzaContinguts();
			} catch (FuncioNoAplicable e) {
				CtrlPresentacio.makePopUp(e.getMessage());
			}
		}
		
		else
		{
			CtrlPresentacio.makePopUp("El maxim de files es 100");
		}
	}
	
	private void deleteColumn() {
		if (Sheet.getColumnCount() > 1) {
			try {
				CtrlPresentacio.deleteColumn(Sheet.getSelectedColumn());
				model.setColumnCount(CtrlPresentacio.getColumns());
				actualitzaContinguts();
			} catch (IndexNoValid e) {
				CtrlPresentacio.makePopUp(e.getMessage());
			} catch (FuncioNoAplicable e) {
				CtrlPresentacio.makePopUp(e.getMessage());
			}

		}
		else CtrlPresentacio.makePopUp("No es poden borrar mes columnes");
	}
	
		private void deleteRow() {
		if (Sheet.getRowCount() > 1) {
			try {
				CtrlPresentacio.deleteRow(Sheet.getSelectedRow());
				model.setRowCount(CtrlPresentacio.getRows());
				actualitzaContinguts();
			} catch (IndexNoValid e) {
				CtrlPresentacio.makePopUp(e.getMessage());
			} catch (FuncioNoAplicable e) {
				CtrlPresentacio.makePopUp(e.getMessage());
			}

		}
		else CtrlPresentacio.makePopUp("No es poden borrar mes files");
	}
	
	
	private void deleteColumnSet() {
		String input;
		input = JOptionPane.showInputDialog ("Quantes columnes vols esborrar? \n(Atencio: es perdran les dades de les caselles esborrades)");
		try {
			if(model.getColumnCount() - Sheet.getSelectedColumn() - Integer.parseInt(input) < 1)
			{
				if (model.getColumnCount() - Integer.parseInt(input) < 1) CtrlPresentacio.makePopUp("Massa columnes a eliminar. Minim: 1");
				else CtrlPresentacio.makePopUp("Massa files a eliminar des de la columna seleccionada. \nElimina menys o des d'una columna a l'esquerra.");
			}
			
			else if (Integer.parseInt(input) > 0)
			{
				try {
					CtrlPresentacio.deleteColumnSet(Integer.parseInt(input), Sheet.getSelectedColumn());
					model.setColumnCount(CtrlPresentacio.getColumns());
					actualitzaContinguts();
				} catch (FuncioNoAplicable e) {
					CtrlPresentacio.makePopUp(e.getMessage());
				} catch (NumberFormatException nfe) {
					CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
				}
			}
			
			else
			{
				CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
			} 
		} catch (NumberFormatException nfe) {
			CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
		}
	}
	
	private void deleteRowSet() {
		String input;
		input = JOptionPane.showInputDialog ("Quantes columnes vols esborrar? \n(Atencio: es perdran les dades de les caselles esborrades)");
		try {
			if(model.getRowCount() - Sheet.getSelectedRow() - Integer.parseInt(input) < 1)
			{
				if (model.getRowCount() - Integer.parseInt(input) < 1) CtrlPresentacio.makePopUp("Massa files a eliminar. Minim: 1");
				else CtrlPresentacio.makePopUp("Massa files a eliminar des de la fila seleccionada. \nElimina menys o des d'una fila superior.");
			}
			
			else if (Integer.parseInt(input) > 0)
			{
				try {
					CtrlPresentacio.deleteRowSet(Integer.parseInt(input), Sheet.getSelectedRow());
					model.setRowCount(CtrlPresentacio.getRows());
					actualitzaContinguts();
				} catch (FuncioNoAplicable e) {
					CtrlPresentacio.makePopUp(e.getMessage());
				}
			}
			
			else
			{
				CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
			}
		} catch (NumberFormatException nfe) {
			CtrlPresentacio.makePopUp("Valor incorrecte. Introdueix un enter major que 0.");
		}
			
	}

	
	private void desfer() {
		try {
			CtrlPresentacio.desfer();
		}catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
		refreshSheet();
	}
	
	private void refer() {
		try {
			CtrlPresentacio.refer();
		}catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
		refreshSheet();
	}
	
	private void addNewCol() {
		if (Sheet.getColumnCount() < 100) 
		{
			CtrlPresentacio.addCol(Sheet.getSelectedColumn()+1);
			model.setColumnCount(CtrlPresentacio.getColumns());
			try {
				actualitzaContinguts();
			} catch (FuncioNoAplicable e) {
				CtrlPresentacio.makePopUp(e.getMessage());
			}
		}
		
		else
		{
			CtrlPresentacio.makePopUp("El maxim de columnes es 100");
		}
	}
	
	private void eliminaFitxer() throws FuncioNoAplicable{
		int input = JOptionPane.showConfirmDialog(MainWindow, "S'esborrara el document actual. Seguir?", null, JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE, null);
		if (input == 0) {
			String path = CtrlPresentacio.getPath();
			if(path != null) CtrlPresentacio.eliminaDoc(path);
		}
		
		
	}

	private void save() throws IndexNoValid, IOException, FuncioNoAplicable{
		String path = CtrlPresentacio.getPath();
			if(path == null) saveAs();
			else CtrlPresentacio.guardarDocFormatPropi(CtrlPresentacio.getPath());
		
		
	}
	
	private void saveAs() throws IndexNoValid, IOException, FuncioNoAplicable{
		JFileChooser chooser = new JFileChooser();
			int status = chooser.showOpenDialog(null);
			if (status == JFileChooser.APPROVE_OPTION) {
				File file = chooser.getSelectedFile();
				if (file == null) {
					return;
				}

	           String path = chooser.getSelectedFile().getAbsolutePath();
	           CtrlPresentacio.guardarDocFormatPropi(path);
			}
	}
	
	private void exportaCSV() throws IndexNoValid, IOException, FuncioNoAplicable{
		JFileChooser chooser = new JFileChooser();
			int status = chooser.showOpenDialog(null);
			if (status == JFileChooser.APPROVE_OPTION) {
				File file = chooser.getSelectedFile();
				if (file == null) {
					return;
				}

	           String path = chooser.getSelectedFile().getAbsolutePath();
	           CtrlPresentacio.guardarDocCSV(path);
			}
	}

	private void treatLoadDoc() throws FuncioNoAplicable
	{
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
			ex.printStackTrace();
        }
		 
		JFileChooser chooser = new JFileChooser();
		int status = chooser.showOpenDialog(null);
		if (status == JFileChooser.APPROVE_OPTION) {
			File file = chooser.getSelectedFile();
			if (file == null) {
				return;
			}

           String fileName = chooser.getSelectedFile().getAbsolutePath();
           CtrlPresentacio.loadSelectedDoc(fileName, this);						// ? What did I do?
           CtrlPresentacio.setPath(fileName);
       }
	}
	
	private void refreshSheet()
	{
		model.setColumnCount(CtrlPresentacio.getColumns());
		model.setRowCount(CtrlPresentacio.getRows());
		
		for(int i = 0; i < CtrlPresentacio.getRows(); ++i)
		{
			for(int j = 0; j < CtrlPresentacio.getColumns(); ++j)
			{
				try {
					Sheet.setValueAt(CtrlPresentacio.getContingutAt(i, j), i, j);
				} catch (FuncioNoAplicable e) {
					CtrlPresentacio.makePopUp(e.getMessage());
				} 		// stub per a getContingutAt(x, y);
			}
		}
	}
	
	public void loadDocWindow()
	{
		newDocWindow();
		//CtrlPresentacio.loadDoc();
		try {
			actualitzaContinguts();
		} catch (FuncioNoAplicable e) {
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}
	
	public void newSelectionModel()
	{
		Sheet.getModel().addTableModelListener(new TableModelListener() {
            public void tableChanged(TableModelEvent e) {
                if (e.getColumn() != -1 && e.getFirstRow() != -1) 
                {
                	try 
                	{
                		activa = CtrlPresentacio.getCellaAt(e.getFirstRow(), e.getColumn());
                		((JLabel) MenuBar.getComponent(16)).setText("Formula: " + activa.getDada().getFormula());
                		String input = Sheet.getValueAt(e.getFirstRow(), e.getColumn()).toString();   
                			//El contingut es diferent al que previament hi havia?
                		boolean canvi = !input.equals(CtrlPresentacio.getCellaAt(e.getFirstRow(), e.getColumn()).getDada().getContingut());
            		    	//La forumla es diferent a la que previament hi havia
                		boolean formulacio = !input.equals(CtrlPresentacio.getCellaAt(e.getFirstRow(), e.getColumn()).getDada().getFormula());
            		    	//La formula es buida?
                		boolean buit = CtrlPresentacio.getCellaAt(e.getFirstRow(), e.getColumn()).getDada().getFormula().equals("");
                		if(canvi && (formulacio || buit)){
                			int Rows = activa.getRows();
                    		int Cols = activa.getCols();
                    		
                    		//rows a alfanumeric
                    		String result = "";
                    		Rows++;
                    	    while (Rows > 0) {
                    	      Rows--; // 1 => a, not 0 => a
                    	      int remainder = Rows % 26;
                    	      char digit = (char) (remainder + 97);
                    	      result = digit + result;
                    	      Rows = (Rows - remainder) / 26;
                    	    }
                    	    result = new String(result.toUpperCase());
                    	    ((JLabel) MenuBar.getComponent(18)).setText("Coordenades: " + result + Cols );
                    		
                			
                			CtrlPresentacio.parser(input, e.getFirstRow(), e.getColumn());
                			refreshSheet();
                		}
                		if(input.length()>1 && input.charAt(0) == '=')
							Sheet.setValueAt(CtrlPresentacio.getContingutAt(e.getFirstRow(), e.getColumn()), e.getFirstRow(), e.getColumn());
                	} catch (FuncioNoAplicable fna) {
                	//	Sheet.setBackground(Color.cyan);
                		CtrlPresentacio.makePopUp(fna.getMessage());
            			refreshSheet();
					}

                }
            }
        });
	}

	public void setContent(String cont, int x, int y) {
		try
		{
			Sheet.setValueAt(cont, x, y);
		} catch (IndexOutOfBoundsException e)
		{
			CtrlPresentacio.makePopUp(e.getMessage());
		}
	}

	public void actualitzaContinguts() throws FuncioNoAplicable {
		for(int i = 0; i < CtrlPresentacio.getRows(); ++i)
		{
			for(int j = 0; j < CtrlPresentacio.getColumns(); ++j)
			{
				Sheet.setValueAt(CtrlPresentacio.getContingutAt(i, j), i, j);
			}
		}
	}
}

/* Classe encarregada d'aplicar els formats alternatius de Cella */
class NewCellRenderer extends DefaultTableCellRenderer {

	private static final long serialVersionUID = 1L;
	
	@Override
	public JComponent getTableCellRendererComponent(JTable sheet, Object value, boolean isSelected, boolean hasFocus, int column, int row) {
	    super.getTableCellRendererComponent(sheet, value, isSelected, hasFocus, column, row);
	    boolean bold = false, italics= false;
	    int mida = 0, color = 0;
	    
	    try {
		    bold = CtrlPresentacio.getFormatBold(column, row);
		    italics = CtrlPresentacio.getFormatItalics(column, row);
	//	    boolean underline = CtrlPresentacio.getFormatUnderline(column, row);
		    mida = (int)Math.floor(CtrlPresentacio.getMida(column, row));
		    color = CtrlPresentacio.getColor(column, row);
	    }catch(FuncioNoAplicable e) {
	    	CtrlPresentacio.makePopUp(e.getMessage());
	    }
	    
	    this.setForeground(Color.BLACK);
	    
	    if (color == 0) this.setBackground(Color.WHITE);
	    else if (color == 1) this.setBackground(Color.BLUE);
	    else if (color == 2) this.setBackground(Color.GREEN);
	    else if (color == 3) this.setBackground(Color.RED);
	    else if (color == 4) this.setBackground(Color.YELLOW);
	    
	    if (bold && italics)
	    	this.setFont(new Font(Font.DIALOG, Font.BOLD | Font.ITALIC, mida));
	    else if (bold)
	    	this.setFont(new Font(Font.DIALOG, Font.BOLD, mida)); 
	    else if (italics)
	    	this.setFont(new Font(Font.DIALOG, Font.ITALIC, mida));
//	    else if (underline)
//	    	return new Subratllar(value.toString());
	    else
	    	this.setFont(new Font(Font.DIALOG, Font.PLAIN, mida));
	    
	    return this;
	}
}

/* Classe que subratlla el contingut d'una cella */
class Subratllar extends JLabel {
	
	private static final long serialVersionUID = 1L;

	/* Creadores */
	public Subratllar () { }
	
	public Subratllar (Icon i) { }
	
	public Subratllar (Icon i, int alineacio) { super(i, alineacio); }
	
	public Subratllar (String text) { super(text); }
	
	public Subratllar (String text, Icon i, int alineacio) { super(text, i, alineacio); }
	
	public Subratllar (String text, int alineacio) { super(text, alineacio); }
	
	public void pintar (DebugGraphics g) {
		super.paint(g);
		subratlla(g);
	}
	
	/* Metode responsable per subratllar el text */
	protected void subratlla (DebugGraphics g) {
		Insets insets = getInsets();
		FontMetrics font = g.getFontMetrics();
		Rectangle areaText = new Rectangle();
		Rectangle areaVista = new Rectangle(insets.left, insets.top, getWidth()-(insets.left + insets.right), getHeight() - (insets.bottom + insets.top));
		
			//Retorna la localitzacio relativa a vista de l'origen de la icona i de la base del text
		String text = SwingUtilities.layoutCompoundLabel(this, font, getText(), getIcon(), getVerticalAlignment(), getHorizontalAlignment(), getVerticalTextPosition(), getHorizontalTextPosition(), areaVista, new Rectangle(), areaText, getText() == null ? 0 : ((Integer)UIManager.get("Button.textIconGap")).intValue());
		
		int offset = ((Integer) UIManager.get("Button.textShiftOffset")).intValue();
		
		g.fillRect(areaText.x + offset - 4, areaText.y + font.getAscent() + offset + 2, areaText.width, 1);
	}
}
