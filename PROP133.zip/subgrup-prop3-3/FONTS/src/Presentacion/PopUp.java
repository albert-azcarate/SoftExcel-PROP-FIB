package Presentacion;

import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class PopUp {
	private JLabel missatge = new JLabel();
	private JFrame finestra = new JFrame();
	private JButton help;
	private JButton ok;
	
	public PopUp()
	{	
		finestra = new JFrame();
		finestra.setSize(350, 250);
		finestra.setVisible(true);
		finestra.setLayout(new BorderLayout());
		
		missatge.setText("Empty message");
		missatge.setBounds(25, 25, 225, 50);
		missatge.setHorizontalAlignment(SwingConstants.CENTER);
		finestra.add(missatge, BorderLayout.CENTER);
		
		JPanel p = new JPanel();
		
		ok = new JButton("Ok");
		ok.setBounds(0, 0, 60, 30);
		ok.setVisible(true);
		ok.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				finestra.setVisible(false);
			}
        });
		p.add(ok);
		
		help = new JButton("Help");
		help.setBounds(60, 0, 60, 30);
		help.setVisible(true);
		help.addActionListener( new ActionListener()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		        openWebPage("https://drive.google.com/file/d/1Ezd0g7g3NMeyHMQsdUAEqkSb0kwsWcrI/view?usp=sharing");
		    }
		});
		p.add(help);
		
		finestra.add(p, BorderLayout.SOUTH);
	}

	public void mostrarMissatge(String string) {
		missatge.setText(string);
	}
	
	public void openWebPage(String url){
		   try {         
		     java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
		   }
		   catch (java.io.IOException e) {
		       CtrlPresentacio.makePopUp(e.getMessage());
		   }
		}

}
