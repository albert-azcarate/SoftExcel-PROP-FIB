package Presentacion;
import java.io.FileNotFoundException;
import java.io.IOException;

import Dominio.*;

public class CtrlPresentacio {
	
	private static Vista window;
	public static void init()
	{
		window = new Vista();
		window.init();
	}
	
	/* Carrega el document */
	public static void loadDoc()
	{
		initDoc();
		//Controlador Domini. carrega doc de: path;
	} 
	
	/* Setter */
	public static void setPath(String fileName) {
		ControladorDomini.setPath(fileName);
	}
	
	public static void setFormatBold(int x, int y) throws FuncioNoAplicable {
		ControladorDomini.setFormatBold(x, y);
	}
	
	public static void setFormatItalics(int x, int y) throws FuncioNoAplicable {
		ControladorDomini.setFormatItalics(x, y);
	}
	
	public static void setMida(int x, int y, Double m) throws FuncioNoAplicable {
		ControladorDomini.setMida(x, y, m);
	}

	/* Getters */
	public static String getPath() throws FuncioNoAplicable {
		return ControladorDomini.getPath();
	}
	
	public static int getRows() {
		return ControladorDomini.getNumRows();
	}

	public static int getColumns() {
		return ControladorDomini.getNumCols();
	}

	public static String getNom() {
		return ControladorDomini.getNomDocument();
	}

	public static Object getContingutAt(int x, int y) throws FuncioNoAplicable {
		return ControladorDomini.getContingut(x, y);
	}
	
	public static Cella getCellaAt(int x, int y) throws FuncioNoAplicable {
		return ControladorDomini.getCella(x, y);
	}
	
	public static Boolean getFormatBold(int x, int y) throws FuncioNoAplicable {
		return ControladorDomini.getFormatBold(x, y);
	}
	
	public static Boolean getFormatItalics(int x, int y) throws FuncioNoAplicable {
		return ControladorDomini.getFormatItalics(x, y);
	}
	
	public static double getMida(int x, int y) throws FuncioNoAplicable {
		return ControladorDomini.getMida(x, y);
	}
	
	public static int getColor(int x, int y) throws FuncioNoAplicable {
		return ControladorDomini.getColor(x, y);
	}

	/* Carrega un document preexistent al full de calcul */
	public static void loadSelectedDoc(String fileName, Vista window) throws FuncioNoAplicable {
			//Aqui es crida el controlador de Domini, que Crida el Gestor de Fitxers per llegir
		try {
			String format = fileName.substring(fileName.length() - 4, fileName.length());
		    if(format.equals(".csv")) ControladorDomini.carregarDocCSV(fileName);
		    else ControladorDomini.carregarDocFormatPropi(fileName);
		} catch (FileNotFoundException e) {
			makePopUp("No s'ha trobat el fitxer.");
		} catch (IOException e) {
			makePopUp("Error.");
		}
		window.loadDocWindow();
	}
	/*Elimina el fitxer del path*/
	public static void eliminaDoc(String path) {
		ControladorDomini.eliminarDoc(path);
		window.loadDocWindow();
	}
	
	/* Desa un document en format propi */
	public static void guardarDocFormatPropi(String path) throws FuncioNoAplicable, IndexNoValid, IOException {
		CtrlPresentacio.setPath(path);
		ControladorDomini.guardarDocFormatPropi(path);
	}
	
	/* Desa un document en format CSV */
	public static void guardarDocCSV(String path) throws FuncioNoAplicable, IndexNoValid, IOException {
		CtrlPresentacio.setPath(path);
		ControladorDomini.guardarDocCSV(path);
	}

	/* S'afegeix una columna al full actiu */
	public static void addCol(int i) {
		try {
			ControladorDomini.addCol(i);
		} catch (Exception e) {
			makePopUp(e.getMessage());
		}
	}

	/* S'afegeix una fila al full actiu */
	public static void addRow(int i) {
		try {
			ControladorDomini.addRow(i);
		} catch (Exception e) {
			makePopUp(e.getMessage());
		}
	}
	
	/* S'esborra una columna al full actiu */
	public static void deleteColumn(int i) throws IndexNoValid {
		ControladorDomini.delCol(i);
	}
	
	/* S'esborra una fila al full actiu */
	public static void deleteRow(int i) throws IndexNoValid {
		ControladorDomini.delRow(i);
	}
	
	/* S'esborra n columnes del full actiu des de la columna index */
	public static void deleteColumnSet(int n, int index) {
		try {
			ControladorDomini.delColSet(index, n);
		} catch (IndexNoValid e) {
			makePopUp(e.getMessage());
		}
	}
	
	/* S'esborra n files del full actiu des de la fila index */
	public static void deleteRowSet(int n, int index) {
		try {
			ControladorDomini.delRowSet(index, n);
		} catch (IndexNoValid e) {
			makePopUp(e.getMessage());
		}
	}

	/* S'inicialitza el document */
	public static void initDoc() {
		//ControladorDomini.init();
	}

	/* S'escriu el contingut de la cella a la casella del full actiu */
	public static void setContingutAt(String cont, int firstRow, int column) throws FuncioNoAplicable {
		ControladorDomini.escriu(cont, firstRow, column);
	}

	/* Rep la quantitat de fulls dins el document */
	public static int getLengthLlibreta() {
		return ControladorDomini.getLenghtLlibreta();
	}

	/* Rep el nom del full actiu */
	public static String getNomFull() {
		return ControladorDomini.getNomFull();
	}

	/* Selecciona el full actiu */
	public static void setFullActiu(int full) {
		try {
			ControladorDomini.modificarFullActiu(full);
		} catch (IndexNoValid e) {
			makePopUp("Error en l'index del full. Actualitzant la llibreta.");
			window.barraLlibreta();
		}
	}

	/* Afegeix un full */
	public static void addFull() {
		if (getLengthLlibreta() >= 5)
		{
			makePopUp("No es pot crear un nou full. \nFulls maxims: 5");
		}
		else 
		{
			int i = getFullActiu();
			ControladorDomini.afegirFull();
			
			try {
				ControladorDomini.modificarFullActiu(getLengthLlibreta()-1);
			} catch (IndexNoValid e) {
				makePopUp(e.getMessage());
			}
			
			window.makeFullButton(getLengthLlibreta()-1);
			
			try {
				ControladorDomini.modificarFullActiu(i);
			} catch (IndexNoValid e) {
				makePopUp(e.getMessage());
			}
		}
	}

	/* Esborra el full actiu */
	public static void esborrarFull() {
		try {
			if(ControladorDomini.getLenghtLlibreta() > 1) {
				ControladorDomini.eliminarFull(ControladorDomini.getFullActiu());
				window.canviarFull(0);
			}
			else {
				makePopUp("Només hi ha un full. No es pot eliminar.");
			}
			
		} catch (IndexNoValid e) {
				makePopUp(e.getMessage());
		}
		
	}

	/* Retorna l'index del full actiu */ 
	public static int getFullActiu() {
		return  ControladorDomini.getFullActiu();
	}
	
	/* Renombra el full actiu */
	public static void nombrarFull(String input) {
		ControladorDomini.nombrarFull(input);
	}
	
	/* Mou el full actiu de la posisicio original a la posicio input */
	public static void ordenaFull(int input) {
		try {
			ControladorDomini.ordenarFull(getFullActiu(), input);
		} catch (IndexNoValid e) {
			// TODO Auto-generated catch block
			makePopUp(e.getMessage());
		}
	}
	
	/* Substitueix el fragment indicat pel fragment substitut introduit al bloc delimitat per les celles inical i final */
	public static void substituir(String[] data) throws FuncioNoAplicable {
		ControladorDomini.substituir(data, ControladorDomini.getFull(ControladorDomini.getFullActiu()));
	}
	
	/* Copia les celles dins el bloc delimitat per les celles inicial i final al porta-retalls del document */
	public static void copiar(String[] data) throws FuncioNoAplicable {
		ControladorDomini.copiar(data, ControladorDomini.getFull(ControladorDomini.getFullActiu()));
	}
	
	/* Modifica de manera homogenia el contingut de les celles dins el bloc delimitat per les celles inicial i final amb l'input de l'usuari */
	public static void modificar(String[] data) throws FuncioNoAplicable {
		ControladorDomini.modificar(data, ControladorDomini.getFull(ControladorDomini.getFullActiu()));
	}
	
	/* Enganxa el contingut del porta-retalls del document al punt indicat per l'usuari */
	public static void enganxar(String[] data) throws FuncioNoAplicable {
		ControladorDomini.enganxar(data, ControladorDomini.getFull(ControladorDomini.getFullActiu()));
	}
	
	/* Esborra el continut de les celles dins el bloc delimitat per les celles inicial i final */
	public static void esborrar(String[] data) throws FuncioNoAplicable {
		ControladorDomini.esborrar(data, ControladorDomini.getFull(ControladorDomini.getFullActiu()));
	}
	
	/* Busca el fragment introduit per l'usuari dins el contingut de les celles dins el bloc delimitat per les celles inicial i final */
	public static void buscar(String[] data) throws FuncioNoAplicable {
		ControladorDomini.buscar(data, ControladorDomini.getFull(ControladorDomini.getFullActiu()));
	}
	
	/* Ordena les celles dins el bloc delimitat per les celles inicial i final segons un de quatre criteris
	 * (ascendentment, descendentment, ascendentment en funcio de la primera columna i descendentment dins de la primera columna */
	public static void ordenar(String[] data) throws FuncioNoAplicable {
		ControladorDomini.ordenar(data, ControladorDomini.getFull(ControladorDomini.getFullActiu()));
	}
	
	/* Mou les celles dins el bloc delimitat per les celles inicial i final a la regio indicada per la cella desti */
	public static void moure(String[] data) throws FuncioNoAplicable {
		ControladorDomini.moure(data[0], data[1], data[2]);
	}
	
	/* Aplica la funcio de la primera cella en una fila o columna, extenent-la evolutivament al llarg de la resta de celles */
	public static void aplicarFuncio(String[] data) throws FuncioNoAplicable {
		ControladorDomini.aplicarFuncio(data, ControladorDomini.getFull(ControladorDomini.getFullActiu()));
	}
	
	/* Pinta les celles dins el bloc delimitat per les celles inicial i final amb el color indicat per l'usuari */
	public static void pintarBloc(String[] parametres) throws FuncioNoAplicable {
		ControladorDomini.pintarBloc(parametres, ControladorDomini.getFull(CtrlPresentacio.getFullActiu()));
	}
	
	/* Crida al parser de ControladorDomini */
	public static void parser(String input, int x, int y) throws FuncioNoAplicable {
		ControladorDomini.parser(input, x, y, true);
	}
	
	/* Escriu el contingut de les caselles mostrades per Vista */
	public static void printContingut(String cont, int x, int y) {
		window.setContent(cont, x, y);
	}
	
	/* Desfa */
	public static void desfer() throws FuncioNoAplicable {
		ControladorDomini.desfes();
	}
	
	/* Refa */
	public static void refer() throws FuncioNoAplicable {
		ControladorDomini.refer();
	}
	
	/* Crea un missatge emergent d'avis en cas d'error en alguna operacio */
	public static void makePopUp(String string) {
		PopUp avis = new PopUp();
		avis.mostrarMissatge(string);
	}
}